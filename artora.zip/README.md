<div align="center">
<img width="1200" height="475" alt="GHBanner" src="https://ai.google.dev/static/site-assets/images/share-ais-513315318.png" />
</div>

# Run and deploy your AI Studio app

This contains everything you need to run your app locally.

View your app in AI Studio: https://ai.studio/apps/32deac7e-611f-4c0b-acdf-20cad3a06068

## Run Locally

**Prerequisites:**  Node.js


1. Install dependencies:
   `npm install`
2. Set the `GEMINI_API_KEY` in [.env.local](.env.local) to your Gemini API key
3. Run the app:
   `npm run dev`

## ARTORA redesign update
The project now uses the supplied black-and-pale-gold ARTORA logo and a six-path entry experience: Learn, Workshops, Discover, Buy, Expos and Studio. The Android experience includes a 50+ tutorial presentation, 50 music genres with sample cards, workshop registration flow, marketplace, professional studio, profile score/settings, and District/BookMyShow external ticket buttons.


ARTORA redesign: premium black/gold launch screen, six entry paths, 50 art learning categories, 50 music genres, tutorial lists, workshops, discover, marketplace buy/pitch, expos with District/BookMyShow links, studio inspiration, profile score and professional settings.
