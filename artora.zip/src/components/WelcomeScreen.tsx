import React from 'react';
import { 
  Palette, 
  Sparkles, 
  ShoppingBag, 
  PlusCircle, 
  ArrowRight, 
  BookOpen, 
  Compass,
  CheckCircle2
} from 'lucide-react';
import { MainMode } from '../types';

interface WelcomeScreenProps {
  onSelectOption: (option: 'learn' | 'pitch' | 'buy' | 'discover') => void;
  onExploreDirectly: () => void;
}

export const WelcomeScreen: React.FC<WelcomeScreenProps> = ({
  onSelectOption,
  onExploreDirectly
}) => {
  const cards = [
    {
      id: 'learn' as const,
      number: '01',
      title: 'Learn / Explore Art',
      subtitle: 'Master the craft with visual ateliers & guided lessons',
      bullets: [
        'Step-by-step tutorials',
        'Masterclasses from masters',
        'Art techniques & mediums',
        'Guided structured learning'
      ],
      image: 'https://images.unsplash.com/photo-1579783900882-c0d3dad7b119?auto=format&fit=crop&w=1000&q=85',
      badge: 'Interactive Learning',
      ctaText: 'Enter Atelier',
      icon: BookOpen
    },
    {
      id: 'pitch' as const,
      number: '02',
      title: 'Pitch Your Art',
      subtitle: 'Showcase your portfolio and present pieces to collectors',
      bullets: [
        'Upload fine artwork',
        'Build verified artist profile',
        'Submit & pitch to curators',
        'Sell original creations'
      ],
      image: 'https://images.unsplash.com/photo-1579783902614-a3fb3927b675?auto=format&fit=crop&w=1000&q=85',
      badge: 'Artist Studio',
      ctaText: 'Launch Studio',
      icon: PlusCircle
    },
    {
      id: 'buy' as const,
      number: '03',
      title: 'Buy Art',
      subtitle: 'Acquire original fine artworks directly from verified creators',
      bullets: [
        'Browse curated original art',
        'Discover emerging talents',
        'Purchase original artworks',
        'Certificate of authenticity'
      ],
      image: 'https://images.unsplash.com/photo-1541701494587-cb58502866ab?auto=format&fit=crop&w=1000&q=85',
      badge: 'Fine Art Marketplace',
      ctaText: 'Explore Gallery',
      icon: ShoppingBag
    },
    {
      id: 'discover' as const,
      number: '04',
      title: 'Discover Art',
      subtitle: 'Immerse in daily exhibitions and curated aesthetics',
      bullets: [
        'Discover professional artists',
        'Personalized recommendations',
        'Explore diverse art styles',
        'Curated daily exhibitions'
      ],
      image: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=1000&q=85',
      badge: 'Curated Discovery',
      ctaText: 'Discover Pieces',
      icon: Sparkles
    }
  ];

  return (
    <div className="min-h-[88vh] flex flex-col justify-center items-center px-4 sm:px-6 lg:px-8 py-10 sm:py-16 bg-[#FAF8F5] text-[#2D2926]">
      <div className="w-full max-w-6xl mx-auto">
        
        {/* Gallery Welcome Header */}
        <div className="text-center max-w-3xl mx-auto mb-12 sm:mb-16">
          
          {/* Subtle Pink & Gold Emblem Badge */}
          <div className="inline-flex items-center gap-2.5 px-4 py-1.5 rounded-full bg-[#FAF2F0] border border-[#EFE6D5] text-[#2D2926] text-xs font-sans font-medium tracking-[0.2em] uppercase mb-5 shadow-[0_2px_8px_rgba(197,160,89,0.08)]">
            <span className="w-2 h-2 rounded-full bg-[#C5A059]" />
            <span>Digital Contemporary Art Gallery</span>
          </div>

          <h1 className="text-4xl sm:text-6xl lg:text-7xl font-bodoni font-normal tracking-[0.06em] text-[#2D2926] leading-[1.08]">
            Welcome to <span className="font-semibold italic font-serif">Artora</span>
          </h1>
          
          <p className="mt-4 text-base sm:text-lg text-[#7D7571] max-w-2xl mx-auto font-sans font-normal leading-relaxed">
            A sanctuary where creators, collectors, and art enthusiasts learn techniques, discover inspiring collections, and trade original works.
          </p>

          {/* Editorial Section Marker */}
          <div className="mt-10 flex items-center justify-center gap-4">
            <div className="h-px w-12 bg-[#EFE8DE]" />
            <h2 className="text-xs sm:text-sm font-sans font-semibold uppercase tracking-[0.24em] text-[#7D7571]">
              What would you like to do today?
            </h2>
            <div className="h-px w-12 bg-[#EFE8DE]" />
          </div>
        </div>

        {/* 4 Large Premium Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 lg:gap-8 mb-14">
          {cards.map((card) => {
            const Icon = card.icon;
            return (
              <div
                key={card.id}
                id={`welcome-choice-${card.id}-card`}
                onClick={() => onSelectOption(card.id)}
                className="group relative bg-[#FFFFFF] rounded-2xl p-6 sm:p-7 border border-[#EFE8DE] hover:border-[#C5A059] shadow-[0_4px_24px_rgba(45,41,38,0.03)] hover:shadow-[0_12px_32px_rgba(197,160,89,0.12)] transition-all duration-300 cursor-pointer flex flex-col justify-between"
              >
                <div>
                  {/* Visual Artwork Frame */}
                  <div className="relative w-full h-56 sm:h-64 rounded-xl overflow-hidden mb-6 bg-[#FAF2F0] border border-[#EFE8DE]">
                    <img 
                      src={card.image} 
                      alt={card.title} 
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700 ease-out"
                      loading="lazy"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/55 via-black/10 to-transparent" />
                    
                    {/* Pale Pink Floating Badge */}
                    <div className="absolute top-3.5 left-3.5 px-3 py-1 rounded-full bg-[#FAF8F5]/95 backdrop-blur-md border border-[#EFE6D5] text-[#2D2926] text-[11px] font-sans font-medium tracking-wide shadow-sm flex items-center gap-1.5">
                      <span className="w-1.5 h-1.5 rounded-full bg-[#C5A059]" />
                      <span>{card.badge}</span>
                    </div>

                    {/* Numeric Accent */}
                    <div className="absolute bottom-3.5 right-4 font-serif italic text-3xl text-white/80">
                      {card.number}
                    </div>

                    {/* Quick Icon */}
                    <div className="absolute bottom-3.5 left-4 p-2 rounded-xl bg-[#FAF8F5]/90 backdrop-blur-md text-[#2D2926] shadow-sm">
                      <Icon className="w-4 h-4 text-[#C5A059]" />
                    </div>
                  </div>

                  {/* Card Editorial Content */}
                  <div>
                    <h3 className="text-2xl sm:text-3xl font-serif font-bold text-[#2D2926] group-hover:text-[#C5A059] transition-colors tracking-tight">
                      {card.title}
                    </h3>
                    <p className="mt-2 text-sm text-[#7D7571] font-sans leading-relaxed">
                      {card.subtitle}
                    </p>

                    {/* Feature Highlights with Pale Pink Dots */}
                    <div className="grid grid-cols-2 gap-2 mt-4 pt-4 border-t border-[#EFE8DE]/80">
                      {card.bullets.map((bullet, idx) => (
                        <div key={idx} className="flex items-center gap-2 text-xs text-[#57514D] font-sans">
                          <span className="w-1.5 h-1.5 rounded-full bg-[#FCEAE6] border border-[#C5A059]/40 shrink-0" />
                          <span className="truncate">{bullet}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Card Action Footer */}
                <div className="mt-6 pt-4 border-t border-[#EFE8DE] flex items-center justify-between">
                  <span className="text-xs font-sans font-semibold uppercase tracking-[0.16em] text-[#7D7571] group-hover:text-[#2D2926] transition-colors">
                    {card.ctaText}
                  </span>
                  <div className="w-9 h-9 rounded-full bg-[#FAF2F0] group-hover:bg-[#C5A059] text-[#2D2926] group-hover:text-white border border-[#EFE6D5] flex items-center justify-center transition-all duration-300">
                    <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-0.5" />
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Quick Explore Direct Navigation */}
        <div className="text-center pt-2 pb-6">
          <button
            id="welcome-skip-to-explore-button"
            onClick={onExploreDirectly}
            className="inline-flex items-center gap-2 px-5 py-2.5 rounded-full bg-[#FFFFFF] hover:bg-[#FAF2F0] text-[#2D2926] border border-[#EFE8DE] hover:border-[#C5A059] text-xs font-sans font-semibold tracking-wider uppercase transition-all shadow-[0_2px_8px_rgba(0,0,0,0.02)]"
          >
            <span>Enter Main Gallery Feed</span>
            <ArrowRight className="w-3.5 h-3.5 text-[#C5A059]" />
          </button>
        </div>

      </div>
    </div>
  );
};
