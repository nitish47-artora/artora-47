package com.artora.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.outlined.BookmarkBorder
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material.icons.outlined.Share
import androidx.compose.material.icons.outlined.ShoppingBag
import androidx.compose.material.icons.outlined.Sparkles
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.artora.app.data.ArtoraRepository
import com.artora.app.model.Artwork
import com.artora.app.ui.theme.*

@Composable
fun DiscoverFeedScreen(
    onSelectArtist: (String) -> Unit = {},
    onPurchaseArtwork: (Artwork) -> Unit = {}
) {
    var selectedFilter by remember { mutableStateOf("All") }
    var selectedArtwork by remember { mutableStateOf<Artwork?>(null) }
    var likedIds by remember { mutableStateOf(setOf("art-alpine-mist-01")) }
    var savedIds by remember { mutableStateOf(setOf("art-alpine-mist-01")) }

    val filters = listOf("All", "Painting", "Pottery & Ceramics", "Photography", "Digital Art")

    val filteredArtworks = if (selectedFilter == "All") {
        ArtoraRepository.artworks
    } else {
        ArtoraRepository.artworks.filter { it.artForm.contains(selectedFilter, ignoreCase = true) }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(ArtoraIvory)
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        // Editorial Header
        item {
            Column(modifier = Modifier.padding(top = 12.dp, bottom = 6.dp)) {
                Surface(
                    shape = RoundedCornerShape(50),
                    color = ArtoraBlush,
                    border = androidx.compose.foundation.BorderStroke(1.dp, ArtoraCreamBorder)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.Sparkles,
                            contentDescription = null,
                            tint = ArtoraGold,
                            modifier = Modifier.size(14.dp)
                        )
                        Text(
                            text = "CURATED EXHIBITION FEED",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = ArtoraCharcoal,
                            letterSpacing = 1.2.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = "Discover Inspiring Art",
                    fontFamily = FontFamily.Serif,
                    fontSize = 28.sp,
                    fontWeight = FontWeight.Normal,
                    color = ArtoraCharcoal
                )
                Text(
                    text = "& Masterpiece Creations",
                    fontFamily = FontFamily.Serif,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Light,
                    color = ArtoraMuted
                )
                Text(
                    text = "Explore curated creations, trending atelier studies, and connect directly with world-class artists.",
                    fontSize = 12.sp,
                    color = ArtoraTextBody,
                    modifier = Modifier.padding(top = 6.dp)
                )
            }
        }

        // Category Filter Chips
        item {
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(filters) { filter ->
                    val isSelected = selectedFilter == filter
                    Surface(
                        shape = RoundedCornerShape(50),
                        color = if (isSelected) ArtoraGold else ArtoraWhite,
                        border = androidx.compose.foundation.BorderStroke(1.dp, if (isSelected) ArtoraGold else ArtoraBeige),
                        modifier = Modifier.clickable { selectedFilter = filter }
                    ) {
                        Text(
                            text = filter,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = ArtoraCharcoal,
                            modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                        )
                    }
                }
            }
        }

        // Artworks Grid List
        items(filteredArtworks) { artwork ->
            val isLiked = likedIds.contains(artwork.id)
            val isSaved = savedIds.contains(artwork.id)

            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = ArtoraWhite),
                border = androidx.compose.foundation.BorderStroke(1.dp, ArtoraBeige),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { selectedArtwork = artwork }
            ) {
                Column {
                    // Image with Form & Price Badges
                    Box(modifier = Modifier.fillMaxWidth().height(220.dp)) {
                        AsyncImage(
                            model = artwork.image,
                            contentDescription = artwork.title,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )

                        // Medium Tag
                        Surface(
                            shape = RoundedCornerShape(50),
                            color = ArtoraIvory.copy(alpha = 0.95f),
                            border = androidx.compose.foundation.BorderStroke(1.dp, ArtoraCreamBorder),
                            modifier = Modifier
                                .align(Alignment.TopStart)
                                .padding(12.dp)
                        ) {
                            Text(
                                text = artwork.artForm,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = ArtoraCharcoal,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                            )
                        }

                        // Price Badge
                        if (artwork.isForSale) {
                            Surface(
                                shape = RoundedCornerShape(50),
                                color = ArtoraCharcoal.copy(alpha = 0.9f),
                                modifier = Modifier
                                    .align(Alignment.TopEnd)
                                    .padding(12.dp)
                            ) {
                                Text(
                                    text = "$${artwork.price.toInt()}",
                                    fontSize = 12.sp,
                                    fontFamily = FontFamily.Serif,
                                    fontWeight = FontWeight.Bold,
                                    color = ArtoraGold,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                )
                            }
                        }
                    }

                    // Card Content
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = artwork.title,
                            fontFamily = FontFamily.Serif,
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            color = ArtoraCharcoal,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = "${artwork.style} • ${artwork.dimensions}",
                            fontSize = 11.sp,
                            color = ArtoraMuted,
                            modifier = Modifier.padding(top = 2.dp)
                        )

                        Divider(
                            color = ArtoraBeige,
                            thickness = 1.dp,
                            modifier = Modifier.padding(vertical = 12.dp)
                        )

                        // Artist Row & Action Icons
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                modifier = Modifier.clickable { onSelectArtist(artwork.artistId) }
                            ) {
                                AsyncImage(
                                    model = artwork.artistAvatar,
                                    contentDescription = artwork.artistName,
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier
                                        .size(32.dp)
                                        .clip(CircleShape)
                                        .border(1.dp, ArtoraGold.copy(alpha = 0.4f), CircleShape)
                                )
                                Column {
                                    Text(
                                        text = artwork.artistName,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = ArtoraCharcoal
                                    )
                                    Text(
                                        text = "View Atelier",
                                        fontSize = 9.sp,
                                        color = ArtoraMuted
                                    )
                                }
                            }

                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                IconButton(
                                    onClick = {
                                        likedIds = if (isLiked) likedIds - artwork.id else likedIds + artwork.id
                                    },
                                    modifier = Modifier.size(32.dp)
                                ) {
                                    Icon(
                                        imageVector = if (isLiked) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder,
                                        contentDescription = "Like",
                                        tint = if (isLiked) ArtoraGold else ArtoraMuted,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }

                                IconButton(
                                    onClick = {
                                        savedIds = if (isSaved) savedIds - artwork.id else savedIds + artwork.id
                                    },
                                    modifier = Modifier.size(32.dp)
                                ) {
                                    Icon(
                                        imageVector = if (isSaved) Icons.Filled.Bookmark else Icons.Outlined.BookmarkBorder,
                                        contentDescription = "Save",
                                        tint = if (isSaved) ArtoraGold else ArtoraMuted,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }

    // Detail Modal Dialog
    selectedArtwork?.let { art ->
        AlertDialog(
            onDismissRequest = { selectedArtwork = null },
            confirmButton = {
                Button(
                    onClick = {
                        val toBuy = art
                        selectedArtwork = null
                        onPurchaseArtwork(toBuy)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ArtoraGold),
                    shape = RoundedCornerShape(50)
                ) {
                    Icon(
                        imageVector = Icons.Outlined.ShoppingBag,
                        contentDescription = null,
                        tint = ArtoraCharcoal,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Acquire for $${art.price.toInt()}",
                        color = ArtoraCharcoal,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )
                }
            },
            dismissButton = {
                TextButton(onClick = { selectedArtwork = null }) {
                    Text("Close", color = ArtoraMuted)
                }
            },
            title = {
                Text(
                    text = art.title,
                    fontFamily = FontFamily.Serif,
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp,
                    color = ArtoraCharcoal
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Box(modifier = Modifier.fillMaxWidth().height(180.dp).clip(RoundedCornerShape(12.dp))) {
                        AsyncImage(
                            model = art.image,
                            contentDescription = art.title,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                    Text(text = art.description, fontSize = 12.sp, color = ArtoraTextBody)
                    Text(text = "Materials: ${art.materials}", fontSize = 11.sp, color = ArtoraMuted)
                    Text(text = "Format: ${art.dimensions}", fontSize = 11.sp, color = ArtoraMuted)
                }
            },
            containerColor = ArtoraIvory,
            shape = RoundedCornerShape(20.dp)
        )
    }
}
