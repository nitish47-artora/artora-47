package com.artora.app.audio

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import kotlinx.coroutines.*
import kotlin.math.sin

object ArtoraAudioSynthesizer {
    private const val SAMPLE_RATE = 44100
    private var audioTrack: AudioTrack? = null
    private var isPlaying = false
    private var synthJob: Job? = null

    fun playPreset(preset: String, onProgress: ((Int) -> Unit)? = null) {
        stop()
        isPlaying = true

        val minBufferSize = AudioTrack.getMinBufferSize(
            SAMPLE_RATE,
            AudioFormat.CHANNEL_OUT_MONO,
            AudioFormat.ENCODING_PCM_16BIT
        )

        audioTrack = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(SAMPLE_RATE)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build()
            )
            .setBufferSizeInBytes(minBufferSize)
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build()

        audioTrack?.play()

        val frequencies = when (preset) {
            "jazz_swing" -> listOf(261.63, 329.63, 392.00, 493.88, 587.33) // Cmaj7, Dm7 notes
            "classical_piano" -> listOf(220.0, 277.18, 329.63, 440.0, 554.37) // A minor / major arpeggios
            "ambient_chords" -> listOf(174.61, 220.00, 261.63, 349.23) // Fmaj7 ambient
            else -> listOf(261.63, 329.63, 392.00, 523.25)
        }

        synthJob = CoroutineScope(Dispatchers.Default).launch {
            val buffer = ShortArray(1024)
            var sampleIndex = 0L
            var secondsElapsed = 0

            while (isPlaying && isActive) {
                val currentFreq = frequencies[(sampleIndex / (SAMPLE_RATE * 0.5)).toInt() % frequencies.size]
                
                for (i in buffer.indices) {
                    val time = sampleIndex.toDouble() / SAMPLE_RATE
                    val angle = 2.0 * Math.PI * currentFreq * time
                    val sample = (sin(angle) * 0.35 * Short.MAX_VALUE).toInt().toShort()
                    buffer[i] = sample
                    sampleIndex++
                }

                audioTrack?.write(buffer, 0, buffer.size)

                if (sampleIndex % SAMPLE_RATE < 1024) {
                    secondsElapsed++
                    withContext(Dispatchers.Main) {
                        onProgress?.invoke(secondsElapsed)
                    }
                }
            }
        }
    }

    fun pause() {
        isPlaying = false
        synthJob?.cancel()
        audioTrack?.pause()
    }

    fun stop() {
        isPlaying = false
        synthJob?.cancel()
        audioTrack?.stop()
        audioTrack?.release()
        audioTrack = null
    }

    fun isCurrentlyPlaying(): Boolean = isPlaying
}
