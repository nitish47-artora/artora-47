package com.artora.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import com.artora.app.ui.components.AppDestination
import com.artora.app.ui.components.ArtoraBottomBar
import com.artora.app.ui.components.ArtoraTopBar
import com.artora.app.ui.screens.*
import com.artora.app.ui.theme.ArtoraIvory
import com.artora.app.ui.theme.ArtoraTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            ArtoraTheme {
                ArtoraAppContent()
            }
        }
    }
}

@Composable
fun ArtoraAppContent() {
    var currentDestination by remember { mutableStateOf(AppDestination.DISCOVER) }
    var selectedArtistId by remember { mutableStateOf<String?>(null) }
    var isWelcomeShown by remember { mutableStateOf(false) }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = ArtoraIvory
    ) {
        if (!isWelcomeShown) {
            WelcomeScreen(
                onNavigate = { destination ->
                    isWelcomeShown = true
                    currentDestination = destination
                }
            )
        } else {
            Scaffold(
                topBar = {
                    ArtoraTopBar(
                        title = "ARTORA",
                        subtitle = "ATELIER & DISCOVERY"
                    )
                },
                bottomBar = {
                    ArtoraBottomBar(
                        currentDestination = currentDestination,
                        onNavigate = { destination ->
                            selectedArtistId = null
                            currentDestination = destination
                        }
                    )
                },
                containerColor = ArtoraIvory
            ) { paddingValues ->
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(paddingValues)
                ) {
                    if (selectedArtistId != null) {
                        ArtistProfileScreen(
                            artistId = selectedArtistId!!,
                            onBack = { selectedArtistId = null }
                        )
                    } else {
                        when (currentDestination) {
                            AppDestination.DISCOVER -> DiscoverFeedScreen(
                                onSelectArtist = { id -> selectedArtistId = id }
                            )
                            AppDestination.WORKSHOPS -> WorkshopsScreen()
                            AppDestination.PRACTICE -> PracticeSystemScreen()
                            AppDestination.NEARBY -> ExploreNearbyScreen()
                            AppDestination.MUSIC -> MusicExperienceScreen()
                            AppDestination.MARKET -> MarketplaceScreen(
                                onSelectArtist = { id -> selectedArtistId = id }
                            )
                        }
                    }
                }
            }
        }
    }
}
