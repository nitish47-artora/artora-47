package com.artora.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.artora.app.ui.theme.*

enum class AppDestination(val label: String, val icon: ImageVector) {
    DISCOVER("Discover", Icons.Outlined.Visibility),
    WORKSHOPS("Workshops", Icons.Outlined.MenuBook),
    PRACTICE("Studio", Icons.Outlined.Brush),
    NEARBY("Salons", Icons.Outlined.Place),
    MUSIC("Music", Icons.Outlined.MusicNote),
    MARKET("Market", Icons.Outlined.ShoppingBag)
}

@Composable
fun ArtoraBottomBar(
    currentDestination: AppDestination,
    onNavigate: (AppDestination) -> Unit
) {
    Surface(
        color = ArtoraWhite,
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, ArtoraBeige)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(horizontal = 8.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceAround,
            verticalAlignment = Alignment.CenterVertically
        ) {
            AppDestination.values().forEach { destination ->
                val isSelected = currentDestination == destination

                NavigationBarItem(
                    selected = isSelected,
                    onClick = { onNavigate(destination) },
                    icon = {
                        Icon(
                            imageVector = destination.icon,
                            contentDescription = destination.label,
                            tint = if (isSelected) ArtoraCharcoal else ArtoraMuted,
                            modifier = Modifier.size(20.dp)
                        )
                    },
                    label = {
                        Text(
                            text = destination.label,
                            fontSize = 10.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                            color = if (isSelected) ArtoraCharcoal else ArtoraMuted
                        )
                    },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = ArtoraCharcoal,
                        selectedTextColor = ArtoraCharcoal,
                        indicatorColor = ArtoraGold.copy(alpha = 0.25f),
                        unselectedIconColor = ArtoraMuted,
                        unselectedTextColor = ArtoraMuted
                    )
                )
            }
        }
    }
}
