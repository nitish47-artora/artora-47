package com.artora.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.artora.app.audio.ArtoraAudioSynthesizer
import com.artora.app.data.ArtoraRepository
import com.artora.app.model.MusicTrack
import com.artora.app.ui.theme.*

@Composable
fun MusicExperienceScreen() {
    var selectedGenreKey by remember { mutableStateOf("jazz") }
    var currentPlayingTrack by remember { mutableStateOf<MusicTrack?>(null) }
    var isPlaying by remember { mutableStateOf(false) }
    var playbackSeconds by remember { mutableStateOf(0) }

    val genre = ArtoraRepository.musicGenres[selectedGenreKey] ?: ArtoraRepository.musicGenres["jazz"]!!

    DisposableEffect(Unit) {
        onDispose {
            ArtoraAudioSynthesizer.stop()
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(ArtoraIvory)
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Header
        item {
            Column(modifier = Modifier.padding(top = 12.dp, bottom = 4.dp)) {
                Surface(
                    shape = RoundedCornerShape(50),
                    color = ArtoraBlush,
                    border = androidx.compose.foundation.BorderStroke(1.dp, ArtoraCreamBorder)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.MusicNote,
                            contentDescription = null,
                            tint = ArtoraGold,
                            modifier = Modifier.size(14.dp)
                        )
                        Text(
                            text = "SONIC CONSERVATORY & HARMONY",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = ArtoraCharcoal,
                            letterSpacing = 1.2.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = "Sonic Arts & Theory",
                    fontFamily = FontFamily.Serif,
                    fontSize = 26.sp,
                    fontWeight = FontWeight.Normal,
                    color = ArtoraCharcoal
                )
                Text(
                    text = "Explore harmonic lineages, modal improvisation, and real-time synthesized acoustic scores.",
                    fontSize = 12.sp,
                    color = ArtoraTextBody,
                    modifier = Modifier.padding(top = 4.dp)
                )
            }
        }

        // Genre Tabs
        item {
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(listOf("jazz" to "Jazz & Modal", "classical" to "Classical & Piano")) { item ->
                    val isSelected = selectedGenreKey == item.first
                    Surface(
                        shape = RoundedCornerShape(50),
                        color = if (isSelected) ArtoraGold else ArtoraWhite,
                        border = androidx.compose.foundation.BorderStroke(1.dp, if (isSelected) ArtoraGold else ArtoraBeige),
                        modifier = Modifier.clickable { selectedGenreKey = item.first }
                    ) {
                        Text(
                            text = item.second,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = ArtoraCharcoal,
                            modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                        )
                    }
                }
            }
        }

        // Hero Genre Card
        item {
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = ArtoraWhite),
                border = androidx.compose.foundation.BorderStroke(1.dp, ArtoraBeige),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column {
                    Box(modifier = Modifier.fillMaxWidth().height(160.dp)) {
                        AsyncImage(
                            model = genre.coverImage,
                            contentDescription = genre.name,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                    }

                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(
                            text = genre.name,
                            fontFamily = FontFamily.Serif,
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp,
                            color = ArtoraCharcoal
                        )
                        Text(
                            text = genre.tagline,
                            fontSize = 12.sp,
                            color = ArtoraMuted
                        )
                        Text(
                            text = genre.history,
                            fontSize = 12.sp,
                            color = ArtoraTextBody
                        )

                        // Characteristics
                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(
                                text = "CORE HARMONIC ATTRIBUTES",
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                color = ArtoraCharcoal,
                                letterSpacing = 1.sp
                            )
                            genre.characteristics.forEach { char ->
                                Row(
                                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(6.dp)
                                            .clip(CircleShape)
                                            .background(ArtoraGold)
                                    )
                                    Text(text = char, fontSize = 11.sp, color = ArtoraTextBody)
                                }
                            }
                        }
                    }
                }
            }
        }

        // Procedural Audio Player / Track List
        item {
            Text(
                text = "Synthesized Master Scores",
                fontFamily = FontFamily.Serif,
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp,
                color = ArtoraCharcoal,
                modifier = Modifier.padding(top = 8.dp)
            )
        }

        items(genre.tracks) { track ->
            val isCurrent = currentPlayingTrack?.id == track.id
            val isCurrentlyActive = isCurrent && isPlaying

            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = if (isCurrentlyActive) ArtoraBlush else ArtoraWhite),
                border = androidx.compose.foundation.BorderStroke(1.dp, if (isCurrentlyActive) ArtoraGold else ArtoraBeige),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        IconButton(
                            onClick = {
                                if (isCurrentlyActive) {
                                    ArtoraAudioSynthesizer.pause()
                                    isPlaying = false
                                } else {
                                    currentPlayingTrack = track
                                    isPlaying = true
                                    playbackSeconds = 0
                                    ArtoraAudioSynthesizer.playPreset(track.audioPreset) { sec ->
                                        playbackSeconds = sec
                                    }
                                }
                            },
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(ArtoraGold)
                        ) {
                            Icon(
                                imageVector = if (isCurrentlyActive) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                                contentDescription = if (isCurrentlyActive) "Pause" else "Play",
                                tint = ArtoraCharcoal,
                                modifier = Modifier.size(22.dp)
                            )
                        }

                        Column {
                            Text(
                                text = track.title,
                                fontFamily = FontFamily.Serif,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                color = ArtoraCharcoal
                            )
                            Text(
                                text = "${track.artist} • ${track.bpm} BPM • ${track.license}",
                                fontSize = 10.sp,
                                color = ArtoraMuted
                            )
                        }
                    }

                    Surface(
                        shape = RoundedCornerShape(50),
                        color = ArtoraWhite,
                        border = androidx.compose.foundation.BorderStroke(1.dp, ArtoraCreamBorder)
                    ) {
                        Text(
                            text = if (isCurrentlyActive) "0:${playbackSeconds.toString().padStart(2, '0')}" else "${track.duration}s",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = ArtoraCharcoal,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                        )
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}
