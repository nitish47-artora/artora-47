package com.artora.app.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.artora.app.R
import com.artora.app.ui.components.AppDestination
import com.artora.app.ui.theme.*

data class WelcomeChoice(val title: String, val subtitle: String, val icon: androidx.compose.ui.graphics.vector.ImageVector, val destination: AppDestination)

@Composable
fun WelcomeScreen(onNavigate: (AppDestination) -> Unit) {
    val choices = listOf(
        WelcomeChoice("Learn", "Explore tutorials & improve your skills", Icons.Outlined.MenuBook, AppDestination.LEARN),
        WelcomeChoice("Workshops", "Join workshops & enhance your talent", Icons.Outlined.School, AppDestination.WORKSHOPS),
        WelcomeChoice("Discover", "Discover arts and creative ideas", Icons.Outlined.Lightbulb, AppDestination.DISCOVER),
        WelcomeChoice("Buy", "Buy or pitch your artworks", Icons.Outlined.ShoppingCart, AppDestination.MARKET),
        WelcomeChoice("Expos", "Find expos and exhibitions near you", Icons.Outlined.ConfirmationNumber, AppDestination.NEARBY),
        WelcomeChoice("Studio", "Get inspired by professional artists", Icons.Outlined.Brush, AppDestination.PRACTICE)
    )

    Column(Modifier.fillMaxSize().background(Color.Black).padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Spacer(Modifier.height(6.dp))
        Image(painter = painterResource(R.drawable.artora_logo), contentDescription = "ARTORA logo", modifier = Modifier.size(150.dp).clip(RoundedCornerShape(22.dp)))
        Spacer(Modifier.height(10.dp))
        Text("Where Art Inspires You", fontSize = 11.sp, color = ArtoraGold, fontWeight = FontWeight.SemiBold, letterSpacing = 1.2.sp)
        Spacer(Modifier.height(5.dp))
        Text("What would you like to do today?", fontFamily = FontFamily.Serif, fontSize = 22.sp, fontWeight = FontWeight.Bold, color = ArtoraWhite, textAlign = TextAlign.Center)
        Spacer(Modifier.height(14.dp))
        LazyVerticalGrid(columns = GridCells.Fixed(2), modifier = Modifier.fillMaxWidth().weight(1f), verticalArrangement = Arrangement.spacedBy(11.dp), horizontalArrangement = Arrangement.spacedBy(11.dp), contentPadding = PaddingValues(bottom = 8.dp)) {
            items(choices) { choice ->
                Card(shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = ArtoraIvory), border = androidx.compose.foundation.BorderStroke(1.dp, ArtoraGold.copy(alpha = 0.35f)), modifier = Modifier.fillMaxWidth().height(138.dp).clickable { onNavigate(choice.destination) }) {
                    Column(Modifier.fillMaxSize().padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                        Box(Modifier.size(43.dp).clip(RoundedCornerShape(13.dp)).background(ArtoraBlush), contentAlignment = Alignment.Center) { Icon(choice.icon, null, tint = ArtoraGold, modifier = Modifier.size(24.dp)) }
                        Spacer(Modifier.height(7.dp))
                        Text(choice.title, fontFamily = FontFamily.Serif, fontSize = 17.sp, fontWeight = FontWeight.Bold, color = ArtoraCharcoal)
                        Text(choice.subtitle, fontSize = 9.sp, color = ArtoraTextBody, textAlign = TextAlign.Center, lineHeight = 13.sp)
                    }
                }
            }
        }
        Text("ARTORA • CONTEMPORARY ART & CREATIVE DISCOVERY", fontSize = 8.sp, color = ArtoraGold.copy(alpha = 0.75f), letterSpacing = 1.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(bottom = 4.dp))
    }
}
