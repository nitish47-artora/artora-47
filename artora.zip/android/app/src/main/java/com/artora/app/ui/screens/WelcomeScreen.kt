package com.artora.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.artora.app.ui.components.AppDestination
import com.artora.app.ui.theme.*

@Composable
fun WelcomeScreen(
    onNavigate: (AppDestination) -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(ArtoraIvory)
            .padding(24.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.SpaceBetween,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(modifier = Modifier.height(20.dp))

            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Monogram
                Box(
                    modifier = Modifier
                        .size(72.dp)
                        .clip(CircleShape)
                        .background(ArtoraCharcoal)
                        .border(2.dp, ArtoraGold, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "A",
                        color = ArtoraGold,
                        fontSize = 36.sp,
                        fontFamily = FontFamily.Serif,
                        fontWeight = FontWeight.Bold
                    )
                }

                Surface(
                    shape = RoundedCornerShape(50),
                    color = ArtoraBlush,
                    border = androidx.compose.foundation.BorderStroke(1.dp, ArtoraCreamBorder)
                ) {
                    Text(
                        text = "THE CONTEMPORARY ATELIER",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = ArtoraCharcoal,
                        letterSpacing = 1.5.sp,
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                    )
                }

                Text(
                    text = "ARTORA",
                    fontFamily = FontFamily.Serif,
                    fontSize = 38.sp,
                    fontWeight = FontWeight.Normal,
                    color = ArtoraCharcoal,
                    letterSpacing = 2.sp
                )

                Text(
                    text = "A sanctuary for fine artists, master ceramicists, plein-air painters, and sonic composers.",
                    fontSize = 13.sp,
                    color = ArtoraTextBody,
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                    modifier = Modifier.padding(horizontal = 16.dp)
                )
            }

            // Quick Pathways
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = { onNavigate(AppDestination.DISCOVER) },
                    colors = ButtonDefaults.buttonColors(containerColor = ArtoraGold),
                    shape = RoundedCornerShape(50),
                    modifier = Modifier.fillMaxWidth().height(48.dp)
                ) {
                    Text("Enter Curated Exhibition", color = ArtoraCharcoal, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }

                Button(
                    onClick = { onNavigate(AppDestination.PRACTICE) },
                    colors = ButtonDefaults.buttonColors(containerColor = ArtoraWhite),
                    border = androidx.compose.foundation.BorderStroke(1.dp, ArtoraBeige),
                    shape = RoundedCornerShape(50),
                    modifier = Modifier.fillMaxWidth().height(48.dp)
                ) {
                    Text("Start Atelier Practice Ladder", color = ArtoraCharcoal, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                }
            }
        }
    }
}
