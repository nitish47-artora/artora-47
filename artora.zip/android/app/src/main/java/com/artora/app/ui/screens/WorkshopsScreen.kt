package com.artora.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.artora.app.data.ArtoraRepository
import com.artora.app.model.Tutorial
import com.artora.app.ui.theme.*

@Composable
fun WorkshopsScreen(
    onOpenTutorial: (Tutorial) -> Unit = {}
) {
    var selectedCategory by remember { mutableStateOf("painting") }
    var activeTutorialModal by remember { mutableStateOf<Tutorial?>(null) }

    val categories = ArtoraRepository.categories
    val currentTutorial = ArtoraRepository.tutorials.firstOrNull() ?: ArtoraRepository.tutorials[0]

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(ArtoraIvory)
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Header
        item {
            Column(modifier = Modifier.padding(top = 12.dp, bottom = 4.dp)) {
                Surface(
                    shape = RoundedCornerShape(50),
                    color = ArtoraBlush,
                    border = androidx.compose.foundation.BorderStroke(1.dp, ArtoraCreamBorder)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.School,
                            contentDescription = null,
                            tint = ArtoraGold,
                            modifier = Modifier.size(14.dp)
                        )
                        Text(
                            text = "ATELIER MASTERCLASSES & ACADEMY",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = ArtoraCharcoal,
                            letterSpacing = 1.2.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = "Mastery Through Guided Steps",
                    fontFamily = FontFamily.Serif,
                    fontSize = 26.sp,
                    fontWeight = FontWeight.Normal,
                    color = ArtoraCharcoal
                )
                Text(
                    text = "Learn traditional techniques, brushwork geometry, and classical oil & ceramic glaze physics.",
                    fontSize = 12.sp,
                    color = ArtoraTextBody,
                    modifier = Modifier.padding(top = 4.dp)
                )
            }
        }

        // Category Pills
        item {
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(categories) { cat ->
                    val isSelected = selectedCategory == cat.id
                    Surface(
                        shape = RoundedCornerShape(50),
                        color = if (isSelected) ArtoraGold else ArtoraWhite,
                        border = androidx.compose.foundation.BorderStroke(1.dp, if (isSelected) ArtoraGold else ArtoraBeige),
                        modifier = Modifier.clickable { selectedCategory = cat.id }
                    ) {
                        Text(
                            text = cat.name,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = ArtoraCharcoal,
                            modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                        )
                    }
                }
            }
        }

        // Featured Tutorial Card
        item {
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = ArtoraWhite),
                border = androidx.compose.foundation.BorderStroke(1.dp, ArtoraBeige),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { activeTutorialModal = currentTutorial }
            ) {
                Column {
                    Box(modifier = Modifier.fillMaxWidth().height(200.dp)) {
                        AsyncImage(
                            model = currentTutorial.coverImage,
                            contentDescription = currentTutorial.title,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                        Surface(
                            shape = RoundedCornerShape(50),
                            color = ArtoraGold,
                            modifier = Modifier.align(Alignment.TopStart).padding(12.dp)
                        ) {
                            Text(
                                text = "Featured Workshop",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = ArtoraCharcoal,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                            )
                        }
                    }

                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = currentTutorial.title,
                            fontFamily = FontFamily.Serif,
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp,
                            color = ArtoraCharcoal
                        )
                        Text(
                            text = currentTutorial.subtitle,
                            fontSize = 12.sp,
                            color = ArtoraMuted,
                            modifier = Modifier.padding(top = 4.dp)
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                AsyncImage(
                                    model = currentTutorial.creatorAvatar,
                                    contentDescription = currentTutorial.creatorName,
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier
                                        .size(28.dp)
                                        .clip(CircleShape)
                                        .border(1.dp, ArtoraGold, CircleShape)
                                )
                                Text(
                                    text = currentTutorial.creatorName,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = ArtoraCharcoal
                                )
                            }

                            Button(
                                onClick = { activeTutorialModal = currentTutorial },
                                colors = ButtonDefaults.buttonColors(containerColor = ArtoraGold),
                                shape = RoundedCornerShape(50),
                                contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp)
                            ) {
                                Text(
                                    text = "Start (${currentTutorial.durationMinutes}m)",
                                    color = ArtoraCharcoal,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp
                                )
                            }
                        }
                    }
                }
            }
        }

        // Step by step breakdown list
        item {
            Text(
                text = "Curriculum & Progression",
                fontFamily = FontFamily.Serif,
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp,
                color = ArtoraCharcoal,
                modifier = Modifier.padding(top = 8.dp)
            )
        }

        items(currentTutorial.steps) { step ->
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = ArtoraWhite),
                border = androidx.compose.foundation.BorderStroke(1.dp, ArtoraBeige),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalAlignment = Alignment.Top
                ) {
                    Box(
                        modifier = Modifier
                            .size(28.dp)
                            .clip(CircleShape)
                            .background(ArtoraBlush)
                            .border(1.dp, ArtoraCreamBorder, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "${step.stepNumber}",
                            fontSize = 12.sp,
                            fontFamily = FontFamily.Serif,
                            fontWeight = FontWeight.Bold,
                            color = ArtoraGold
                        )
                    }

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = step.title,
                            fontFamily = FontFamily.Serif,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = ArtoraCharcoal
                        )
                        Text(
                            text = step.explanation,
                            fontSize = 12.sp,
                            color = ArtoraTextBody,
                            modifier = Modifier.padding(top = 4.dp)
                        )
                        step.proTip?.let { tip ->
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = ArtoraBlush,
                                border = androidx.compose.foundation.BorderStroke(1.dp, ArtoraCreamBorder),
                                modifier = Modifier.padding(top = 8.dp)
                            ) {
                                Row(
                                    modifier = Modifier.padding(8.dp),
                                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Outlined.Lightbulb,
                                        contentDescription = null,
                                        tint = ArtoraGold,
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Text(
                                        text = "Master Tip: $tip",
                                        fontSize = 10.sp,
                                        color = ArtoraTextBody
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }

    // Modal dialog
    activeTutorialModal?.let { tut ->
        AlertDialog(
            onDismissRequest = { activeTutorialModal = null },
            confirmButton = {
                Button(
                    onClick = {
                        activeTutorialModal = null
                        onOpenTutorial(tut)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ArtoraGold),
                    shape = RoundedCornerShape(50)
                ) {
                    Text("Begin Masterclass", color = ArtoraCharcoal, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { activeTutorialModal = null }) {
                    Text("Close", color = ArtoraMuted)
                }
            },
            title = {
                Text(
                    text = tut.title,
                    fontFamily = FontFamily.Serif,
                    fontWeight = FontWeight.Bold,
                    color = ArtoraCharcoal
                )
            },
            text = {
                Text(
                    text = "${tut.subtitle}\n\nInstructor: ${tut.creatorName} (${tut.creatorRole})\nDuration: ${tut.durationMinutes} mins",
                    fontSize = 12.sp,
                    color = ArtoraTextBody
                )
            },
            containerColor = ArtoraIvory,
            shape = RoundedCornerShape(20.dp)
        )
    }
}
