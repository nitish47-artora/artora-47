export type MainMode = 
  | 'welcome' 
  | 'category_pick'
  | 'home' 
  | 'learn' 
  | 'pitch' 
  | 'buy' 
  | 'discover' 
  | 'music' 
  | 'events'
  | 'workshops'
  | 'studio'
  | 'profile' 
  | 'tutorial_view'
  | 'contest_prep' 
  | 'idea_gen' 
  | 'artist_detail'
  | 'portfolio' 
  | 'settings';

export type CategoryTab = 
  | 'overview' 
  | 'tutorials' 
  | 'types' 
  | 'techniques' 
  | 'practice' 
  | 'workshops' 
  | 'professional'
  | 'artists' 
  | 'events'
  | 'workshops'
  | 'studio'
  | 'profile';

export type MusicTab = 'overview' | 'music' | 'artists' | 'instruments' | 'learn';

export type DifficultyLevel = 'Beginner' | 'Intermediate' | 'Advanced' | 'Portfolio Ready';

export interface ArtCategory {
  id: string;
  name: string;
  tagline: string;
  description: string;
  icon: string;
  color: string;
  bgGradient: string;
  coverImage: string;
  types: { name: string; description: string; image: string }[];
  styles: { name: string; description: string }[];
  techniques: { title: string; difficulty: string; description: string; tip: string; tools: string[] }[];
  popularMaterials: string[];
  historyFact: string;
}

export interface TutorialStep {
  stepNumber: number;
  title: string;
  image: string;
  explanation: string;
  materials: string[];
  proTip?: string;
}

export interface Tutorial {
  id: string;
  categoryId: string;
  title: string;
  subtitle: string;
  coverImage: string;
  difficulty: DifficultyLevel;
  durationMinutes: number;
  totalSteps: number;
  creator: {
    name: string;
    avatar: string;
    role: string;
  };
  steps: TutorialStep[];
  rating: number;
  tags: string[];
}

export interface PracticeTask {
  id: string;
  categoryId: string;
  taskNumber: number;
  title: string;
  level: DifficultyLevel;
  estimatedMinutes: number;
  materials: string[];
  instructions: string[];
  referenceImage: string;
  criteria: string[];
  mentorTip: string;
}

export interface Workshop {
  id: string;
  title: string;
  instructor: {
    name: string;
    title: string;
    avatar: string;
  };
  categoryId: string;
  artForm: string;
  date: string;
  time: string;
  duration: string;
  difficulty: DifficultyLevel;
  locationType: 'Online' | 'Local Studio';
  locationName: string;
  city?: string;
  price: string;
  image: string;
  description: string;
  agenda: string[];
  materialsProvided: string[];
  spotsRemaining: number;
}

export interface MusicTrack {
  id: string;
  title: string;
  artist: string;
  genre: string;
  duration: number; // in seconds
  audioPreset: 'jazz_swing' | 'classical_piano' | 'ambient_chords' | 'blues_riff' | 'lofi_chill' | 'folk_acoustic' | 'synthwave';
  coverImage: string;
  description: string;
  instrumentsUsed: string[];
  bpm: number;
  license: 'Royalty-Free' | 'Public Domain' | 'Original Artora Composition';
}

export interface MusicGenreInfo {
  id: string;
  name: string;
  tagline: string;
  coverImage: string;
  history: string;
  characteristics: string[];
  commonInstruments: { name: string; role: string; image: string }[];
  featuredArtists: { name: string; era: string; description: string; image: string }[];
  tracks: MusicTrack[];
  learningResources: { title: string; type: string; duration: string }[];
  relatedGenres: string[];
}

export interface ArtistProfile {
  id: string;
  name: string;
  handle: string;
  specialization: string;
  artCategory: string;
  location: string;
  bio: string;
  avatar: string;
  coverImage: string;
  rating: number;
  followersCount: number;
  artworksCount: number;
  featured: boolean;
  trending: boolean;
  verified: boolean;
  contactEmail: string;
  openForCommissions: boolean;
  artworks: Artwork[];
  badges: string[];
}

export interface Artwork {
  id: string;
  title: string;
  artistId: string;
  artistName: string;
  artistAvatar: string;
  categoryId: string;
  artForm: string;
  style: string;
  materials: string;
  dimensions: string;
  image: string;
  price: number;
  currency: string;
  isForSale: boolean;
  isSold?: boolean;
  description: string;
  likesCount: number;
  savesCount: number;
  createdAt: string;
  externalSellerUrl?: string;
}

export interface ArtEvent {
  id: string;
  title: string;
  type: 'Exhibition' | 'Workshop' | 'Gallery Opening' | 'Craft Fair' | 'Concert' | 'Cultural Festival' | 'Artist Meetup';
  artCategory: string;
  venue: string;
  city: string;
  address: string;
  distanceKm: number;
  dateStr: string;
  timeStr: string;
  dateFilter: 'today' | 'this_weekend' | 'this_week' | 'this_month';
  isFree: boolean;
  priceStr: string;
  image: string;
  description: string;
  organizer: string;
  rsvpCount: number;
  coordinates: { lat: number; lng: number };
}

export interface ContestChallenge {
  id: string;
  title: string;
  subtitle: string;
  organizer: string;
  category: string;
  deadline: string;
  daysRemaining: number;
  prizePool: string;
  image: string;
  theme: string;
  sevenDayPlan: { day: number; title: string; task: string; focus: string }[];
  guidelines: string[];
  evaluationCriteria: string[];
  portfolioTips: string[];
}

export interface UserSettings {
  darkMode: boolean;
  fontSize: 'normal' | 'medium' | 'large';
  reducedMotion: boolean;
  highContrast: boolean;
  notificationsEnabled: boolean;
  soundEffects: boolean;
  locationEnabled: boolean;
  userName: string;
  userEmail: string;
  preferredCity: string;
}

export interface PitchArtworkForm {
  title: string;
  description: string;
  categoryId: string;
  artForm: string;
  style: string;
  materials: string;
  dimensions: string;
  price: string;
  currency: string;
  isForSale: boolean;
  artistName: string;
  artistEmail: string;
  artistPhone: string;
  preferredContact: 'email' | 'phone' | 'direct_message';
  image: string;
}
