import React, { useState } from 'react';
import { 
  CheckCircle2, 
  Upload, 
  Sparkles, 
  Award, 
  ArrowRight, 
  Layers, 
  Clock, 
  HelpCircle,
  FileImage,
  RefreshCw,
  ChevronRight,
  ShieldCheck,
  Check
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { PracticeTask, DifficultyLevel } from '../types';
import { PRACTICE_TASKS_DATA } from '../data/tasksData';

interface PracticeSystemProps {
  categoryId: string;
  onSaveToPortfolio?: (taskTitle: string, image: string) => void;
}

export const PracticeSystem: React.FC<PracticeSystemProps> = ({
  categoryId,
  onSaveToPortfolio
}) => {
  const [selectedTaskId, setSelectedTaskId] = useState<string>(PRACTICE_TASKS_DATA[0].id);
  const [uploadedImages, setUploadedImages] = useState<Record<string, string>>({});
  const [completedTaskIds, setCompletedTaskIds] = useState<string[]>([]);
  const [activeFeedback, setActiveFeedback] = useState<Record<string, { status: string; comments: string[] }>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);

  const currentTask = PRACTICE_TASKS_DATA.find(t => t.id === selectedTaskId) || PRACTICE_TASKS_DATA[0];

  const levels: { level: DifficultyLevel; label: string; desc: string }[] = [
    { level: 'Beginner', label: 'FOUNDATIONS', desc: 'Shape decomposition & proportions' },
    { level: 'Intermediate', label: 'TONAL DEPTH', desc: 'Chiaroscuro & value planes' },
    { level: 'Advanced', label: 'ATMOSPHERE', desc: 'Atmospheric perspective & color' },
    { level: 'Portfolio Ready', label: 'ATELIER MASTER', desc: 'Original masterwork composition' }
  ];

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        const resultUrl = event.target?.result as string;
        setUploadedImages(prev => ({ ...prev, [currentTask.id]: resultUrl }));
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSimulateSampleUpload = () => {
    const sampleImgs = [
      'https://images.unsplash.com/photo-1544717305-2782549b5136?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1579783902614-a3fb3927b675?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1541701494587-cb58502866ab?auto=format&fit=crop&w=800&q=80'
    ];
    const chosen = sampleImgs[(currentTask.taskNumber - 1) % sampleImgs.length];
    setUploadedImages(prev => ({ ...prev, [currentTask.id]: chosen }));
  };

  const handleSubmitForReview = () => {
    if (!uploadedImages[currentTask.id]) return;

    setIsSubmitting(true);
    setTimeout(() => {
      setIsSubmitting(false);
      
      const feedbackPack: Record<number, string[]> = {
        1: [
          'Excellent construction lines — the foundational geometry is clearly visible and balanced.',
          'Outer proportion envelope matches the master reference accurately.',
          'Ready for the next challenge: Advance to light and tonal value studies.'
        ],
        2: [
          'Strong separation between light and shadow planes with convincing form.',
          'Subtle reflected light underneath provides convincing 3D volume.',
          'Ready for the next challenge: Integrate atmospheric color temperature.'
        ],
        3: [
          'Clear 3-tier atmospheric depth with warm foreground and receding cool background.',
          'Edge control along focal contours feels crisp and dynamic.',
          'Ready for the next challenge: Create your original studio composition.'
        ],
        4: [
          'Distinctive creative voice with compelling focal hierarchy.',
          'Exhibition-ready polish and confident mark-making.',
          'Artwork is ready to add directly to your Public Portfolio.'
        ]
      };

      setActiveFeedback(prev => ({
        ...prev,
        [currentTask.id]: {
          status: 'Ready for the next challenge',
          comments: feedbackPack[currentTask.taskNumber] || ['Great effort and execution. Ready for the next challenge!']
        }
      }));

      if (!completedTaskIds.includes(currentTask.id)) {
        setCompletedTaskIds(prev => [...prev, currentTask.id]);
        confetti({
          particleCount: 80,
          spread: 60,
          origin: { y: 0.7 }
        });
      }
    }, 800);
  };

  return (
    <div className="w-full max-w-5xl mx-auto px-4 py-8 animate-in fade-in duration-300 bg-[#FAF8F5] text-[#2D2926]">
      
      {/* Header */}
      <div className="text-center max-w-2xl mx-auto mb-10">
        <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-[#FAF2F0] border border-[#EFE6D5] text-[#2D2926] text-xs font-sans font-semibold uppercase tracking-widest mb-3">
          <Sparkles className="w-3.5 h-3.5 text-[#C5A059]" />
          <span>Interactive Atelier Studio</span>
        </div>
        <h2 className="text-3xl sm:text-5xl font-bodoni font-normal text-[#2D2926] tracking-tight">
          Create With Me <span className="font-serif italic font-light text-2xl sm:text-4xl text-[#7D7571]">& Studio Practice</span>
        </h2>
        <p className="text-xs sm:text-sm text-[#7D7571] font-sans mt-2 leading-relaxed">
          Transition from theoretical study to physical mastery. Complete progressive atelier challenges and build your fine-art portfolio.
        </p>
      </div>

      {/* Progression Ladder */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-8 font-sans">
        {levels.map((lvl, index) => {
          const taskForLevel = PRACTICE_TASKS_DATA[index];
          const isSelected = selectedTaskId === taskForLevel?.id;
          const isDone = completedTaskIds.includes(taskForLevel?.id);

          return (
            <button
              key={lvl.level}
              id={`practice-level-tab-${lvl.level.toLowerCase().replace(/\s+/g, '-')}`}
              onClick={() => setSelectedTaskId(taskForLevel.id)}
              className={`p-4 rounded-xl text-left border transition-all duration-200 relative overflow-hidden ${
                isSelected
                  ? 'border-[#C5A059] bg-[#FFFFFF] shadow-[0_4px_16px_rgba(197,160,89,0.12)]'
                  : isDone
                  ? 'border-[#C5A059]/40 bg-[#FAF2F0]/40'
                  : 'border-[#EFE8DE] bg-[#FFFFFF] hover:border-[#C5A059]'
              }`}
            >
              <div className="flex items-center justify-between text-xs font-semibold mb-1">
                <span className={isSelected ? 'text-[#C5A059]' : 'text-[#7D7571]'}>
                  Stage {index + 1}
                </span>
                {isDone ? (
                  <span className="flex items-center gap-1 text-[10px] font-semibold text-[#C5A059] bg-[#FAF2F0] px-2 py-0.5 rounded-full border border-[#EFE6D5]">
                    <Check className="w-3 h-3" /> Mastered
                  </span>
                ) : (
                  <span className="text-[10px] text-[#7D7571]">Stage {index + 1}/4</span>
                )}
              </div>
              <div className="font-serif font-bold text-xs sm:text-sm text-[#2D2926] truncate">
                {lvl.label}
              </div>
              <div className="text-[11px] text-[#7D7571] truncate mt-0.5 font-sans">
                {lvl.desc}
              </div>
            </button>
          );
        })}
      </div>

      {/* Main Task Workbench Card */}
      <div className="bg-[#FFFFFF] rounded-2xl border border-[#EFE8DE] p-6 sm:p-9 shadow-[0_4px_24px_rgba(45,41,38,0.03)] mb-6">
        
        {/* Task Title & Badges */}
        <div className="flex flex-wrap items-center justify-between gap-3 pb-6 border-b border-[#EFE8DE]">
          <div>
            <div className="flex items-center gap-2 mb-1.5 font-sans">
              <span className="px-3 py-0.5 rounded-full bg-[#C5A059] text-[#2D2926] text-[11px] font-semibold">
                Challenge {currentTask.taskNumber} of 4
              </span>
              <span className="px-2.5 py-0.5 rounded-full bg-[#FAF2F0] border border-[#EFE6D5] text-[#2D2926] text-[11px] font-semibold">
                {currentTask.level}
              </span>
              <span className="flex items-center gap-1 text-xs text-[#7D7571] font-medium">
                <Clock className="w-3.5 h-3.5 text-[#C5A059]" />
                ~{currentTask.estimatedMinutes} mins
              </span>
            </div>
            <h3 className="text-2xl sm:text-3xl font-serif font-bold text-[#2D2926]">
              {currentTask.title}
            </h3>
          </div>
        </div>

        {/* 2-Column Task Instructions & Reference */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-7 my-7">
          
          {/* Left: Step Instructions & Criteria */}
          <div className="lg:col-span-7 space-y-5 font-sans">
            
            {/* Action Instructions */}
            <div>
              <h4 className="text-xs font-semibold uppercase tracking-[0.2em] text-[#7D7571] mb-3">
                Atelier Exercise Steps
              </h4>
              <ol className="space-y-2.5">
                {currentTask.instructions.map((inst, i) => (
                  <li key={i} className="flex items-start gap-2.5 text-xs sm:text-sm text-[#2D2926] leading-relaxed">
                    <span className="w-5 h-5 rounded-full bg-[#FAF2F0] border border-[#EFE6D5] text-[#C5A059] text-xs font-serif font-bold flex items-center justify-center shrink-0 mt-0.5">
                      {i + 1}
                    </span>
                    <span>{inst}</span>
                  </li>
                ))}
              </ol>
            </div>

            {/* Materials List */}
            <div className="p-4 rounded-xl bg-[#FAF8F5] border border-[#EFE8DE]">
              <h4 className="text-xs font-semibold uppercase tracking-[0.2em] text-[#7D7571] mb-2">
                Recommended Mediums
              </h4>
              <div className="flex flex-wrap gap-2">
                {currentTask.materials.map((m, i) => (
                  <span key={i} className="px-3 py-1 rounded-lg bg-[#FFFFFF] border border-[#EFE8DE] text-xs text-[#2D2926] font-medium">
                    {m}
                  </span>
                ))}
              </div>
            </div>

            {/* Mentor Tip */}
            <div className="p-4 rounded-xl bg-[#FAF2F0] border border-[#EFE6D5] text-[#2D2926] text-xs flex items-start gap-2.5">
              <Sparkles className="w-4 h-4 text-[#C5A059] shrink-0 mt-0.5" />
              <div>
                <span className="font-semibold text-[#2D2926]">Master Insight: </span>
                <span className="text-[#57514D]">{currentTask.mentorTip}</span>
              </div>
            </div>
          </div>

          {/* Right: Visual Reference & Upload result */}
          <div className="lg:col-span-5 space-y-4 font-sans">
            
            {/* Reference Image */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <h4 className="text-xs font-semibold uppercase tracking-[0.2em] text-[#7D7571]">
                  Master Reference
                </h4>
              </div>
              <div className="relative w-full aspect-4/3 rounded-xl overflow-hidden bg-[#FAF2F0] border border-[#EFE8DE]">
                <img 
                  src={currentTask.referenceImage} 
                  alt={currentTask.title} 
                  className="w-full h-full object-cover"
                />
                <div className="absolute bottom-2 right-2 px-2.5 py-1 rounded-full bg-[#FAF8F5]/90 backdrop-blur-md border border-[#EFE6D5] text-[#2D2926] text-[10px] font-semibold">
                  Study Guide
                </div>
              </div>
            </div>

            {/* Upload Result Area */}
            <div className="border-2 border-dashed border-[#EFE8DE] rounded-xl p-4 text-center bg-[#FAF8F5]">
              {uploadedImages[currentTask.id] ? (
                <div>
                  <div className="relative w-full h-36 rounded-lg overflow-hidden mb-2 bg-[#FAF2F0] border border-[#EFE8DE]">
                    <img 
                      src={uploadedImages[currentTask.id]} 
                      alt="Your submission" 
                      className="w-full h-full object-contain"
                    />
                    <button
                      onClick={() => setUploadedImages(prev => ({ ...prev, [currentTask.id]: '' }))}
                      className="absolute top-2 right-2 px-2.5 py-1 rounded-full bg-[#2D2926]/70 text-white text-[10px] hover:bg-[#2D2926]"
                    >
                      Change
                    </button>
                  </div>
                  <div className="text-xs font-semibold text-[#C5A059] flex items-center justify-center gap-1.5">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    Artwork Uploaded Successfully
                  </div>
                </div>
              ) : (
                <div>
                  <Upload className="w-6 h-6 text-[#C5A059] mx-auto mb-1.5" />
                  <p className="text-xs font-semibold text-[#2D2926]">
                    Upload your completed study
                  </p>
                  <p className="text-[11px] text-[#7D7571] mt-0.5 mb-3">
                    PNG, JPG or photograph of your sketchbook / canvas
                  </p>
                  
                  <div className="flex items-center justify-center gap-2">
                    <label className="cursor-pointer px-4 py-1.5 rounded-full bg-[#C5A059] hover:bg-[#B38E46] text-[#2D2926] text-xs font-semibold shadow-2xs">
                      <span>Choose File</span>
                      <input 
                        type="file" 
                        accept="image/*" 
                        onChange={handleFileUpload} 
                        className="hidden" 
                      />
                    </label>
                    <button
                      onClick={handleSimulateSampleUpload}
                      className="px-3.5 py-1.5 rounded-full bg-[#FAF2F0] border border-[#EFE6D5] text-[#2D2926] text-xs font-medium hover:bg-[#FAF8F5]"
                    >
                      Load Sample Study
                    </button>
                  </div>
                </div>
              )}
            </div>

            {/* Submit for Review */}
            {uploadedImages[currentTask.id] && (
              <button
                id="submit-task-for-review-button"
                disabled={isSubmitting}
                onClick={handleSubmitForReview}
                className="w-full flex items-center justify-center gap-2 py-3 rounded-full bg-[#C5A059] hover:bg-[#B38E46] text-[#2D2926] text-xs font-semibold uppercase tracking-wider shadow-sm transition-all"
              >
                {isSubmitting ? (
                  <RefreshCw className="w-4 h-4 animate-spin" />
                ) : (
                  <ShieldCheck className="w-4 h-4" />
                )}
                <span>{isSubmitting ? 'Analyzing Brushwork...' : 'Request Master Critique & Advance'}</span>
              </button>
            )}
          </div>
        </div>

        {/* Feedback Section */}
        {activeFeedback[currentTask.id] && (
          <div className="mt-6 p-5 rounded-2xl bg-[#FAF2F0] border border-[#EFE6D5] animate-in fade-in duration-200 font-sans">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                <Award className="w-5 h-5 text-[#C5A059]" />
                <h4 className="font-serif font-bold text-base text-[#2D2926]">
                  Master Evaluation: {activeFeedback[currentTask.id].status}
                </h4>
              </div>
              <span className="text-[11px] text-[#7D7571] italic">
                *Constructive guidance for your atelier journey
              </span>
            </div>

            <ul className="space-y-2 mt-3">
              {activeFeedback[currentTask.id].comments.map((c, i) => (
                <li key={i} className="flex items-start gap-2 text-xs text-[#2D2926]">
                  <span className="text-[#C5A059] font-bold">✓</span>
                  <span>{c}</span>
                </li>
              ))}
            </ul>

            {/* Advance to next task if available */}
            {currentTask.taskNumber < 4 && (
              <div className="mt-5 pt-3 border-t border-[#EFE6D5] flex justify-end">
                <button
                  onClick={() => {
                    const next = PRACTICE_TASKS_DATA[currentTask.taskNumber];
                    if (next) setSelectedTaskId(next.id);
                  }}
                  className="inline-flex items-center gap-1.5 px-5 py-2 rounded-full bg-[#C5A059] hover:bg-[#B38E46] text-[#2D2926] text-xs font-semibold uppercase tracking-wider transition-all shadow-2xs"
                >
                  <span>Advance to Stage {currentTask.taskNumber + 1}</span>
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
