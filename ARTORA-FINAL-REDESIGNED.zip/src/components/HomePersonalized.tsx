import React from 'react';
import { 
  Sparkles, 
  BookOpen, 
  PlusCircle, 
  Music, 
  MapPin, 
  ShoppingBag, 
  ArrowRight, 
  Clock, 
  Layers, 
  Play, 
  Zap, 
  Award, 
  Heart,
  ChevronRight
} from 'lucide-react';
import { MainMode, ArtCategory, Tutorial, Artwork } from '../types';
import { TUTORIALS_DATA, getTutorialsForCategory } from '../data/tutorialsData';
import { ARTWORKS_DATA } from '../data/artworksData';
import { ART_EVENTS_DATA } from '../data/eventsData';

interface HomePersonalizedProps {
  onSelectMode: (mode: MainMode) => void;
  activeCategory: ArtCategory;
  onSelectCategory: (category: ArtCategory) => void;
  onOpenTutorial: (tutorial: Tutorial) => void;
  onOpenIdeaGenerator: () => void;
  onOpenContestPrep: () => void;
  savedTutorialIds: string[];
}

export const HomePersonalized: React.FC<HomePersonalizedProps> = ({
  onSelectMode,
  activeCategory,
  onSelectCategory,
  onOpenTutorial,
  onOpenIdeaGenerator,
  onOpenContestPrep,
  savedTutorialIds
}) => {
  const getGreeting = () => {
    const hour = new Date().getHours();
    if (hour < 12) return 'Good morning';
    if (hour < 18) return 'Good afternoon';
    return 'Good evening';
  };

  const categoryTutorials = getTutorialsForCategory(activeCategory);
  const featuredTutorial = categoryTutorials[0] || TUTORIALS_DATA[0];
  const trendingArt = ARTWORKS_DATA.slice(0, 3);
  const nearbyEvents = ART_EVENTS_DATA.slice(0, 2);

  return (
    <div className="w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-12 animate-in fade-in duration-300 bg-[#FAF8F5] text-[#2D2926]">
      
      {/* Personalized Welcome Header Banner — Pale Blush Pink & Gold Accents */}
      <div className="relative rounded-3xl overflow-hidden bg-[#FAF2F0] p-8 sm:p-12 border border-[#EFE6D5] shadow-[0_4px_24px_rgba(197,160,89,0.06)]">
        <div className="relative z-10 max-w-3xl">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#FFFFFF] text-[#2D2926] text-[11px] font-sans font-medium tracking-[0.2em] uppercase mb-4 border border-[#EFE8DE] shadow-2xs">
            <span className="w-2 h-2 rounded-full bg-[#C5A059]" />
            <span>Curated Creative Sanctuary</span>
          </div>

          <h1 className="text-3xl sm:text-5xl font-bodoni font-normal tracking-tight text-[#2D2926]">
            {getGreeting()}, <span className="font-semibold italic font-serif">Alex</span>
          </h1>
          <p className="text-sm sm:text-base text-[#7D7571] mt-3 font-sans font-normal leading-relaxed">
            Welcome to your contemporary creative space. Your active atelier medium is <strong className="font-semibold text-[#2D2926] underline decoration-[#C5A059] decoration-2 underline-offset-4">{activeCategory.name}</strong>.
          </p>

          {/* Quick Action Navigation Buttons */}
          <div className="flex flex-wrap items-center gap-3 mt-8">
            <button
              id="home-start-tutorial-btn"
              onClick={() => onOpenTutorial(featuredTutorial)}
              className="flex items-center gap-2 px-5 py-2.5 rounded-full bg-[#C5A059] hover:bg-[#B38E46] text-[#2D2926] text-xs font-sans font-semibold tracking-wider uppercase shadow-[0_2px_10px_rgba(197,160,89,0.25)] transition-all"
            >
              <BookOpen className="w-3.5 h-3.5" />
              <span>Start Masterclass</span>
            </button>

            <button
              id="home-pitch-art-btn"
              onClick={() => onSelectMode('pitch')}
              className="flex items-center gap-2 px-4 py-2.5 rounded-full bg-[#FFFFFF] hover:bg-[#FAF8F5] text-[#2D2926] text-xs font-sans font-medium border border-[#EFE8DE] hover:border-[#C5A059] transition-all shadow-2xs"
            >
              <PlusCircle className="w-3.5 h-3.5 text-[#C5A059]" />
              <span>Pitch Artwork</span>
            </button>

            <button
              id="home-explore-music-btn"
              onClick={() => onSelectMode('music')}
              className="flex items-center gap-2 px-4 py-2.5 rounded-full bg-[#FFFFFF] hover:bg-[#FAF8F5] text-[#2D2926] text-xs font-sans font-medium border border-[#EFE8DE] hover:border-[#C5A059] transition-all shadow-2xs"
            >
              <Music className="w-3.5 h-3.5 text-[#C5A059]" />
              <span>Atelier Soundscape</span>
            </button>

            <button
              id="home-find-events-btn"
              onClick={() => onSelectMode('events')}
              className="flex items-center gap-2 px-4 py-2.5 rounded-full bg-[#FFFFFF] hover:bg-[#FAF8F5] text-[#2D2926] text-xs font-sans font-medium border border-[#EFE8DE] hover:border-[#C5A059] transition-all shadow-2xs"
            >
              <MapPin className="w-3.5 h-3.5 text-[#C5A059]" />
              <span>Exhibitions</span>
            </button>
          </div>
        </div>
      </div>

      {/* SECTION 1: Continue Learning & Recommended Masterclasses */}
      <section>
        <div className="flex items-center justify-between mb-6 pb-2 border-b border-[#EFE8DE]">
          <div>
            <h2 className="text-2xl sm:text-3xl font-serif font-bold text-[#2D2926]">
              Continue Learning & Atelier
            </h2>
            <p className="text-xs sm:text-sm text-[#7D7571] font-sans mt-0.5">Pick up where you left off or begin a new structured masterclass.</p>
          </div>
          <button
            onClick={() => onSelectMode('learn')}
            className="text-xs font-sans font-semibold text-[#C5A059] hover:text-[#B38E46] flex items-center gap-1 uppercase tracking-wider"
          >
            <span>All Tutorials</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {categoryTutorials.slice(0, 2).map((tut) => (
            <div 
              key={tut.id}
              onClick={() => onOpenTutorial(tut)}
              className="group bg-[#FFFFFF] rounded-2xl p-6 border border-[#EFE8DE] hover:border-[#C5A059] shadow-[0_4px_20px_rgba(45,41,38,0.02)] hover:shadow-[0_8px_24px_rgba(197,160,89,0.08)] transition-all cursor-pointer flex flex-col sm:flex-row gap-5 items-center"
            >
              <img 
                src={tut.coverImage} 
                alt="" 
                className="w-full sm:w-40 aspect-4/3 rounded-xl object-cover shrink-0 group-hover:scale-105 transition-transform border border-[#EFE8DE]"
              />
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-2">
                  <span className="px-2.5 py-0.5 rounded-full bg-[#FAF2F0] text-[#2D2926] text-[10px] font-sans font-medium uppercase tracking-wider border border-[#EFE6D5]">
                    {tut.difficulty}
                  </span>
                  <span className="text-[11px] text-[#7D7571] font-sans flex items-center gap-1">
                    <Clock className="w-3 h-3 text-[#C5A059]" /> {tut.durationMinutes} mins
                  </span>
                </div>
                <h3 className="font-serif font-bold text-lg text-[#2D2926] group-hover:text-[#C5A059] transition-colors truncate">
                  {tut.title}
                </h3>
                <p className="text-xs text-[#7D7571] font-sans line-clamp-2 mt-1 leading-relaxed">
                  {tut.subtitle}
                </p>
                <div className="mt-4 flex items-center gap-1 text-xs font-sans font-semibold uppercase tracking-wider text-[#C5A059]">
                  <span>Resume Masterclass</span>
                  <ArrowRight className="w-3.5 h-3.5 transition-transform group-hover:translate-x-1" />
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* SECTION 2: Daily Creative Studio Inspiration */}
      <section className="grid grid-cols-1 md:grid-cols-2 gap-6">
        
        {/* Challenge Box */}
        <div className="p-7 rounded-2xl bg-[#FFFFFF] border border-[#EFE8DE] shadow-[0_4px_20px_rgba(45,41,38,0.02)] flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-2 mb-3">
              <Zap className="w-4 h-4 text-[#C5A059]" />
              <span className="text-xs font-sans font-semibold uppercase tracking-[0.2em] text-[#7D7571]">7-Day Studio Sprint</span>
            </div>
            <h3 className="text-xl font-serif font-bold text-[#2D2926]">
              Expressive Portrait & Form Sprint
            </h3>
            <p className="text-xs sm:text-sm text-[#7D7571] font-sans mt-2 leading-relaxed">
              Step-by-step guidance from tonal mapping and gesture sketches to exhibition-ready submission.
            </p>
          </div>
          <button
            onClick={onOpenContestPrep}
            className="mt-6 inline-flex items-center gap-2 text-xs font-sans font-semibold text-[#2D2926] hover:text-[#C5A059] uppercase tracking-wider"
          >
            <span>Open Sprint Guide</span>
            <ArrowRight className="w-3.5 h-3.5 text-[#C5A059]" />
          </button>
        </div>

        {/* Idea Prompt Box */}
        <div className="p-7 rounded-2xl bg-[#FAF2F0] border border-[#EFE6D5] shadow-[0_4px_20px_rgba(197,160,89,0.04)] flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-2 mb-3">
              <Sparkles className="w-4 h-4 text-[#C5A059]" />
              <span className="text-xs font-sans font-semibold uppercase tracking-[0.2em] text-[#7D7571]">AI Idea Generator</span>
            </div>
            <h3 className="text-xl font-serif font-bold text-[#2D2926]">
              Curated Concept Generator
            </h3>
            <p className="text-xs sm:text-sm text-[#7D7571] font-sans mt-2 leading-relaxed">
              Synthesize museum-grade palette harmonies, poetic themes, and innovative mixed-media prompts.
            </p>
          </div>
          <button
            onClick={onOpenIdeaGenerator}
            className="mt-6 inline-flex items-center gap-2 text-xs font-sans font-semibold text-[#2D2926] hover:text-[#C5A059] uppercase tracking-wider"
          >
            <span>Generate Art Concepts</span>
            <ArrowRight className="w-3.5 h-3.5 text-[#C5A059]" />
          </button>
        </div>

      </section>

      {/* SECTION 3: Trending Fine Artworks */}
      <section>
        <div className="flex items-center justify-between mb-6 pb-2 border-b border-[#EFE8DE]">
          <div>
            <h2 className="text-2xl sm:text-3xl font-serif font-bold text-[#2D2926]">
              Trending in the Gallery
            </h2>
            <p className="text-xs sm:text-sm text-[#7D7571] font-sans mt-0.5">Inspiring pieces published recently by community masters and artists.</p>
          </div>
          <button
            onClick={() => onSelectMode('discover')}
            className="text-xs font-sans font-semibold text-[#C5A059] hover:text-[#B38E46] flex items-center gap-1 uppercase tracking-wider"
          >
            <span>Explore Feed</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
          {trendingArt.map((art) => (
            <div 
              key={art.id}
              onClick={() => onSelectMode('discover')}
              className="group bg-[#FFFFFF] rounded-2xl border border-[#EFE8DE] overflow-hidden shadow-[0_4px_20px_rgba(45,41,38,0.02)] hover:border-[#C5A059] hover:shadow-[0_8px_24px_rgba(197,160,89,0.08)] transition-all cursor-pointer"
            >
              <div className="aspect-4/3 overflow-hidden bg-[#FAF2F0]">
                <img src={art.image} alt="" className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
              </div>
              <div className="p-5">
                <h4 className="font-serif font-bold text-base text-[#2D2926] truncate">{art.title}</h4>
                <div className="text-xs text-[#7D7571] font-sans mt-1">by {art.artistName} • <span className="text-[#C5A059] font-medium">{art.artForm}</span></div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* SECTION 4: Nearby Exhibitions & Events */}
      <section>
        <div className="flex items-center justify-between mb-6 pb-2 border-b border-[#EFE8DE]">
          <div>
            <h2 className="text-2xl sm:text-3xl font-serif font-bold text-[#2D2926]">
              Upcoming Fine Art Exhibitions
            </h2>
            <p className="text-xs sm:text-sm text-[#7D7571] font-sans mt-0.5">Local gallery openings, symposiums, and fine craft fairs.</p>
          </div>
          <button
            onClick={() => onSelectMode('events')}
            className="text-xs font-sans font-semibold text-[#C5A059] hover:text-[#B38E46] flex items-center gap-1 uppercase tracking-wider"
          >
            <span>City Map</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          {nearbyEvents.map((evt) => (
            <div 
              key={evt.id}
              onClick={() => onSelectMode('events')}
              className="p-5 rounded-2xl bg-[#FFFFFF] border border-[#EFE8DE] shadow-[0_4px_20px_rgba(45,41,38,0.02)] hover:border-[#C5A059] transition-all cursor-pointer flex items-center gap-4"
            >
              <img src={evt.image} alt="" className="w-20 h-20 rounded-xl object-cover shrink-0 border border-[#EFE8DE]" />
              <div className="flex-1 min-w-0">
                <span className="text-[10px] font-sans font-bold text-[#C5A059] uppercase tracking-wider">{evt.type}</span>
                <h4 className="font-serif font-bold text-base text-[#2D2926] truncate">{evt.title}</h4>
                <p className="text-xs text-[#7D7571] font-sans mt-0.5 truncate">{evt.venue} • {evt.dateStr}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

    </div>
  );
};
