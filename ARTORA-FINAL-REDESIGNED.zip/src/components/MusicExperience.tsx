import React, { useState, useEffect } from 'react';
import { 
  Play, 
  Pause, 
  Music, 
  Disc, 
  Radio, 
  Volume2, 
  Sparkles, 
  Bookmark, 
  Clock, 
  BookOpen, 
  Users, 
  Sliders, 
  Activity,
  CheckCircle2,
  Share2,
  ExternalLink
} from 'lucide-react';
import { MusicGenreInfo, MusicTrack, MusicTab } from '../types';
import { MUSIC_GENRES_DATA, MUSIC_ALL_GENRE_NAMES } from '../data/musicData';
import { audioSynth } from '../utils/audioSynthesizer';

interface MusicExperienceProps {
  initialGenre?: string;
  savedTrackIds: string[];
  onToggleSaveTrack: (id: string) => void;
  onActiveTrackChange?: (track: MusicTrack | null) => void;
}

export const MusicExperience: React.FC<MusicExperienceProps> = ({
  initialGenre = 'jazz',
  savedTrackIds,
  onToggleSaveTrack,
  onActiveTrackChange
}) => {
  const [selectedGenreKey, setSelectedGenreKey] = useState<string>(initialGenre);
  const [activeTab, setActiveTab] = useState<MusicTab>('overview');
  const [playingTrackId, setPlayingTrackId] = useState<string | null>(null);
  const [trackProgress, setTrackProgress] = useState(0);

  const currentGenre: MusicGenreInfo = MUSIC_GENRES_DATA[selectedGenreKey] || MUSIC_GENRES_DATA['jazz'];

  useEffect(() => {
    audioSynth.setTimeUpdateListener((currentTime, isPlaying) => {
      setTrackProgress(currentTime);
      if (!isPlaying) {
        setPlayingTrackId(null);
      }
    });

    return () => {
      audioSynth.stop();
    };
  }, []);

  const handlePlayTrack = (track: MusicTrack) => {
    if (playingTrackId === track.id) {
      if (audioSynth.isCurrentlyPlaying()) {
        audioSynth.pause();
      } else {
        audioSynth.resume();
      }
    } else {
      setPlayingTrackId(track.id);
      audioSynth.playPreset(track.audioPreset, track.duration);
      if (onActiveTrackChange) onActiveTrackChange(track);
    }
  };

  const tabs: { id: MusicTab; label: string; icon: React.ComponentType<{ className?: string }> }[] = [
    { id: 'overview', label: 'OVERVIEW', icon: Sparkles },
    { id: 'music', label: 'MUSIC SAMPLES', icon: Music },
    { id: 'artists', label: 'ARTISTS', icon: Users },
    { id: 'instruments', label: 'INSTRUMENTS', icon: Sliders },
    { id: 'learn', label: 'LEARN & THEORY', icon: BookOpen }
  ];

  return (
    <div className="w-full max-w-6xl mx-auto px-4 py-8 animate-in fade-in duration-300 bg-[#FAF8F5] text-[#2D2926]">
      
      {/* Top Welcome & Genre Question */}
      <div className="text-center max-w-2xl mx-auto mb-8">
        <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-[#FAF2F0] border border-[#EFE6D5] text-[#2D2926] text-xs font-sans font-semibold uppercase tracking-widest mb-3">
          <Music className="w-3.5 h-3.5 text-[#C5A059]" />
          <span>Acoustic & Sonic Conservatory</span>
        </div>
        <h2 className="text-3xl sm:text-5xl font-bodoni font-normal text-[#2D2926] tracking-tight">
          What music inspires your canvas?
        </h2>
        <p className="text-xs sm:text-sm text-[#7D7571] font-sans mt-2 leading-relaxed">
          Explore acoustic lineages, master musicians, historical theory guides, and real-time synthesized audio scores.
        </p>
      </div>

      {/* Genre Selector Pills */}
      <div className="flex items-center gap-2 overflow-x-auto no-scrollbar py-2 mb-8 scroll-smooth font-sans">
        {MUSIC_ALL_GENRE_NAMES.map((name) => {
          const key = name.toLowerCase().replace(/[\s-]+/g, '_');
          const isSelected = key === selectedGenreKey || (key === 'jazz' && selectedGenreKey === 'jazz') || (key === 'classical' && selectedGenreKey === 'classical');

          return (
            <button
              key={name}
              id={`music-genre-pill-${name.toLowerCase().replace(/\s+/g, '-')}`}
              onClick={() => {
                const mappedKey = MUSIC_GENRES_DATA[name.toLowerCase()] ? name.toLowerCase() : 'jazz';
                setSelectedGenreKey(mappedKey);
              }}
              className={`px-4 py-2 rounded-full text-xs font-semibold whitespace-nowrap transition-all duration-200 shrink-0 border ${
                isSelected
                  ? 'bg-[#C5A059] text-[#2D2926] border-[#C5A059] shadow-2xs'
                  : 'bg-[#FFFFFF] text-[#7D7571] border-[#EFE8DE] hover:bg-[#FAF2F0]'
              }`}
            >
              <span>{name}</span>
              {isSelected && <span className="ml-1.5 inline-block w-1.5 h-1.5 rounded-full bg-[#2D2926]" />}
            </button>
          );
        })}
      </div>

      {/* Selected Genre Banner Card */}
      <div className="relative rounded-2xl overflow-hidden mb-8 border border-[#EFE8DE] shadow-sm bg-[#2D2926] text-white min-h-[220px] flex items-end">
        <img 
          src={currentGenre.coverImage} 
          alt={currentGenre.name} 
          className="absolute inset-0 w-full h-full object-cover opacity-40"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-[#2D2926] via-[#2D2926]/60 to-transparent" />

        <div className="relative z-10 p-6 sm:p-8 w-full flex flex-col md:flex-row md:items-end justify-between gap-4 font-sans">
          <div>
            <span className="px-3 py-0.5 rounded-full bg-[#C5A059] text-[#2D2926] text-xs font-semibold uppercase tracking-wider mb-2 inline-block">
              Sonic Journey
            </span>
            <h1 className="text-3xl sm:text-4xl font-serif font-bold text-white tracking-tight">
              {currentGenre.name}
            </h1>
            <p className="text-xs sm:text-sm text-[#E0DBD5] mt-1 max-w-xl">
              {currentGenre.tagline}
            </p>
          </div>

          <div className="flex items-center gap-2">
            <span className="px-3 py-1.5 rounded-xl bg-white/10 backdrop-blur-md text-xs font-medium border border-white/15">
              {currentGenre.tracks.length} Master Demos
            </span>
            <span className="px-3 py-1.5 rounded-xl bg-white/10 backdrop-blur-md text-xs font-medium border border-white/15">
              {currentGenre.commonInstruments.length} Instruments
            </span>
          </div>
        </div>
      </div>

      {/* Tabs Navigation */}
      <div className="flex items-center gap-2 border-b border-[#EFE8DE] pb-3 mb-6 overflow-x-auto no-scrollbar font-sans">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              id={`music-tab-${tab.id}`}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-2 px-4 py-2 rounded-full text-xs font-semibold tracking-wider transition-all shrink-0 ${
                isActive
                  ? 'bg-[#C5A059] text-[#2D2926] shadow-2xs'
                  : 'text-[#7D7571] hover:text-[#2D2926] hover:bg-[#FAF2F0]'
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* Tab Content */}
      <div className="bg-[#FFFFFF] rounded-2xl p-6 sm:p-8 border border-[#EFE8DE] shadow-[0_4px_24px_rgba(45,41,38,0.03)] min-h-[360px] font-sans">
        
        {/* OVERVIEW TAB */}
        {activeTab === 'overview' && (
          <div className="space-y-6">
            <div>
              <h3 className="text-xs font-semibold uppercase tracking-[0.2em] text-[#7D7571] mb-2">
                Historical Heritage & Development
              </h3>
              <p className="text-sm sm:text-base text-[#2D2926] leading-relaxed">
                {currentGenre.history}
              </p>
            </div>

            <div>
              <h3 className="text-xs font-semibold uppercase tracking-[0.2em] text-[#7D7571] mb-3">
                Key Sonic Characteristics
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {currentGenre.characteristics.map((char, i) => (
                  <div 
                    key={i} 
                    className="p-4 rounded-xl bg-[#FAF8F5] border border-[#EFE8DE] flex items-start gap-2.5"
                  >
                    <span className="w-2 h-2 rounded-full bg-[#C5A059] shrink-0 mt-1.5" />
                    <span className="text-xs text-[#2D2926] font-medium leading-normal">
                      {char}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            <div>
              <h3 className="text-xs font-semibold uppercase tracking-[0.2em] text-[#7D7571] mb-2">
                Related Traditions
              </h3>
              <div className="flex flex-wrap gap-2">
                {currentGenre.relatedGenres.map((rg, i) => (
                  <span 
                    key={i}
                    className="px-3.5 py-1 rounded-full bg-[#FAF2F0] border border-[#EFE6D5] text-xs font-semibold text-[#2D2926]"
                  >
                    {rg}
                  </span>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* MUSIC SAMPLES TAB */}
        {activeTab === 'music' && (
          <div className="space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-[#EFE8DE]">
              <div>
                <h3 className="font-serif font-bold text-base text-[#2D2926]">
                  Acoustic Audio Samples & Synthesized Studies
                </h3>
                <p className="text-xs text-[#7D7571]">
                  Royalty-free synthesized scores generated in real-time for studio background immersion.
                </p>
              </div>
              <span className="px-3 py-1 rounded-full bg-[#FAF2F0] border border-[#EFE6D5] text-[#C5A059] text-[11px] font-semibold">
                Studio Grade
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
              {currentGenre.tracks.map((track) => {
                const isPlaying = playingTrackId === track.id && audioSynth.isCurrentlyPlaying();
                const isSaved = savedTrackIds.includes(track.id);
                const progressPct = playingTrackId === track.id ? (trackProgress / track.duration) * 100 : 0;

                return (
                  <div
                    key={track.id}
                    id={`track-card-${track.id}`}
                    className={`p-5 rounded-2xl border transition-all duration-200 ${
                      isPlaying 
                        ? 'border-[#C5A059] bg-[#FAF2F0] shadow-sm'
                        : 'border-[#EFE8DE] bg-[#FAF8F5] hover:border-[#C5A059]'
                    }`}
                  >
                    <div className="flex items-start gap-3">
                      <img 
                        src={track.coverImage} 
                        alt={track.title} 
                        className="w-14 h-14 rounded-xl object-cover shrink-0 border border-[#EFE8DE]"
                      />
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between gap-2">
                          <h4 className="font-serif font-bold text-sm text-[#2D2926] truncate">
                            {track.title}
                          </h4>
                          <span className="text-[10px] px-2 py-0.5 rounded-full bg-[#FFFFFF] border border-[#EFE8DE] text-[#7D7571] shrink-0">
                            {track.bpm} BPM
                          </span>
                        </div>
                        <div className="text-xs text-[#7D7571] truncate">
                          {track.artist} • {track.genre}
                        </div>
                        <p className="text-[11px] text-[#57514D] mt-1 line-clamp-2">
                          {track.description}
                        </p>
                      </div>
                    </div>

                    {/* Waveform / Progress bar */}
                    <div className="mt-4">
                      <div className="w-full h-1.5 rounded-full bg-[#EFE8DE] overflow-hidden">
                        <div 
                          className="h-full bg-[#C5A059] rounded-full transition-all duration-200"
                          style={{ width: `${progressPct}%` }}
                        />
                      </div>
                      <div className="flex items-center justify-between text-[10px] text-[#7D7571] mt-1 font-mono">
                        <span>{playingTrackId === track.id ? `${Math.round(trackProgress)}s` : '0s'}</span>
                        <span className="text-[#C5A059] font-sans font-semibold">{track.license}</span>
                        <span>{track.duration}s</span>
                      </div>
                    </div>

                    {/* Controls */}
                    <div className="flex items-center justify-between mt-3 pt-3 border-t border-[#EFE8DE]">
                      <button
                        onClick={() => handlePlayTrack(track)}
                        className={`flex items-center gap-1.5 px-4 py-1.5 rounded-full text-xs font-semibold transition-all ${
                          isPlaying
                            ? 'bg-[#2D2926] text-white'
                            : 'bg-[#C5A059] hover:bg-[#B38E46] text-[#2D2926]'
                        }`}
                      >
                        {isPlaying ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5 fill-current" />}
                        <span>{isPlaying ? 'Pause' : 'Play Score'}</span>
                      </button>

                      <button
                        onClick={() => onToggleSaveTrack(track.id)}
                        className={`p-2 rounded-full text-xs transition-colors ${
                          isSaved 
                            ? 'text-[#C5A059] bg-[#FAF2F0]' 
                            : 'text-[#7D7571] hover:bg-[#FAF2F0]'
                        }`}
                        title="Save to favorites"
                      >
                        <Bookmark className={`w-4 h-4 ${isSaved ? 'fill-[#C5A059]' : ''}`} />
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* ARTISTS TAB */}
        {activeTab === 'artists' && (
          <div className="space-y-4">
            <h3 className="text-xs font-semibold uppercase tracking-[0.2em] text-[#7D7571]">
              Pioneers & Legendary Composers
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              {currentGenre.featuredArtists.map((artist, idx) => (
                <div 
                  key={idx}
                  className="p-5 rounded-2xl bg-[#FAF8F5] border border-[#EFE8DE] text-center"
                >
                  <img 
                    src={artist.image} 
                    alt={artist.name} 
                    className="w-16 h-16 rounded-full object-cover mx-auto mb-2.5 border-2 border-[#C5A059]/40 shadow-xs"
                  />
                  <h4 className="font-serif font-bold text-sm text-[#2D2926]">
                    {artist.name}
                  </h4>
                  <div className="text-[11px] font-semibold text-[#C5A059] mb-1">
                    {artist.era}
                  </div>
                  <p className="text-xs text-[#57514D] leading-relaxed">
                    {artist.description}
                  </p>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* INSTRUMENTS TAB */}
        {activeTab === 'instruments' && (
          <div className="space-y-4">
            <h3 className="text-xs font-semibold uppercase tracking-[0.2em] text-[#7D7571]">
              Acoustic Instruments
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
              {currentGenre.commonInstruments.map((inst, idx) => (
                <div 
                  key={idx}
                  className="p-4 rounded-xl bg-[#FAF8F5] border border-[#EFE8DE] flex items-start gap-3"
                >
                  <img 
                    src={inst.image} 
                    alt={inst.name} 
                    className="w-12 h-12 rounded-lg object-cover shrink-0 border border-[#EFE8DE]"
                  />
                  <div>
                    <h4 className="font-serif font-bold text-sm text-[#2D2926]">
                      {inst.name}
                    </h4>
                    <p className="text-[11px] text-[#7D7571] mt-0.5 leading-snug">
                      {inst.role}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* LEARN & THEORY TAB */}
        {activeTab === 'learn' && (
          <div className="space-y-4">
            <h3 className="text-xs font-semibold uppercase tracking-[0.2em] text-[#7D7571]">
              Musical Theory Guides
            </h3>
            <div className="space-y-3">
              {currentGenre.learningResources.map((res, idx) => (
                <div 
                  key={idx}
                  className="p-4 rounded-xl bg-[#FAF8F5] border border-[#EFE8DE] flex items-center justify-between hover:bg-[#FAF2F0] transition-colors"
                >
                  <div className="flex items-center gap-3.5">
                    <div className="w-8 h-8 rounded-full bg-[#FAF2F0] border border-[#EFE6D5] text-[#C5A059] flex items-center justify-center font-serif font-bold text-xs">
                      {idx + 1}
                    </div>
                    <div>
                      <h4 className="font-serif font-bold text-sm text-[#2D2926]">
                        {res.title}
                      </h4>
                      <div className="text-[11px] text-[#7D7571]">
                        {res.type} • {res.duration}
                      </div>
                    </div>
                  </div>
                  <button className="px-4 py-1.5 rounded-full bg-[#C5A059] hover:bg-[#B38E46] text-[#2D2926] text-xs font-semibold shadow-2xs">
                    Open Guide
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

      </div>
    </div>
  );
};
