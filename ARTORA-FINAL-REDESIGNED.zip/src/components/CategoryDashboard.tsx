import React, { useState } from 'react';
import { 
  Sparkles, 
  BookOpen, 
  Layers, 
  Wrench, 
  CheckCircle2, 
  Users, 
  Award, 
  Calendar, 
  Clock, 
  Play, 
  ChevronRight, 
  Bookmark, 
  Check, 
  ArrowRight,
  ExternalLink
} from 'lucide-react';
import { ArtCategory, Tutorial, CategoryTab, Workshop, Artwork, ArtEvent } from '../types';
import { getTutorialsForCategory } from '../data/tutorialsData';
import { WORKSHOPS_DATA } from '../data/workshopsData';
import { ARTWORKS_DATA } from '../data/artworksData';
import { ART_EVENTS_DATA } from '../data/eventsData';
import { PracticeSystem } from './PracticeSystem';

interface CategoryDashboardProps {
  category: ArtCategory;
  onOpenTutorial: (tutorial: Tutorial) => void;
  onOpenPractice: () => void;
  onOpenContestPrep: () => void;
  onOpenNearbyEvents: () => void;
  onOpenArtists: () => void;
  savedTutorialIds: string[];
  onToggleSaveTutorial: (id: string) => void;
}

export const CategoryDashboard: React.FC<CategoryDashboardProps> = ({
  category,
  onOpenTutorial,
  onOpenPractice,
  onOpenContestPrep,
  onOpenNearbyEvents,
  onOpenArtists,
  savedTutorialIds,
  onToggleSaveTutorial
}) => {
  const [activeTab, setActiveTab] = useState<CategoryTab>('overview');

  const categoryTutorials = getTutorialsForCategory(category);
  const featuredTutorial = categoryTutorials[0];
  const categoryWorkshops = WORKSHOPS_DATA.filter(w => w.categoryId === category.id || category.id === 'painting');
  const categoryArtworks = ARTWORKS_DATA.filter(a => a.categoryId === category.id || category.id === 'painting');
  const categoryEvents = ART_EVENTS_DATA.filter(e => e.artCategory.toLowerCase() === category.name.toLowerCase() || category.id === 'painting');

  const tabs: { id: CategoryTab; label: string; icon: React.ComponentType<{ className?: string }> }[] = [
    { id: 'overview', label: 'OVERVIEW', icon: Sparkles },
    { id: 'tutorials', label: 'TUTORIALS', icon: BookOpen },
    { id: 'types', label: 'TYPES', icon: Layers },
    { id: 'techniques', label: 'TECHNIQUES', icon: Wrench },
    { id: 'practice', label: 'PRACTICE', icon: CheckCircle2 },
    { id: 'workshops', label: 'WORKSHOPS', icon: Users },
    { id: 'professional', label: 'PROFESSIONAL ART', icon: Award },
    { id: 'events', label: 'EVENTS', icon: Calendar }
  ];

  return (
    <div className="w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 animate-in fade-in duration-300 bg-[#FAF8F5] text-[#2D2926]">
      
      {/* Category Header */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-8 pb-6 border-b border-[#EFE8DE]">
        <div>
          <div className="flex items-center gap-2 mb-2">
            <span 
              className="w-2.5 h-2.5 rounded-full ring-2 ring-[#FAF2F0]" 
              style={{ backgroundColor: category.color || '#C5A059' }} 
            />
            <span className="text-xs font-sans font-semibold uppercase tracking-[0.2em] text-[#7D7571]">
              {category.tagline}
            </span>
          </div>
          <h2 className="text-3xl sm:text-5xl font-bodoni font-normal text-[#2D2926] tracking-tight">
            {category.name} <span className="font-serif italic font-light text-2xl sm:text-4xl text-[#7D7571]">Atelier</span>
          </h2>
          <p className="text-xs sm:text-sm text-[#7D7571] font-sans mt-2 max-w-2xl leading-relaxed">
            {category.description || 'Explore master techniques, discover authentic art forms, and follow guided atelier tutorials.'}
          </p>
        </div>

        {/* Segmented Tab Control */}
        <div className="flex gap-1.5 p-1.5 bg-[#FFFFFF] border border-[#EFE8DE] rounded-2xl overflow-x-auto no-scrollbar shrink-0 shadow-[0_2px_8px_rgba(0,0,0,0.02)]">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                id={`cat-tab-${tab.id}`}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-sans font-semibold tracking-wider uppercase transition-all whitespace-nowrap ${
                  isActive
                    ? 'bg-[#FAF2F0] text-[#2D2926] border border-[#EFE6D5] shadow-xs'
                    : 'text-[#7D7571] hover:text-[#2D2926] hover:bg-[#FAF8F5]'
                }`}
              >
                <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-[#C5A059]' : 'text-[#7D7571]'}`} />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Main Layout Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        
        {/* Main Content Area (8 Cols on LG) */}
        <div className="lg:col-span-8 min-h-[400px]">
          
          {/* 1. OVERVIEW TAB */}
          {activeTab === 'overview' && (
            <div className="space-y-8 animate-in fade-in duration-200">
              
              {/* Featured Discipline Hero Card */}
              <div className="group bg-[#FFFFFF] rounded-2xl overflow-hidden border border-[#EFE8DE] shadow-[0_4px_24px_rgba(45,41,38,0.03)] hover:shadow-[0_8px_32px_rgba(197,160,89,0.1)] transition-all">
                <div className="h-60 sm:h-72 relative bg-[#FAF2F0] overflow-hidden">
                  <img 
                    src={category.coverImage} 
                    alt={category.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
                  <div className="absolute top-4 left-4 px-3.5 py-1 bg-[#FAF8F5]/95 backdrop-blur-md border border-[#EFE6D5] rounded-full text-[10px] font-sans font-medium uppercase tracking-widest text-[#2D2926]">
                    Discipline Overview
                  </div>
                  <div className="absolute bottom-4 left-4 right-4 text-white">
                    <h3 className="text-2xl sm:text-3xl font-serif font-bold text-white">
                      The World of {category.name}
                    </h3>
                    <p className="text-xs text-white/90 line-clamp-1 mt-1 font-sans">
                      {category.tagline}
                    </p>
                  </div>
                </div>

                <div className="p-7">
                  <h4 className="text-xs font-sans font-semibold uppercase tracking-[0.2em] text-[#7D7571] mb-2">
                    About this Discipline
                  </h4>
                  <p className="text-sm sm:text-base text-[#2D2926] font-sans leading-relaxed">
                    {category.overview.introduction}
                  </p>

                  <div className="mt-6 pt-6 border-t border-[#EFE8DE]">
                    <h4 className="text-xs font-sans font-semibold uppercase tracking-[0.2em] text-[#C5A059] mb-2">
                      Why {category.name} is Special
                    </h4>
                    <p className="text-xs sm:text-sm text-[#57514D] font-sans leading-relaxed">
                      {category.overview.whySpecial}
                    </p>
                  </div>
                </div>
              </div>

              {/* Starter Checklist & Steps */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                
                {/* Getting Started Steps */}
                <div className="bg-[#FFFFFF] rounded-2xl p-6 border border-[#EFE8DE] shadow-[0_4px_20px_rgba(45,41,38,0.02)]">
                  <h3 className="text-xs font-sans font-semibold uppercase tracking-[0.2em] text-[#7D7571] mb-4">
                    3-Step Progression Path
                  </h3>
                  <div className="space-y-4">
                    <div className="flex items-start gap-3.5">
                      <div className="w-7 h-7 rounded-lg bg-[#FAF2F0] border border-[#EFE6D5] text-[#2D2926] font-serif font-bold text-xs flex items-center justify-center shrink-0">
                        01
                      </div>
                      <div className="text-xs font-sans text-[#57514D]">
                        <strong className="block text-[#2D2926] font-medium">Gather Essential Supplies</strong>
                        Prepare standard starter palette before upgrading specialized tools.
                      </div>
                    </div>
                    <div className="flex items-start gap-3.5">
                      <div className="w-7 h-7 rounded-lg bg-[#FAF2F0] border border-[#EFE6D5] text-[#2D2926] font-serif font-bold text-xs flex items-center justify-center shrink-0">
                        02
                      </div>
                      <div className="text-xs font-sans text-[#57514D]">
                        <strong className="block text-[#2D2926] font-medium">Follow Guided Tutorials</strong>
                        Complete visual step-by-step masterclasses at your own pace.
                      </div>
                    </div>
                    <div className="flex items-start gap-3.5">
                      <div className="w-7 h-7 rounded-lg bg-[#FAF2F0] border border-[#EFE6D5] text-[#2D2926] font-serif font-bold text-xs flex items-center justify-center shrink-0">
                        03
                      </div>
                      <div className="text-xs font-sans text-[#57514D]">
                        <strong className="block text-[#2D2926] font-medium">Practice & Pitch</strong>
                        Complete hands-on studies to build and pitch your fine art portfolio.
                      </div>
                    </div>
                  </div>
                </div>

                {/* Essential Starter Supplies */}
                <div className="bg-[#FFFFFF] rounded-2xl p-6 border border-[#EFE8DE] shadow-[0_4px_20px_rgba(45,41,38,0.02)] flex flex-col justify-between">
                  <div>
                    <h3 className="text-xs font-sans font-semibold uppercase tracking-[0.2em] text-[#7D7571] mb-3 flex items-center justify-between">
                      <span>Starter Supplies</span>
                      <span className="text-[10px] text-[#C5A059] font-bold uppercase">Checklist</span>
                    </h3>
                    <div className="space-y-2">
                      {category.overview.supplies.map((sup, idx) => (
                        <div key={idx} className="flex items-center gap-2.5 text-xs font-sans text-[#2D2926]">
                          <Check className="w-3.5 h-3.5 text-[#C5A059] shrink-0" />
                          <span>{sup}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  <button
                    id="overview-start-first-tutorial-button"
                    onClick={() => onOpenTutorial(featuredTutorial)}
                    className="mt-5 w-full py-3 bg-[#C5A059] hover:bg-[#B38E46] text-[#2D2926] rounded-full text-xs font-sans font-semibold tracking-wider uppercase transition-all shadow-[0_2px_10px_rgba(197,160,89,0.25)] flex items-center justify-center gap-2"
                  >
                    <Play className="w-3.5 h-3.5 fill-current" />
                    <span>Start {featuredTutorial.title.slice(0, 26)}...</span>
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* 2. TUTORIALS TAB */}
          {activeTab === 'tutorials' && (
            <div className="space-y-8 animate-in fade-in duration-200">
              
              {/* Featured Live Masterclass Preview Spotlight */}
              {featuredTutorial && (
                <div className="rounded-2xl border border-[#EFE8DE] bg-[#FFFFFF] p-6 sm:p-7 shadow-[0_4px_20px_rgba(45,41,38,0.03)]">
                  <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
                    <div className="flex items-center gap-2">
                      <span className="px-3 py-1 rounded-full bg-[#FAF2F0] border border-[#EFE6D5] text-[#2D2926] text-[10px] font-sans font-semibold uppercase tracking-wider">
                        Featured Masterclass
                      </span>
                      <span className="text-xs text-[#7D7571] font-sans font-medium">
                        {featuredTutorial.totalSteps} Visual Steps • {featuredTutorial.durationMinutes} Minutes
                      </span>
                    </div>
                    <span className="text-xs font-sans font-bold text-[#C5A059]">
                      {featuredTutorial.difficulty} Level
                    </span>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-center">
                    <div className="md:col-span-6 relative aspect-16/10 rounded-xl overflow-hidden bg-[#FAF2F0] border border-[#EFE8DE]">
                      <img 
                        src={featuredTutorial.coverImage} 
                        alt={featuredTutorial.title} 
                        className="w-full h-full object-cover"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-transparent to-transparent" />
                      <div className="absolute bottom-3 left-3 right-3 flex items-center justify-between text-white text-xs font-sans">
                        <span className="font-medium">{featuredTutorial.creator.name}</span>
                        <span className="px-2 py-0.5 rounded-full bg-white/30 backdrop-blur-md text-[10px] font-semibold">
                          Step 1 of {featuredTutorial.totalSteps}
                        </span>
                      </div>
                    </div>

                    <div className="md:col-span-6 flex flex-col justify-between h-full space-y-4">
                      <div>
                        <h3 className="text-xl sm:text-2xl font-serif font-bold text-[#2D2926] leading-tight">
                          {featuredTutorial.title}
                        </h3>
                        <p className="text-xs sm:text-sm text-[#7D7571] font-sans mt-2 leading-relaxed">
                          {featuredTutorial.subtitle}
                        </p>
                      </div>

                      {/* Step Thumbnails Preview Strip */}
                      <div>
                        <span className="text-[11px] font-sans font-semibold uppercase tracking-wider text-[#7D7571] block mb-2">
                          Step-by-Step Preview Strip:
                        </span>
                        <div className="flex items-center gap-2 overflow-x-auto no-scrollbar py-1">
                          {featuredTutorial.steps.map((st, i) => (
                            <div 
                              key={i} 
                              className="w-12 h-12 rounded-lg overflow-hidden bg-[#FAF2F0] shrink-0 border border-[#EFE8DE] relative group/thumb"
                              title={`Step ${st.stepNumber}: ${st.title}`}
                            >
                              <img src={st.image} alt={st.title} className="w-full h-full object-cover" />
                              <div className="absolute inset-0 bg-black/30 flex items-center justify-center text-white font-bold text-[10px]">
                                {st.stepNumber}
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>

                      <div className="pt-2 flex items-center gap-3">
                        <button
                          id="featured-tutorial-start-now-btn"
                          onClick={() => onOpenTutorial(featuredTutorial)}
                          className="flex-1 py-3 px-5 rounded-full bg-[#C5A059] hover:bg-[#B38E46] text-[#2D2926] text-xs font-sans font-semibold uppercase tracking-wider shadow-[0_2px_10px_rgba(197,160,89,0.25)] transition-all flex items-center justify-center gap-2"
                        >
                          <Play className="w-4 h-4 fill-current" />
                          <span>Open Interactive Tutorial</span>
                        </button>
                        <button
                          onClick={() => onToggleSaveTutorial(featuredTutorial.id)}
                          className="p-3 rounded-full border border-[#EFE8DE] bg-[#FFFFFF] text-[#2D2926] hover:bg-[#FAF2F0] transition-colors"
                          title="Save tutorial"
                        >
                          <Bookmark className={`w-4 h-4 ${savedTutorialIds.includes(featuredTutorial.id) ? 'fill-[#C5A059] text-[#C5A059]' : 'text-[#7D7571]'}`} />
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* All Category Masterclasses Grid */}
              <div>
                <h4 className="text-xs font-sans font-semibold uppercase tracking-[0.2em] text-[#7D7571] mb-5">
                  All {category.name} Masterclasses ({categoryTutorials.length})
                </h4>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {categoryTutorials.map((tut, index) => {
                    const isSaved = savedTutorialIds.includes(tut.id);
                    const progressPct = index === 0 ? 40 : index === 1 ? 0 : 75;
                    const progressLabel = index === 0 ? 'Progress: Step 3 of 8' : index === 1 ? 'Not Started' : 'Progress: Step 6 of 8';

                    return (
                      <div
                        key={tut.id}
                        id={`tutorial-card-${tut.id}`}
                        className="group bg-[#FFFFFF] rounded-2xl overflow-hidden border border-[#EFE8DE] shadow-[0_4px_20px_rgba(45,41,38,0.02)] hover:border-[#C5A059] hover:shadow-[0_8px_24px_rgba(197,160,89,0.08)] transition-all duration-200 flex flex-col justify-between"
                      >
                        <div>
                          {/* Cover Card Image */}
                          <div className="h-48 relative bg-[#FAF2F0] overflow-hidden">
                            <img 
                              src={tut.coverImage} 
                              alt={tut.title} 
                              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                            />
                            <div className="absolute top-3.5 left-3.5 px-3 py-1 bg-[#FAF8F5]/95 backdrop-blur-md border border-[#EFE6D5] rounded-full text-[10px] font-sans font-medium uppercase tracking-widest text-[#2D2926]">
                              {tut.difficulty}
                            </div>
                            <button
                              onClick={() => onToggleSaveTutorial(tut.id)}
                              className="absolute top-3.5 right-3.5 p-2 rounded-full bg-[#FAF8F5]/95 backdrop-blur-md border border-[#EFE6D5] text-[#2D2926] hover:scale-110 transition-transform shadow-sm"
                              title="Save Tutorial"
                            >
                              <Bookmark className={`w-3.5 h-3.5 ${isSaved ? 'fill-[#C5A059] text-[#C5A059]' : 'text-[#7D7571]'}`} />
                            </button>
                          </div>

                          {/* Card Body */}
                          <div className="p-5">
                            <div className="flex justify-between items-start mb-1.5">
                              <h3 className="text-base sm:text-lg font-serif font-bold text-[#2D2926] group-hover:text-[#C5A059] transition-colors">
                                {tut.title}
                              </h3>
                              <span className="text-xs font-sans font-bold text-[#C5A059] shrink-0 ml-2">
                                {tut.durationMinutes} Min
                              </span>
                            </div>

                            <div className="flex items-center gap-2.5 text-xs text-[#7D7571] font-sans mb-4">
                              <span>{tut.totalSteps} Steps</span>
                              <span>•</span>
                              <span>Instructor: {tut.creator.name}</span>
                            </div>

                            {/* Progress Bar */}
                            <div className="w-full bg-[#FAF2F0] h-1.5 rounded-full mb-4 overflow-hidden">
                              <div 
                                className="bg-[#C5A059] h-full rounded-full transition-all duration-300"
                                style={{ width: `${progressPct}%` }}
                              />
                            </div>

                            <div className="flex justify-between items-center">
                              <span className={`text-[10px] font-sans font-semibold uppercase tracking-wider ${progressPct > 0 ? 'text-[#C5A059]' : 'text-[#7D7571]'}`}>
                                {progressLabel}
                              </span>
                              <button
                                id={`open-tutorial-${tut.id}-btn`}
                                onClick={() => onOpenTutorial(tut)}
                                className={`px-4 py-2 rounded-full text-xs font-sans font-semibold tracking-wide transition-all ${
                                  progressPct > 0
                                    ? 'bg-[#C5A059] hover:bg-[#B38E46] text-[#2D2926] shadow-2xs'
                                    : 'border border-[#EFE8DE] text-[#2D2926] hover:border-[#C5A059] hover:bg-[#FAF2F0]'
                                }`}
                              >
                                {progressPct > 0 ? 'Continue' : 'Start Learning'}
                              </button>
                            </div>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          )}

          {/* 3. TYPES TAB */}
          {activeTab === 'types' && (
            <div className="space-y-6 animate-in fade-in duration-200">
              <div>
                <h3 className="font-serif text-2xl font-bold text-[#2D2926]">
                  Types & Mediums of {category.name}
                </h3>
                <p className="text-xs sm:text-sm text-[#7D7571] font-sans mt-1">
                  Explore traditional and contemporary classifications within this discipline.
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                {category.types.map((t, idx) => (
                  <div 
                    key={idx}
                    className="bg-[#FFFFFF] rounded-2xl p-6 border border-[#EFE8DE] shadow-[0_4px_20px_rgba(45,41,38,0.02)] flex flex-col justify-between"
                  >
                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <h4 className="font-serif font-bold text-lg text-[#2D2926]">
                          {t.name}
                        </h4>
                        <span className="px-2.5 py-0.5 rounded-full bg-[#FAF2F0] border border-[#EFE6D5] text-[10px] font-sans font-medium text-[#2D2926]">
                          {t.medium}
                        </span>
                      </div>
                      <p className="text-xs sm:text-sm text-[#57514D] font-sans leading-relaxed">
                        {t.description}
                      </p>
                    </div>
                    <div className="mt-4 pt-3 border-t border-[#EFE8DE] text-xs font-sans text-[#7D7571]">
                      <span className="font-medium text-[#2D2926]">Characteristics: </span>
                      {t.characteristics}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* 4. TECHNIQUES TAB */}
          {activeTab === 'techniques' && (
            <div className="space-y-6 animate-in fade-in duration-200">
              <div>
                <h3 className="font-serif text-2xl font-bold text-[#2D2926]">
                  Core Techniques & Master Methods
                </h3>
                <p className="text-xs sm:text-sm text-[#7D7571] font-sans mt-1">
                  Master these foundational and advanced methods to elevate your artistic craftsmanship.
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                {category.techniques.map((tech, idx) => (
                  <div 
                    key={idx}
                    className="bg-[#FFFFFF] rounded-2xl p-6 border border-[#EFE8DE] shadow-[0_4px_20px_rgba(45,41,38,0.02)]"
                  >
                    <div className="flex items-center justify-between mb-2">
                      <h4 className="font-serif font-bold text-lg text-[#2D2926]">
                        {tech.name}
                      </h4>
                      <span className="px-2.5 py-0.5 rounded-full text-[10px] font-sans font-bold uppercase tracking-wider bg-[#FAF2F0] border border-[#EFE6D5] text-[#C5A059]">
                        {tech.difficulty}
                      </span>
                    </div>

                    <p className="text-xs sm:text-sm text-[#57514D] font-sans leading-relaxed mb-3">
                      {tech.description}
                    </p>

                    <div className="p-3.5 rounded-xl bg-[#FAF8F5] border border-[#EFE8DE] text-xs font-sans">
                      <span className="font-semibold text-[#2D2926]">Best used for: </span>
                      <span className="text-[#57514D]">{tech.howToPractice}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* 5. PRACTICE TAB */}
          {activeTab === 'practice' && (
            <div className="animate-in fade-in duration-200">
              <PracticeSystem categoryId={category.id} />
            </div>
          )}

          {/* 6. WORKSHOPS TAB */}
          {activeTab === 'workshops' && (
            <div className="space-y-6 animate-in fade-in duration-200">
              <div>
                <h3 className="font-serif text-2xl font-bold text-[#2D2926]">
                  Interactive Workshops & Masterclasses
                </h3>
                <p className="text-xs sm:text-sm text-[#7D7571] font-sans mt-1">
                  Live virtual ateliers and studio intensives led by master artists.
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {categoryWorkshops.map((ws) => (
                  <div 
                    key={ws.id}
                    className="bg-[#FFFFFF] rounded-2xl border border-[#EFE8DE] overflow-hidden shadow-[0_4px_20px_rgba(45,41,38,0.02)] flex flex-col justify-between"
                  >
                    <div>
                      <div className="relative w-full aspect-16/9 bg-[#FAF2F0]">
                        <img 
                          src={ws.image} 
                          alt={ws.title} 
                          className="w-full h-full object-cover"
                        />
                        <div className="absolute top-3 left-3 px-3 py-1 rounded-full bg-[#FAF8F5]/95 backdrop-blur-md border border-[#EFE6D5] text-[#2D2926] text-[10px] font-sans font-medium uppercase">
                          {ws.locationType}
                        </div>
                        <div className="absolute top-3 right-3 px-3 py-1 rounded-full bg-[#C5A059] text-[#2D2926] text-xs font-sans font-bold">
                          {ws.price}
                        </div>
                      </div>

                      <div className="p-5">
                        <div className="flex items-center gap-3 text-xs font-sans text-[#7D7571] mb-2">
                          <span className="flex items-center gap-1 font-medium text-[#C5A059]">
                            <Calendar className="w-3 h-3" /> {ws.date}
                          </span>
                          <span className="flex items-center gap-1">
                            <Clock className="w-3 h-3" /> {ws.duration}
                          </span>
                        </div>

                        <h4 className="font-serif font-bold text-base text-[#2D2926]">
                          {ws.title}
                        </h4>
                        <p className="text-xs text-[#7D7571] font-sans mt-1 line-clamp-2 leading-relaxed">
                          {ws.description}
                        </p>

                        <div className="flex items-center gap-2.5 mt-4 p-2.5 rounded-xl bg-[#FAF8F5] border border-[#EFE8DE]">
                          <img 
                            src={ws.instructor.avatar} 
                            alt={ws.instructor.name} 
                            className="w-8 h-8 rounded-full object-cover"
                          />
                          <div>
                            <div className="text-xs font-sans font-semibold text-[#2D2926]">{ws.instructor.name}</div>
                            <div className="text-[10px] font-sans text-[#7D7571]">{ws.instructor.title}</div>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="p-5 pt-0 flex items-center justify-between border-t border-[#EFE8DE] mt-2">
                      <span className="text-xs font-sans text-[#7D7571]">
                        {ws.spotsRemaining} spots remaining
                      </span>
                      <button className="px-4 py-2 rounded-full bg-[#C5A059] hover:bg-[#B38E46] text-[#2D2926] text-xs font-sans font-semibold shadow-2xs transition-colors">
                        Reserve Seat
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* 7. PROFESSIONAL ART TAB */}
          {activeTab === 'professional' && (
            <div className="space-y-6 animate-in fade-in duration-200">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-serif text-2xl font-bold text-[#2D2926]">
                    Exhibited Masterworks
                  </h3>
                  <p className="text-xs sm:text-sm text-[#7D7571] font-sans mt-1">
                    Featured artworks crafted by acclaimed artists in {category.name}.
                  </p>
                </div>
                <button
                  onClick={onOpenArtists}
                  className="text-xs font-sans font-semibold text-[#C5A059] hover:underline flex items-center gap-1 uppercase tracking-wider"
                >
                  <span>All Artists</span>
                  <ChevronRight className="w-3.5 h-3.5" />
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
                {categoryArtworks.map((art) => (
                  <div 
                    key={art.id}
                    className="group bg-[#FFFFFF] rounded-2xl border border-[#EFE8DE] overflow-hidden shadow-[0_4px_20px_rgba(45,41,38,0.02)] hover:border-[#C5A059] hover:shadow-[0_8px_24px_rgba(197,160,89,0.08)] transition-all duration-200"
                  >
                    <div className="relative w-full aspect-4/3 overflow-hidden bg-[#FAF2F0]">
                      <img 
                        src={art.image} 
                        alt={art.title} 
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                      />
                      <div className="absolute bottom-2.5 right-2.5 px-3 py-1 rounded-full bg-[#FAF8F5]/95 backdrop-blur-md border border-[#EFE6D5] text-[#2D2926] text-xs font-sans font-bold">
                        ${art.price}
                      </div>
                    </div>

                    <div className="p-4">
                      <h4 className="font-serif font-bold text-base text-[#2D2926] truncate">
                        {art.title}
                      </h4>
                      <div className="text-xs font-sans text-[#7D7571] mt-0.5">
                        by {art.artistName} • <span className="text-[#C5A059]">{art.style}</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* 8. EVENTS TAB */}
          {activeTab === 'events' && (
            <div className="space-y-6 animate-in fade-in duration-200">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-serif text-2xl font-bold text-[#2D2926]">
                    Exhibitions & Meetups for {category.name}
                  </h3>
                  <p className="text-xs sm:text-sm text-[#7D7571] font-sans mt-1">
                    Upcoming gallery shows, biennials, and creative symposiums.
                  </p>
                </div>
                <button
                  onClick={onOpenNearbyEvents}
                  className="text-xs font-sans font-semibold text-[#C5A059] hover:underline flex items-center gap-1 uppercase tracking-wider"
                >
                  <span>Interactive Map</span>
                  <ChevronRight className="w-3.5 h-3.5" />
                </button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {categoryEvents.map((evt) => (
                  <div 
                    key={evt.id}
                    className="bg-[#FFFFFF] rounded-2xl p-5 border border-[#EFE8DE] shadow-[0_4px_20px_rgba(45,41,38,0.02)] flex items-start gap-4"
                  >
                    <img 
                      src={evt.image} 
                      alt={evt.title} 
                      className="w-20 h-20 rounded-xl object-cover shrink-0 border border-[#EFE8DE]"
                    />
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="px-2 py-0.5 rounded-full bg-[#FAF2F0] border border-[#EFE6D5] text-[#2D2926] text-[10px] font-sans font-semibold uppercase">
                          {evt.type}
                        </span>
                        <span className="text-xs text-[#7D7571] font-sans">{evt.city}</span>
                      </div>
                      <h4 className="font-serif font-bold text-base text-[#2D2926] truncate">
                        {evt.title}
                      </h4>
                      <p className="text-xs text-[#7D7571] font-sans mt-0.5 truncate">
                        {evt.venue} • {evt.dateStr}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

        </div>

        {/* Sidebar */}
        <aside className="w-full lg:col-span-4 rounded-2xl border border-[#EFE8DE] bg-[#FFFFFF] p-6 flex flex-col gap-6 shadow-[0_4px_20px_rgba(45,41,38,0.02)]">
          
          {/* Create With Me Module */}
          <div>
            <h4 className="text-xs font-sans font-semibold uppercase tracking-[0.2em] text-[#7D7571] mb-4">
              Atelier Study Prompt
            </h4>
            <div className="bg-[#FAF2F0] p-5 rounded-xl border border-[#EFE6D5]">
              <div className="flex items-center gap-3 mb-2.5">
                <div className="w-7 h-7 bg-[#FFFFFF] border border-[#EFE6D5] text-[#2D2926] rounded-lg flex items-center justify-center font-serif font-bold text-xs shrink-0">
                  01
                </div>
                <p className="text-sm font-serif font-bold text-[#2D2926]">
                  The Light & Form Study
                </p>
              </div>
              <p className="text-xs text-[#57514D] font-sans leading-relaxed mb-4">
                Create a series of 5 tonal studies using charcoal and blending stumps to master chiaroscuro and spherical volume.
              </p>
              <div className="flex items-center justify-between">
                <div className="flex -space-x-1.5">
                  <div className="w-6 h-6 rounded-full bg-[#E9DCC9] border-2 border-white"></div>
                  <div className="w-6 h-6 rounded-full bg-[#D1CCC0] border-2 border-white"></div>
                  <div className="w-6 h-6 rounded-full bg-[#FAF2F0] border-2 border-white text-[8px] flex items-center justify-center text-[#2D2926] font-bold">
                    +18
                  </div>
                </div>
                <span className="text-[10px] font-sans font-bold text-[#C5A059] uppercase tracking-wider">
                  Active Study
                </span>
              </div>
            </div>
          </div>

          {/* Nearby Events Quick Module */}
          <div>
            <div className="flex items-center justify-between mb-4">
              <h4 className="text-xs font-sans font-semibold uppercase tracking-[0.2em] text-[#7D7571]">
                Exhibition Calender
              </h4>
              <button 
                onClick={onOpenNearbyEvents}
                className="text-[10px] font-sans font-semibold text-[#C5A059] uppercase hover:underline"
              >
                Map View
              </button>
            </div>
            <div className="space-y-2.5">
              <div 
                onClick={onOpenNearbyEvents}
                className="flex items-center gap-3 p-3 rounded-xl bg-[#FAF8F5] border border-[#EFE8DE] cursor-pointer hover:border-[#C5A059] transition-colors"
              >
                <div className="w-10 h-10 bg-[#FAF2F0] border border-[#EFE6D5] rounded-lg shrink-0 flex flex-col items-center justify-center">
                  <span className="text-[8px] font-sans font-bold uppercase text-[#7D7571]">Oct</span>
                  <span className="text-xs font-serif font-bold text-[#2D2926]">12</span>
                </div>
                <div className="min-w-0">
                  <p className="text-xs font-serif font-bold text-[#2D2926] truncate">Modernism & Form Expo</p>
                  <p className="text-[10px] font-sans text-[#7D7571] truncate">City Art Center • 2.4km</p>
                </div>
              </div>

              <div 
                onClick={onOpenNearbyEvents}
                className="flex items-center gap-3 p-3 rounded-xl bg-[#FAF8F5] border border-[#EFE8DE] cursor-pointer hover:border-[#C5A059] transition-colors"
              >
                <div className="w-10 h-10 bg-[#FAF2F0] border border-[#EFE6D5] rounded-lg shrink-0 flex flex-col items-center justify-center">
                  <span className="text-[8px] font-sans font-bold uppercase text-[#7D7571]">Oct</span>
                  <span className="text-xs font-serif font-bold text-[#2D2926]">15</span>
                </div>
                <div className="min-w-0">
                  <p className="text-xs font-serif font-bold text-[#2D2926] truncate">Ceramics & Glaze Weekend</p>
                  <p className="text-[10px] font-sans text-[#7D7571] truncate">The Clay Atelier • 0.8km</p>
                </div>
              </div>
            </div>
          </div>

          {/* Contest Preparation Module */}
          <div className="p-5 bg-[#FAF2F0] border border-[#EFE6D5] rounded-2xl relative overflow-hidden shadow-xs">
            <h5 className="text-base font-serif font-bold text-[#2D2926] mb-1">
              Annual Art Submission
            </h5>
            <p className="text-xs font-sans text-[#57514D] mb-4 leading-relaxed">
              Prepare your original portfolio for the International Contemporary Fine Art Summit.
            </p>
            <button 
              onClick={onOpenContestPrep}
              className="w-full py-2.5 bg-[#C5A059] hover:bg-[#B38E46] rounded-full text-xs font-sans font-semibold text-[#2D2926] uppercase tracking-wider transition-colors shadow-2xs"
            >
              Sprint Preparation
            </button>
          </div>

        </aside>

      </div>
    </div>
  );
};
