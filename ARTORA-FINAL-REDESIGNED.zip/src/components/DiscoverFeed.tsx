import React, { useState } from 'react';
import { 
  Heart, 
  Bookmark, 
  Share2, 
  Sparkles, 
  Compass, 
  Eye, 
  ShoppingBag, 
  X,
  ExternalLink,
  MessageCircle,
  CheckCircle2
} from 'lucide-react';
import { Artwork, ArtistProfile } from '../types';
import { ARTWORKS_DATA } from '../data/artworksData';
import { ARTISTS_DATA } from '../data/artistsData';

interface DiscoverFeedProps {
  onSelectArtist: (artist: ArtistProfile) => void;
  onOpenBuyArtwork: (artwork: Artwork) => void;
  likedArtworkIds: string[];
  onToggleLike: (id: string) => void;
  savedArtworkIds: string[];
  onToggleSave: (id: string) => void;
}

export const DiscoverFeed: React.FC<DiscoverFeedProps> = ({
  onSelectArtist,
  onOpenBuyArtwork,
  likedArtworkIds,
  onToggleLike,
  savedArtworkIds,
  onToggleSave
}) => {
  const [selectedArtwork, setSelectedArtwork] = useState<Artwork | null>(null);
  const [activeFilter, setActiveFilter] = useState<string>('all');
  const [shareSuccess, setShareSuccess] = useState<string | null>(null);

  const filters = ['all', 'Painting', 'Photography', 'Pottery & Ceramics', 'Crochet', 'Digital Art', 'Traditional / Folk Art'];

  const filteredArtworks = activeFilter === 'all' 
    ? ARTWORKS_DATA 
    : ARTWORKS_DATA.filter(a => a.artForm.toLowerCase().includes(activeFilter.toLowerCase()));

  const handleShare = (art: Artwork) => {
    if (navigator.share) {
      navigator.share({
        title: art.title,
        text: `Explore "${art.title}" by ${art.artistName} on ARTORA!`,
        url: window.location.href
      }).catch(() => {});
    } else {
      navigator.clipboard?.writeText(window.location.href);
      setShareSuccess(art.id);
      setTimeout(() => setShareSuccess(null), 2000);
    }
  };

  return (
    <div className="w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 animate-in fade-in duration-300 bg-[#FAF8F5] text-[#2D2926]">
      
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-10">
        <div>
          <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-[#FAF2F0] border border-[#EFE6D5] text-[#2D2926] text-xs font-sans font-semibold uppercase tracking-widest mb-3">
            <Sparkles className="w-3.5 h-3.5 text-[#C5A059]" />
            <span>Curated Exhibition Feed</span>
          </div>
          <h1 className="text-3xl sm:text-5xl font-bodoni font-normal text-[#2D2926] tracking-tight">
            Discover Inspiring Art <span className="font-serif italic font-light text-2xl sm:text-4xl text-[#7D7571]">& Masterpieces</span>
          </h1>
          <p className="text-xs sm:text-sm text-[#7D7571] font-sans mt-2 leading-relaxed">
            Explore curated creations, trending atelier studies, and connect directly with world-class artists.
          </p>
        </div>

        {/* Filter Chips */}
        <div className="flex items-center gap-2 overflow-x-auto no-scrollbar py-1">
          {filters.map((f) => (
            <button
              key={f}
              onClick={() => setActiveFilter(f)}
              className={`px-4 py-1.5 rounded-full text-xs font-sans font-semibold whitespace-nowrap transition-all ${
                activeFilter === f
                  ? 'bg-[#C5A059] text-[#2D2926] shadow-2xs'
                  : 'bg-[#FFFFFF] border border-[#EFE8DE] text-[#7D7571] hover:bg-[#FAF2F0] hover:text-[#2D2926]'
              }`}
            >
              {f === 'all' ? 'All Mediums' : f}
            </button>
          ))}
        </div>
      </div>

      {/* Visual Art Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
        {filteredArtworks.map((art) => {
          const isLiked = likedArtworkIds.includes(art.id);
          const isSaved = savedArtworkIds.includes(art.id);
          const artist = ARTISTS_DATA.find(a => a.id === art.artistId) || ARTISTS_DATA[0];

          return (
            <div
              key={art.id}
              id={`discover-card-${art.id}`}
              className="group bg-[#FFFFFF] rounded-2xl border border-[#EFE8DE] overflow-hidden shadow-[0_4px_20px_rgba(45,41,38,0.02)] hover:border-[#C5A059] hover:shadow-[0_8px_24px_rgba(197,160,89,0.08)] transition-all duration-300 flex flex-col justify-between"
            >
              {/* Artwork Image Container */}
              <div 
                className="relative w-full aspect-4/3 sm:aspect-1/1 overflow-hidden bg-[#FAF2F0] cursor-pointer"
                onClick={() => setSelectedArtwork(art)}
              >
                <img 
                  src={art.image} 
                  alt={art.title} 
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  loading="lazy"
                />
                
                {/* Overlay Badge */}
                <div className="absolute top-3 left-3 px-3 py-1 rounded-full bg-[#FAF8F5]/90 backdrop-blur-md text-[#2D2926] text-[11px] font-sans font-semibold border border-[#EFE6D5]">
                  {art.artForm}
                </div>

                {art.isForSale && (
                  <div className="absolute top-3 right-3 px-3 py-1 rounded-full bg-[#2D2926]/90 backdrop-blur-md text-[#C5A059] font-serif text-xs font-bold shadow-xs">
                    ${art.price}
                  </div>
                )}
              </div>

              {/* Info & Artist Bar */}
              <div className="p-5 font-sans">
                <div className="flex items-start justify-between gap-3 mb-2">
                  <div className="min-w-0">
                    <h3 
                      onClick={() => setSelectedArtwork(art)}
                      className="font-serif font-bold text-lg text-[#2D2926] truncate cursor-pointer hover:text-[#C5A059] transition-colors"
                    >
                      {art.title}
                    </h3>
                    <p className="text-xs text-[#7D7571] truncate mt-0.5">
                      {art.style} • {art.dimensions}
                    </p>
                  </div>
                </div>

                {/* Artist Row */}
                <div className="flex items-center justify-between pt-3 border-t border-[#EFE8DE] mt-3">
                  <button
                    id={`view-artist-btn-${art.artistId}`}
                    onClick={() => onSelectArtist(artist)}
                    className="flex items-center gap-2 text-left group/artist focus:outline-none"
                  >
                    <img 
                      src={art.artistAvatar} 
                      alt={art.artistName} 
                      className="w-7 h-7 rounded-full object-cover border border-[#C5A059]/30"
                    />
                    <div className="min-w-0">
                      <div className="text-xs font-semibold text-[#2D2926] group-hover/artist:text-[#C5A059] truncate">
                        {art.artistName}
                      </div>
                      <div className="text-[10px] text-[#7D7571] truncate">View Atelier</div>
                    </div>
                  </button>

                  {/* Actions (Like, Save, Share) */}
                  <div className="flex items-center gap-1">
                    <button
                      id={`like-art-${art.id}`}
                      onClick={() => onToggleLike(art.id)}
                      className={`p-2 rounded-lg text-xs transition-colors ${
                        isLiked 
                          ? 'text-[#C5A059] bg-[#FAF2F0]' 
                          : 'text-[#7D7571] hover:bg-[#FAF2F0]'
                      }`}
                      title="Like artwork"
                    >
                      <Heart className={`w-4 h-4 ${isLiked ? 'fill-[#C5A059]' : ''}`} />
                    </button>

                    <button
                      id={`save-art-${art.id}`}
                      onClick={() => onToggleSave(art.id)}
                      className={`p-2 rounded-lg text-xs transition-colors ${
                        isSaved 
                          ? 'text-[#C5A059] bg-[#FAF2F0]' 
                          : 'text-[#7D7571] hover:bg-[#FAF2F0]'
                      }`}
                      title="Save to bookmarks"
                    >
                      <Bookmark className={`w-4 h-4 ${isSaved ? 'fill-[#C5A059]' : ''}`} />
                    </button>

                    <button
                      id={`share-art-${art.id}`}
                      onClick={() => handleShare(art)}
                      className="p-2 rounded-lg text-[#7D7571] hover:bg-[#FAF2F0] transition-colors relative"
                      title="Share artwork"
                    >
                      <Share2 className="w-4 h-4" />
                      {shareSuccess === art.id && (
                        <span className="absolute -top-6 right-0 bg-[#2D2926] text-white text-[9px] px-1.5 py-0.5 rounded shadow">
                          Copied!
                        </span>
                      )}
                    </button>
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Detailed Artwork Modal */}
      {selectedArtwork && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-xs animate-in fade-in duration-200">
          <div 
            className="w-full max-w-4xl max-h-[90vh] overflow-y-auto bg-[#FAF8F5] rounded-2xl border border-[#EFE8DE] shadow-2xl overflow-hidden"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="relative bg-[#FAF2F0]">
              <img 
                src={selectedArtwork.image} 
                alt={selectedArtwork.title} 
                className="w-full max-h-[55vh] object-contain"
              />
              <button
                onClick={() => setSelectedArtwork(null)}
                className="absolute top-4 right-4 p-2 rounded-full bg-[#FAF8F5]/90 text-[#2D2926] hover:bg-[#FAF2F0] transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 sm:p-8 font-sans">
              <div className="flex flex-col md:flex-row md:items-start justify-between gap-6">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-2">
                    <span className="px-3 py-0.5 rounded-full bg-[#FAF2F0] border border-[#EFE6D5] text-[#2D2926] text-xs font-semibold uppercase">
                      {selectedArtwork.artForm}
                    </span>
                    <span className="text-xs text-[#7D7571] font-medium">
                      {selectedArtwork.style}
                    </span>
                  </div>

                  <h2 className="text-2xl sm:text-3xl font-serif font-bold text-[#2D2926]">
                    {selectedArtwork.title}
                  </h2>
                  
                  <p className="text-sm text-[#57514D] mt-3 leading-relaxed">
                    {selectedArtwork.description}
                  </p>

                  <div className="grid grid-cols-2 gap-4 mt-5 p-4 rounded-xl bg-[#FFFFFF] border border-[#EFE8DE] text-xs">
                    <div>
                      <span className="text-[#7D7571] block mb-0.5">Archival Materials & Medium</span>
                      <span className="font-semibold text-[#2D2926]">{selectedArtwork.materials}</span>
                    </div>
                    <div>
                      <span className="text-[#7D7571] block mb-0.5">Dimensions & Format</span>
                      <span className="font-semibold text-[#2D2926]">{selectedArtwork.dimensions}</span>
                    </div>
                  </div>
                </div>

                {/* Right Purchase Box */}
                <div className="w-full md:w-72 p-6 rounded-xl border border-[#EFE8DE] bg-[#FFFFFF] shadow-2xs shrink-0">
                  <div className="flex items-center justify-between mb-4">
                    <span className="text-xs text-[#7D7571]">Acquisition Price</span>
                    <span className="text-2xl font-serif font-bold text-[#C5A059]">
                      ${selectedArtwork.price}
                    </span>
                  </div>

                  <div className="space-y-2">
                    <button
                      onClick={() => {
                        const artToBuy = selectedArtwork;
                        setSelectedArtwork(null);
                        onOpenBuyArtwork(artToBuy);
                      }}
                      className="w-full py-3 rounded-full bg-[#C5A059] hover:bg-[#B38E46] text-[#2D2926] font-semibold text-xs uppercase tracking-wider shadow-2xs transition-all flex items-center justify-center gap-2"
                    >
                      <ShoppingBag className="w-4 h-4" />
                      <span>Acquisition Inquiries</span>
                    </button>

                    <button
                      onClick={() => {
                        const artist = ARTISTS_DATA.find(a => a.id === selectedArtwork.artistId) || ARTISTS_DATA[0];
                        setSelectedArtwork(null);
                        onSelectArtist(artist);
                      }}
                      className="w-full py-2.5 rounded-full bg-[#FAF8F5] border border-[#EFE8DE] text-[#2D2926] font-semibold text-xs hover:bg-[#FAF2F0] transition-colors"
                    >
                      View Artist Atelier
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
