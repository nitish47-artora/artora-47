import React, { useState } from 'react';
import { 
  Award, 
  Calendar, 
  Clock, 
  Sparkles, 
  CheckCircle2, 
  Zap, 
  ShieldCheck, 
  FileText, 
  Lightbulb, 
  ArrowRight,
  ChevronRight,
  ChevronDown,
  Check
} from 'lucide-react';
import { CONTESTS_DATA } from '../data/contestsData';
import { ContestChallenge } from '../types';

export const ContestPrep: React.FC = () => {
  const [selectedContest, setSelectedContest] = useState<ContestChallenge>(CONTESTS_DATA[0]);
  const [completedDays, setCompletedDays] = useState<number[]>([1, 2]);
  const [activeDayOpen, setActiveDayOpen] = useState<number>(3);

  const toggleDayComplete = (day: number) => {
    if (completedDays.includes(day)) {
      setCompletedDays(completedDays.filter(d => d !== day));
    } else {
      setCompletedDays([...completedDays, day]);
    }
  };

  return (
    <div className="w-full max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8 animate-in fade-in duration-300 bg-[#FAF8F5] text-[#2D2926]">
      
      {/* Header */}
      <div className="text-center max-w-2xl mx-auto mb-10">
        <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-[#FAF2F0] border border-[#EFE6D5] text-[#2D2926] text-xs font-sans font-semibold uppercase tracking-widest mb-3">
          <Zap className="w-3.5 h-3.5 text-[#C5A059]" />
          <span>Competition & Biennial Studio</span>
        </div>
        <h1 className="text-3xl sm:text-5xl font-bodoni font-normal text-[#2D2926] tracking-tight">
          Create for a Challenge <span className="font-serif italic font-light text-2xl sm:text-4xl text-[#7D7571]">& Juried Review</span>
        </h1>
        <p className="text-xs sm:text-sm text-[#7D7571] font-sans mt-2 leading-relaxed">
          Prepare submissions for international juried exhibitions, gallery reviews, and prestigious art competitions with curated 7-day atelier preparation sprints.
        </p>
      </div>

      {/* Contest Selector Bar */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5 mb-10">
        {CONTESTS_DATA.map((contest) => {
          const isSelected = contest.id === selectedContest.id;
          return (
            <div
              key={contest.id}
              onClick={() => setSelectedContest(contest)}
              className={`p-6 rounded-2xl border cursor-pointer transition-all duration-200 flex items-start gap-4 ${
                isSelected
                  ? 'border-[#C5A059] bg-[#FFFFFF] shadow-[0_8px_24px_rgba(197,160,89,0.12)]'
                  : 'border-[#EFE8DE] bg-[#FFFFFF] hover:border-[#C5A059]'
              }`}
            >
              <img src={contest.image} alt="" className="w-20 h-20 rounded-xl object-cover shrink-0 border border-[#EFE8DE]" />
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-1">
                  <span className="px-2.5 py-0.5 rounded-full bg-[#FAF2F0] border border-[#EFE6D5] text-[#2D2926] text-[10px] font-sans font-semibold uppercase">
                    {contest.daysRemaining} Days Left
                  </span>
                  <span className="text-xs font-sans text-[#7D7571]">{contest.category}</span>
                </div>
                <h3 className="font-serif font-bold text-base sm:text-lg text-[#2D2926] truncate">
                  {contest.title}
                </h3>
                <p className="text-xs font-sans text-[#C5A059] font-medium truncate mt-0.5">{contest.prizePool}</p>
              </div>
            </div>
          );
        })}
      </div>

      {/* Main Sprint Detail */}
      <div className="bg-[#FFFFFF] rounded-2xl border border-[#EFE8DE] p-7 sm:p-9 shadow-[0_4px_24px_rgba(45,41,38,0.03)] space-y-8">
        
        {/* Banner */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-5 pb-6 border-b border-[#EFE8DE]">
          <div>
            <span className="text-xs font-sans font-semibold uppercase tracking-[0.2em] text-[#C5A059]">
              Curated Juried Brief
            </span>
            <h2 className="text-2xl sm:text-3xl font-serif font-bold text-[#2D2926] mt-1">
              {selectedContest.title}
            </h2>
            <p className="text-xs sm:text-sm text-[#7D7571] font-sans mt-1">
              Theme: <strong className="text-[#2D2926]">"{selectedContest.theme}"</strong> • Curated by {selectedContest.organizer}
            </p>
          </div>

          <div className="px-4 py-2.5 rounded-xl bg-[#FAF2F0] border border-[#EFE6D5] text-[#2D2926] text-xs font-sans font-semibold shrink-0">
            Prize Pool: <span className="text-[#C5A059]">{selectedContest.prizePool}</span>
          </div>
        </div>

        {/* 7-Day Sprint Plan */}
        <div>
          <h3 className="text-xs font-sans font-semibold uppercase tracking-[0.2em] text-[#7D7571] mb-5 flex items-center justify-between">
            <span>7-Day Day-by-Day Preparation Path</span>
            <span className="text-xs text-[#C5A059] font-semibold">{completedDays.length} / 7 Days Completed</span>
          </h3>

          <div className="space-y-3 font-sans">
            {selectedContest.sevenDayPlan.map((step) => {
              const isDone = completedDays.includes(step.day);
              const isOpen = activeDayOpen === step.day;

              return (
                <div
                  key={step.day}
                  className={`rounded-xl border transition-all ${
                    isDone 
                      ? 'border-[#C5A059]/40 bg-[#FAF2F0]/40' 
                      : 'border-[#EFE8DE] bg-[#FAF8F5]'
                  }`}
                >
                  <div 
                    className="p-4 flex items-center justify-between cursor-pointer"
                    onClick={() => setActiveDayOpen(isOpen ? 0 : step.day)}
                  >
                    <div className="flex items-center gap-3.5">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          toggleDayComplete(step.day);
                        }}
                        className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-serif font-bold transition-colors ${
                          isDone 
                            ? 'bg-[#C5A059] text-[#2D2926]' 
                            : 'border border-[#EFE8DE] bg-[#FFFFFF] text-[#7D7571]'
                        }`}
                      >
                        {isDone ? '✓' : step.day}
                      </button>
                      <div>
                        <div className="text-xs sm:text-sm font-serif font-bold text-[#2D2926]">
                          Day {step.day}: {step.title}
                        </div>
                        <div className="text-[11px] text-[#7D7571] font-sans">Core Focus: {step.focus}</div>
                      </div>
                    </div>

                    <ChevronDown className={`w-4 h-4 text-[#7D7571] transition-transform ${isOpen ? 'rotate-180' : ''}`} />
                  </div>

                  {isOpen && (
                    <div className="px-4 pb-4 pt-2 text-xs text-[#57514D] border-t border-[#EFE8DE] mt-1 font-sans">
                      <p className="leading-relaxed">{step.task}</p>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* 2 Column Tips */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-4 font-sans">
          <div className="p-6 rounded-2xl bg-[#FAF8F5] border border-[#EFE8DE]">
            <h4 className="font-semibold text-xs uppercase tracking-[0.2em] text-[#7D7571] mb-3">
              Jury Evaluation Criteria
            </h4>
            <ul className="space-y-2.5 text-xs text-[#57514D]">
              {selectedContest.evaluationCriteria.map((crit, i) => (
                <li key={i} className="flex items-start gap-2">
                  <span className="text-[#C5A059] font-bold">•</span>
                  <span>{crit}</span>
                </li>
              ))}
            </ul>
          </div>

          <div className="p-6 rounded-2xl bg-[#FAF8F5] border border-[#EFE8DE]">
            <h4 className="font-semibold text-xs uppercase tracking-[0.2em] text-[#7D7571] mb-3">
              Portfolio & Submission Advice
            </h4>
            <ul className="space-y-2.5 text-xs text-[#57514D]">
              {selectedContest.portfolioTips.map((tip, i) => (
                <li key={i} className="flex items-start gap-2">
                  <span className="text-[#C5A059] font-bold">✓</span>
                  <span>{tip}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>

      </div>
    </div>
  );
};
