import React from 'react';
import { 
  X, 
  Sun, 
  Moon, 
  Bookmark, 
  Settings, 
  Eye, 
  Sparkles, 
  MapPin, 
  RotateCcw, 
  ShieldCheck, 
  Palette,
  Check
} from 'lucide-react';
import { Tutorial, Artwork } from '../types';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  darkMode: boolean;
  onToggleDarkMode: () => void;
  onResetOnboarding: () => void;
  savedTutorials: Tutorial[];
  savedArtworks: Artwork[];
  onOpenTutorial: (tutorial: Tutorial) => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  darkMode,
  onToggleDarkMode,
  onResetOnboarding,
  savedTutorials,
  savedArtworks,
  onOpenTutorial
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-xs animate-in fade-in duration-200 font-sans">
      <div 
        className="w-full max-w-xl max-h-[85vh] overflow-y-auto bg-[#FAF8F5] rounded-2xl border border-[#EFE8DE] p-6 sm:p-7 shadow-2xl space-y-6 text-[#2D2926]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-[#EFE8DE]">
          <div className="flex items-center gap-2">
            <Settings className="w-5 h-5 text-[#C5A059]" />
            <h2 className="font-serif font-bold text-xl text-[#2D2926]">
              Atelier Settings & Saved Items
            </h2>
          </div>
          <button 
            onClick={onClose}
            className="p-1 rounded-full text-[#7D7571] hover:bg-[#FAF2F0]"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Curation Info */}
        <div className="p-4 rounded-xl bg-[#FFFFFF] border border-[#EFE8DE] flex items-center justify-between">
          <div>
            <div className="font-semibold text-xs sm:text-sm text-[#2D2926]">Gallery Aesthetic</div>
            <div className="text-[11px] text-[#7D7571] mt-0.5">Warm ivory, blush accent, and gilded typography.</div>
          </div>
          <div className="px-3 py-1 rounded-full bg-[#FAF2F0] border border-[#EFE6D5] text-[#C5A059] text-xs font-semibold">
            Atelier Light
          </div>
        </div>

        {/* Saved Bookmarks Section */}
        <div>
          <h3 className="text-xs font-semibold uppercase tracking-[0.2em] text-[#7D7571] mb-3 flex items-center gap-1.5">
            <Bookmark className="w-3.5 h-3.5 text-[#C5A059]" />
            <span>Saved Studies & Artworks ({savedTutorials.length + savedArtworks.length})</span>
          </h3>

          {savedTutorials.length === 0 && savedArtworks.length === 0 ? (
            <div className="text-center py-6 text-xs text-[#7D7571] border border-dashed border-[#EFE8DE] rounded-xl bg-[#FFFFFF]">
              No saved tutorials or artworks yet. Tap the bookmark icon on any item to save it here!
            </div>
          ) : (
            <div className="space-y-2 max-h-48 overflow-y-auto no-scrollbar">
              {savedTutorials.map((tut) => (
                <div 
                  key={tut.id}
                  onClick={() => {
                    onClose();
                    onOpenTutorial(tut);
                  }}
                  className="p-3 rounded-xl bg-[#FFFFFF] border border-[#EFE8DE] flex items-center justify-between cursor-pointer hover:border-[#C5A059] transition-colors text-xs"
                >
                  <div className="flex items-center gap-2 truncate">
                    <span className="w-2 h-2 rounded-full bg-[#C5A059]" />
                    <span className="font-serif font-bold text-[#2D2926] truncate">{tut.title}</span>
                  </div>
                  <span className="text-[10px] text-[#7D7571] shrink-0 bg-[#FAF2F0] px-2 py-0.5 rounded-full border border-[#EFE6D5]">
                    Tutorial
                  </span>
                </div>
              ))}

              {savedArtworks.map((art) => (
                <div 
                  key={art.id}
                  className="p-3 rounded-xl bg-[#FFFFFF] border border-[#EFE8DE] flex items-center justify-between text-xs"
                >
                  <div className="flex items-center gap-2 truncate">
                    <span className="w-2 h-2 rounded-full bg-[#C5A059]" />
                    <span className="font-serif font-bold text-[#2D2926] truncate">{art.title}</span>
                    <span className="text-[10px] text-[#7D7571]">by {art.artistName}</span>
                  </div>
                  <span className="text-[10px] text-[#C5A059] font-serif font-bold shrink-0 bg-[#FAF2F0] px-2 py-0.5 rounded-full border border-[#EFE6D5]">
                    ${art.price}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Reset Onboarding Option */}
        <div className="pt-3 border-t border-[#EFE8DE] flex items-center justify-between">
          <div>
            <div className="text-xs font-semibold text-[#2D2926]">Reset Curator Questionnaire</div>
            <div className="text-[11px] text-[#7D7571]">Clear current preferences and restart welcome step.</div>
          </div>
          <button
            onClick={() => {
              onResetOnboarding();
              onClose();
            }}
            className="flex items-center gap-1.5 px-4 py-2 rounded-full bg-[#FAF2F0] border border-[#EFE6D5] text-[#2D2926] hover:bg-[#FFFFFF] text-xs font-semibold transition-colors"
          >
            <RotateCcw className="w-3.5 h-3.5 text-[#C5A059]" />
            <span>Restart</span>
          </button>
        </div>
      </div>
    </div>
  );
};
