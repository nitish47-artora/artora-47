import React, { useState } from 'react';
import { 
  Smartphone, 
  Code2, 
  Copy, 
  Check, 
  Layers, 
  FileCode, 
  FolderTree, 
  Download, 
  ExternalLink,
  Sparkles,
  Palette,
  Music,
  Brush,
  Compass
} from 'lucide-react';

interface AndroidFileItem {
  name: string;
  path: string;
  category: 'core' | 'ui' | 'theme' | 'data' | 'gradle';
  code: string;
  description: string;
}

const ANDROID_FILES: AndroidFileItem[] = [
  {
    name: 'MainActivity.kt',
    path: 'app/src/main/java/com/artora/app/MainActivity.kt',
    category: 'core',
    description: 'Main Android ComponentActivity managing Scaffold, top/bottom navigation, and state routing.',
    code: `package com.artora.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import com.artora.app.ui.components.AppDestination
import com.artora.app.ui.components.ArtoraBottomBar
import com.artora.app.ui.components.ArtoraTopBar
import com.artora.app.ui.screens.*
import com.artora.app.ui.theme.ArtoraIvory
import com.artora.app.ui.theme.ArtoraTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            ArtoraTheme {
                ArtoraAppContent()
            }
        }
    }
}

@Composable
fun ArtoraAppContent() {
    var currentDestination by remember { mutableStateOf(AppDestination.DISCOVER) }
    var selectedArtistId by remember { mutableStateOf<String?>(null) }
    var isWelcomeShown by remember { mutableStateOf(false) }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = ArtoraIvory
    ) {
        if (!isWelcomeShown) {
            WelcomeScreen(
                onNavigate = { destination ->
                    isWelcomeShown = true
                    currentDestination = destination
                }
            )
        } else {
            Scaffold(
                topBar = {
                    ArtoraTopBar(
                        title = "ARTORA",
                        subtitle = "ATELIER & DISCOVERY"
                    )
                },
                bottomBar = {
                    ArtoraBottomBar(
                        currentDestination = currentDestination,
                        onNavigate = { destination ->
                            selectedArtistId = null
                            currentDestination = destination
                        }
                    )
                },
                containerColor = ArtoraIvory
            ) { paddingValues ->
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(paddingValues)
                ) {
                    if (selectedArtistId != null) {
                        ArtistProfileScreen(
                            artistId = selectedArtistId!!,
                            onBack = { selectedArtistId = null }
                        )
                    } else {
                        when (currentDestination) {
                            AppDestination.DISCOVER -> DiscoverFeedScreen(
                                onSelectArtist = { id -> selectedArtistId = id }
                            )
                            AppDestination.WORKSHOPS -> WorkshopsScreen()
                            AppDestination.PRACTICE -> PracticeSystemScreen()
                            AppDestination.NEARBY -> ExploreNearbyScreen()
                            AppDestination.MUSIC -> MusicExperienceScreen()
                            AppDestination.MARKET -> MarketplaceScreen(
                                onSelectArtist = { id -> selectedArtistId = id }
                            )
                        }
                    }
                }
            }
        }
    }
}`
  },
  {
    name: 'Theme.kt',
    path: 'app/src/main/java/com/artora/app/ui/theme/Theme.kt',
    category: 'theme',
    description: 'Atelier Material3 color scheme, ivory backgrounds, gilded accents & typography binding.',
    code: `package com.artora.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val ArtoraLightColorScheme = lightColorScheme(
    primary = ArtoraGold,
    onPrimary = ArtoraCharcoal,
    primaryContainer = ArtoraBlush,
    onPrimaryContainer = ArtoraCharcoal,
    secondary = ArtoraCharcoal,
    onSecondary = ArtoraWhite,
    background = ArtoraIvory,
    onBackground = ArtoraCharcoal,
    surface = ArtoraWhite,
    onSurface = ArtoraCharcoal,
    surfaceVariant = ArtoraBlush,
    onSurfaceVariant = ArtoraMuted,
    outline = ArtoraBeige
)

@Composable
fun ArtoraTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = ArtoraLightColorScheme,
        typography = Typography,
        content = content
    )
}`
  },
  {
    name: 'PracticeSystemScreen.kt',
    path: 'app/src/main/java/com/artora/app/ui/screens/PracticeSystemScreen.kt',
    category: 'ui',
    description: '4-stage atelier progression ladder, sketchbook upload simulator, master critique evaluator.',
    code: `package com.artora.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.artora.app.data.ArtoraRepository
import com.artora.app.model.PracticeTask
import com.artora.app.ui.theme.*

@Composable
fun PracticeSystemScreen() {
    val tasks = ArtoraRepository.practiceTasks
    var selectedTaskIndex by remember { mutableStateOf(0) }
    var completedTaskIndices by remember { mutableStateOf(setOf<Int>()) }
    var uploadedImageUrl by remember { mutableStateOf<String?>(null) }
    var showCritiqueFeedback by remember { mutableStateOf(false) }

    val currentTask = tasks.getOrElse(selectedTaskIndex) { tasks[0] }
    // ... 4-stage Atelier interactive progression
}`
  },
  {
    name: 'ArtoraAudioSynthesizer.kt',
    path: 'app/src/main/java/com/artora/app/audio/ArtoraAudioSynthesizer.kt',
    category: 'core',
    description: 'Native Android AudioTrack procedural frequency generator for modal acoustic synthesis.',
    code: `package com.artora.app.audio

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import kotlinx.coroutines.*
import kotlin.math.sin

object ArtoraAudioSynthesizer {
    private const val SAMPLE_RATE = 44100
    private var audioTrack: AudioTrack? = null
    private var isPlaying = false
    private var synthJob: Job? = null

    fun playPreset(preset: String, onProgress: ((Int) -> Unit)? = null) {
        // Real-time PCM-16 harmonic synthesis loop
    }
}`
  },
  {
    name: 'app/build.gradle.kts',
    path: 'android/app/build.gradle.kts',
    category: 'gradle',
    description: 'AGP 8.5+, Kotlin 2.0 Compose compiler, Material3, Navigation, and Coil image pipeline.',
    code: `plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "com.artora.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.artora.app"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0.0"
    }
    // ...
}`
  }
];

export const AndroidCodeHub: React.FC<{ onClose: () => void }> = ({ onClose }) => {
  const [activeFileIndex, setActiveFileIndex] = useState(0);
  const [copied, setCopied] = useState(false);

  const activeFile = ANDROID_FILES[activeFileIndex];

  const handleCopy = () => {
    navigator.clipboard.writeText(activeFile.code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-charcoal/60 backdrop-blur-sm animate-fadeIn">
      <div className="bg-ivory border border-cream-border rounded-2xl w-full max-w-5xl h-[85vh] flex flex-col shadow-2xl overflow-hidden">
        
        {/* Header */}
        <div className="px-6 py-4 bg-white border-b border-beige flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gold/15 border border-gold/30 flex items-center justify-center text-gold-dark">
              <Smartphone className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-serif text-lg font-bold text-charcoal">Native Android (Kotlin + Jetpack Compose)</h3>
                <span className="px-2 py-0.5 text-[10px] font-bold tracking-wider uppercase bg-blush text-gold-dark rounded-full border border-cream-border">
                  Production Ready
                </span>
              </div>
              <p className="text-xs text-muted">
                Explore the complete Kotlin source code structure &amp; architecture created for ARTORA Android.
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-serif font-bold text-charcoal bg-beige/50 hover:bg-beige rounded-full transition-colors"
          >
            Close Inspector
          </button>
        </div>

        {/* Body Split View */}
        <div className="flex-1 flex overflow-hidden">
          
          {/* File Explorer Tree */}
          <div className="w-72 bg-white/60 border-r border-beige flex flex-col p-4 overflow-y-auto">
            <div className="text-[10px] font-bold text-muted uppercase tracking-wider mb-3 flex items-center gap-1.5">
              <FolderTree className="w-3.5 h-3.5 text-gold-dark" />
              Project Files
            </div>

            <div className="space-y-1.5">
              {ANDROID_FILES.map((file, idx) => (
                <button
                  key={file.path}
                  onClick={() => setActiveFileIndex(idx)}
                  className={`w-full text-left px-3 py-2 rounded-xl text-xs transition-all flex flex-col ${
                    activeFileIndex === idx
                      ? 'bg-gold/15 text-charcoal font-bold border border-gold/40 shadow-xs'
                      : 'hover:bg-beige/40 text-charcoal/80'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <FileCode className={`w-3.5 h-3.5 ${activeFileIndex === idx ? 'text-gold-dark' : 'text-muted'}`} />
                    <span className="font-mono text-[11px] truncate">{file.name}</span>
                  </div>
                  <span className="text-[9px] text-muted truncate mt-0.5 pl-5">{file.path}</span>
                </button>
              ))}
            </div>

            <div className="mt-auto pt-4 border-t border-beige">
              <div className="p-3 bg-blush rounded-xl border border-cream-border text-[11px] text-charcoal/90">
                <div className="font-bold flex items-center gap-1 text-gold-dark mb-1">
                  <Sparkles className="w-3 h-3" />
                  Gradle &amp; Compose
                </div>
                Full Android source files are structured in <code className="font-mono bg-white px-1 py-0.5 rounded text-[10px]">/android</code> with AGP 8.5+, Jetpack Compose, Material3 &amp; AudioTrack synthesizer.
              </div>
            </div>
          </div>

          {/* Code Viewer Panel */}
          <div className="flex-1 flex flex-col bg-[#1E1E24] text-gray-200 overflow-hidden">
            <div className="px-6 py-3 bg-[#18181C] border-b border-gray-800 flex items-center justify-between text-xs">
              <div className="flex items-center gap-2">
                <Code2 className="w-4 h-4 text-gold" />
                <span className="font-mono text-gold-light font-semibold">{activeFile.path}</span>
              </div>
              <button
                onClick={handleCopy}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-gray-800 hover:bg-gray-700 text-xs text-gray-200 font-medium transition-colors"
              >
                {copied ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-400" />
                    <span className="text-emerald-400">Copied!</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" />
                    <span>Copy Code</span>
                  </>
                )}
              </button>
            </div>

            {/* Description Banner */}
            <div className="px-6 py-2.5 bg-[#24242A] border-b border-gray-800 text-xs text-gray-300">
              <span className="text-gold-light font-semibold">Purpose: </span>
              {activeFile.description}
            </div>

            {/* Syntax Code Box */}
            <div className="flex-1 p-6 overflow-auto font-mono text-xs leading-relaxed text-gray-100 selection:bg-gold/30">
              <pre>
                <code>{activeFile.code}</code>
              </pre>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
