import React, { useState } from 'react';
import { 
  Lightbulb, 
  Sparkles, 
  RefreshCw, 
  Palette, 
  Clock, 
  Layers, 
  Bookmark, 
  Share2,
  Check
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { ArtCategory } from '../types';

interface IdeaGeneratorProps {
  categories: ArtCategory[];
  activeCategory: ArtCategory;
}

export const IdeaGenerator: React.FC<IdeaGeneratorProps> = ({
  categories,
  activeCategory
}) => {
  const [selectedCatId, setSelectedCatId] = useState(activeCategory.id);
  const [selectedMood, setSelectedMood] = useState('Dreamy & Ethereal');
  const [timeAvailable, setTimeAvailable] = useState('45 mins');
  const [generatedPrompt, setGeneratedPrompt] = useState<{
    title: string;
    concept: string;
    palette: string[];
    compositionTip: string;
    materials: string;
  }>({
    title: 'Solitary Beacon in Violet Mist',
    concept: 'A secluded mountain observatory glowing with warm amber lamplight surrounded by floating lavender clouds and a silver crescent moon.',
    palette: ['#2E1A47', '#6C5B7B', '#C06C84', '#F8B195', '#F67280'],
    compositionTip: 'Place the glowing observatory on the lower right third; let 70% of the canvas remain atmospheric negative space.',
    materials: 'Fluid watercolors, white gouache spatter for stars, rough cotton paper'
  });

  const moods = ['Dreamy & Ethereal', 'Vibrant & Energetic', 'Moody & Melancholy', 'Ancient & Folkloric', 'Futuristic & Minimalist', 'Calm & Zen'];
  const times = ['15 mins (Speed Study)', '45 mins (Studio Piece)', '2 hours (Deep Immersion)', 'Weekend Masterwork'];

  const handleGenerate = () => {
    const selectedCat = categories.find(c => c.id === selectedCatId) || activeCategory;
    
    const promptPool = [
      {
        title: `${selectedCat.name}: Whispers of the Forgotten Garden`,
        concept: `An overgrown stone fountain reclaimed by wild botanical flora, ancient moss, and morning dew reflecting fractured prisms of light.`,
        palette: ['#1A3636', '#40534C', '#D6EFD8', '#E78895', '#FFE4D6'],
        compositionTip: 'Use dynamic triangular framing with deep shadows in the foreground directing gaze toward the glowing water center.',
        materials: 'Rich archival pigments, fine detail sable brush, masking fluid for water highlights'
      },
      {
        title: `${selectedCat.name}: Midnight Atelier Silhouette`,
        concept: `A solitary artist gazing through a rain-streaked skylight where blurred city streetlamps bleed into abstract color ribbons.`,
        palette: ['#0B132B', '#1C2541', '#3A506B', '#5BC0BE', '#6FFFE9'],
        compositionTip: 'High contrast between the crisp dark silhouette of the figure and the soft bokeh luminaries in the background.',
        materials: 'Wet-on-wet pigment blending, granulating watercolor technique'
      },
      {
        title: `${selectedCat.name}: Celestial Ceramic Totem`,
        concept: `A sculpted organic vessel etched with spiral solar wind patterns and dipped in reactive turquoise and raw iron glazes.`,
        palette: ['#3D5A80', '#98C1D9', '#E0FBFC', '#EE6C4D', '#293241'],
        compositionTip: 'Emphasize the tactile silhouette and asymmetrical balance inspired by natural wind-worn sandstone.',
        materials: 'Textured stoneware clay, sgraffito carving tools, oxide wash'
      }
    ];

    const randomChoice = promptPool[Math.floor(Math.random() * promptPool.length)];
    setGeneratedPrompt(randomChoice);
    confetti({ particleCount: 50, spread: 40 });
  };

  return (
    <div className="w-full max-w-4xl mx-auto px-4 py-8 animate-in fade-in duration-300 bg-[#FAF8F5] text-[#2D2926]">
      
      {/* Header */}
      <div className="text-center max-w-xl mx-auto mb-10">
        <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-[#FAF2F0] border border-[#EFE6D5] text-[#2D2926] text-xs font-sans font-semibold uppercase tracking-widest mb-3">
          <Lightbulb className="w-3.5 h-3.5 text-[#C5A059]" />
          <span>Atelier Muse & Ideation</span>
        </div>
        <h1 className="text-3xl sm:text-5xl font-bodoni font-normal text-[#2D2926] tracking-tight">
          Get Creative Ideas <span className="font-serif italic font-light text-2xl sm:text-4xl text-[#7D7571]">& Prompts</span>
        </h1>
        <p className="text-xs sm:text-sm text-[#7D7571] font-sans mt-2 leading-relaxed">
          Overcome creative inertia. Generate tailored atelier briefs, harmonic color palettes, and composition strategies instantly.
        </p>
      </div>

      {/* Control Configuration Card */}
      <div className="bg-[#FFFFFF] rounded-2xl border border-[#EFE8DE] p-7 sm:p-9 shadow-[0_4px_24px_rgba(45,41,38,0.03)] space-y-6 mb-8 font-sans">
        
        {/* Discipline Selector */}
        <div>
          <label className="block text-xs font-semibold uppercase tracking-[0.2em] text-[#7D7571] mb-2.5">
            Target Art Discipline
          </label>
          <div className="flex items-center gap-2 overflow-x-auto no-scrollbar py-1">
            {categories.slice(0, 10).map((c) => (
              <button
                key={c.id}
                onClick={() => setSelectedCatId(c.id)}
                className={`px-4 py-1.5 rounded-full text-xs font-semibold whitespace-nowrap border transition-all ${
                  selectedCatId === c.id
                    ? 'bg-[#C5A059] text-[#2D2926] border-[#C5A059] shadow-2xs'
                    : 'bg-[#FAF8F5] text-[#7D7571] border-[#EFE8DE] hover:bg-[#FAF2F0]'
                }`}
              >
                {c.name}
              </button>
            ))}
          </div>
        </div>

        {/* Mood & Time Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-semibold uppercase tracking-[0.2em] text-[#7D7571] mb-2">
              Atmospheric Mood
            </label>
            <select
              value={selectedMood}
              onChange={(e) => setSelectedMood(e.target.value)}
              className="w-full text-xs font-medium p-3 rounded-xl bg-[#FAF8F5] border border-[#EFE8DE] text-[#2D2926] outline-none focus:border-[#C5A059]"
            >
              {moods.map((m) => (
                <option key={m} value={m}>{m}</option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-semibold uppercase tracking-[0.2em] text-[#7D7571] mb-2">
              Time Allotment
            </label>
            <select
              value={timeAvailable}
              onChange={(e) => setTimeAvailable(e.target.value)}
              className="w-full text-xs font-medium p-3 rounded-xl bg-[#FAF8F5] border border-[#EFE8DE] text-[#2D2926] outline-none focus:border-[#C5A059]"
            >
              {times.map((t) => (
                <option key={t} value={t}>{t}</option>
              ))}
            </select>
          </div>
        </div>

        {/* Generate CTA Button */}
        <button
          onClick={handleGenerate}
          className="w-full py-3.5 rounded-full bg-[#C5A059] hover:bg-[#B38E46] text-[#2D2926] font-semibold text-xs uppercase tracking-wider shadow-md hover:shadow-lg transition-all flex items-center justify-center gap-2"
        >
          <Sparkles className="w-4 h-4" />
          <span>Generate Atelier Concept Brief</span>
        </button>
      </div>

      {/* Generated Result Card */}
      {generatedPrompt && (
        <div className="bg-[#FFFFFF] rounded-2xl border border-[#EFE8DE] p-7 sm:p-9 shadow-[0_4px_24px_rgba(45,41,38,0.03)] space-y-6 animate-in zoom-in-95 duration-200">
          
          <div className="flex items-start justify-between gap-4 pb-4 border-b border-[#EFE8DE]">
            <div>
              <span className="px-3 py-1 rounded-full bg-[#FAF2F0] border border-[#EFE6D5] text-[#2D2926] text-xs font-sans font-semibold uppercase tracking-wider">
                Curated Atelier Brief
              </span>
              <h2 className="text-2xl sm:text-3xl font-serif font-bold text-[#2D2926] mt-2">
                {generatedPrompt.title}
              </h2>
            </div>
          </div>

          <div>
            <h4 className="text-xs font-semibold uppercase tracking-[0.2em] text-[#7D7571] mb-1 font-sans">
              Creative Narrative & Theme
            </h4>
            <p className="text-sm sm:text-base text-[#2D2926] leading-relaxed font-normal">
              {generatedPrompt.concept}
            </p>
          </div>

          {/* Color Palette Harmonizer */}
          <div className="p-5 rounded-2xl bg-[#FAF8F5] border border-[#EFE8DE]">
            <h4 className="text-xs font-semibold uppercase tracking-[0.2em] text-[#7D7571] mb-3 font-sans">
              Harmonic Color Palette
            </h4>
            <div className="flex items-center gap-2">
              {generatedPrompt.palette.map((color, i) => (
                <div key={i} className="flex-1 flex flex-col items-center gap-1">
                  <div 
                    className="w-full h-10 rounded-lg shadow-2xs border border-black/5" 
                    style={{ backgroundColor: color }} 
                  />
                  <span className="text-[10px] font-mono text-[#7D7571]">{color}</span>
                </div>
              ))}
            </div>
          </div>

          {/* 2-Column Tips */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs font-sans">
            <div className="p-4 rounded-xl bg-[#FAF8F5] border border-[#EFE8DE]">
              <span className="font-bold text-[#2D2926] block mb-1">📐 Composition Strategy:</span>
              <span className="text-[#57514D]">{generatedPrompt.compositionTip}</span>
            </div>
            <div className="p-4 rounded-xl bg-[#FAF8F5] border border-[#EFE8DE]">
              <span className="font-bold text-[#2D2926] block mb-1">🎨 Archival Materials:</span>
              <span className="text-[#57514D]">{generatedPrompt.materials}</span>
            </div>
          </div>

        </div>
      )}
    </div>
  );
};
