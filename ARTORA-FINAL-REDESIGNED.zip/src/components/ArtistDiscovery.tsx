import React, { useState } from 'react';
import { 
  Users, 
  Sparkles, 
  MapPin, 
  Award, 
  TrendingUp, 
  CheckCircle2, 
  X, 
  Mail, 
  ExternalLink, 
  Bookmark, 
  Eye, 
  Heart,
  Palette,
  Send,
  Plus
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { ArtistProfile, Artwork } from '../types';
import { ARTISTS_DATA } from '../data/artistsData';
import { ARTWORKS_DATA } from '../data/artworksData';

interface ArtistDiscoveryProps {
  selectedArtistInitial?: ArtistProfile | null;
  onOpenArtworkDetail?: (artwork: Artwork) => void;
}

export const ArtistDiscovery: React.FC<ArtistDiscoveryProps> = ({
  selectedArtistInitial,
  onOpenArtworkDetail
}) => {
  const [activeSegment, setActiveSegment] = useState<'featured' | 'trending' | 'nearby' | 'all'>('featured');
  const [activeProfile, setActiveProfile] = useState<ArtistProfile | null>(selectedArtistInitial || null);
  const [profileTab, setProfileTab] = useState<'portfolio' | 'about' | 'commission'>('portfolio');
  const [followedArtistIds, setFollowedArtistIds] = useState<string[]>([]);
  const [commissionSent, setCommissionSent] = useState(false);

  const segments = [
    { id: 'featured' as const, label: 'Featured Masters', icon: Sparkles },
    { id: 'trending' as const, label: 'Trending Creators', icon: TrendingUp },
    { id: 'nearby' as const, label: 'Ateliers Near You', icon: MapPin },
    { id: 'all' as const, label: 'All Disciplines', icon: Users }
  ];

  const filteredArtists = ARTISTS_DATA.filter((artist) => {
    if (activeSegment === 'featured') return artist.featured;
    if (activeSegment === 'trending') return artist.trending;
    if (activeSegment === 'nearby') return artist.location.includes('San Francisco') || artist.location.includes('Vienna');
    return true;
  });

  const toggleFollow = (id: string) => {
    if (followedArtistIds.includes(id)) {
      setFollowedArtistIds(followedArtistIds.filter(a => a !== id));
    } else {
      setFollowedArtistIds([...followedArtistIds, id]);
    }
  };

  const handleCommissionSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setCommissionSent(true);
    confetti({ particleCount: 60, spread: 50 });
    setTimeout(() => {
      setCommissionSent(false);
      setProfileTab('portfolio');
    }, 2500);
  };

  return (
    <div className="w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 animate-in fade-in duration-300 bg-[#FAF8F5] text-[#2D2926]">
      
      {/* Header */}
      <div className="text-center max-w-2xl mx-auto mb-10">
        <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-[#FAF2F0] border border-[#EFE6D5] text-[#2D2926] text-xs font-sans font-semibold uppercase tracking-widest mb-3">
          <Users className="w-3.5 h-3.5 text-[#C5A059]" />
          <span>Global Atelier Roster</span>
        </div>
        <h1 className="text-3xl sm:text-5xl font-bodoni font-normal text-[#2D2926] tracking-tight">
          Discover Artists <span className="font-serif italic font-light text-2xl sm:text-4xl text-[#7D7571]">& Master Creators</span>
        </h1>
        <p className="text-xs sm:text-sm text-[#7D7571] font-sans mt-2 leading-relaxed">
          Explore celebrated international ateliers, connect with resident masters, and request bespoke custom commissions.
        </p>
      </div>

      {/* Segment Tabs */}
      <div className="flex items-center justify-center gap-2.5 mb-10 overflow-x-auto no-scrollbar py-1">
        {segments.map((seg) => {
          const Icon = seg.icon;
          const isActive = activeSegment === seg.id;
          return (
            <button
              key={seg.id}
              onClick={() => setActiveSegment(seg.id)}
              className={`flex items-center gap-2 px-4 py-2 rounded-full text-xs font-sans font-semibold tracking-wide transition-all ${
                isActive
                  ? 'bg-[#C5A059] text-[#2D2926] shadow-2xs'
                  : 'bg-[#FFFFFF] border border-[#EFE8DE] text-[#7D7571] hover:bg-[#FAF2F0] hover:text-[#2D2926]'
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              <span>{seg.label}</span>
            </button>
          );
        })}
      </div>

      {/* Artist Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredArtists.map((artist) => {
          const isFollowing = followedArtistIds.includes(artist.id);

          return (
            <div
              key={artist.id}
              className="bg-[#FFFFFF] rounded-2xl border border-[#EFE8DE] overflow-hidden shadow-[0_4px_20px_rgba(45,41,38,0.02)] hover:border-[#C5A059] hover:shadow-[0_8px_24px_rgba(197,160,89,0.08)] transition-all duration-300 flex flex-col justify-between"
            >
              <div>
                {/* Cover Banner & Avatar */}
                <div className="relative h-28 bg-[#FAF2F0]">
                  <img src={artist.coverImage} alt="" className="w-full h-full object-cover" />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent" />
                  
                  <div className="absolute -bottom-6 left-5">
                    <img 
                      src={artist.avatar} 
                      alt={artist.name} 
                      className="w-14 h-14 rounded-xl object-cover border-2 border-[#FFFFFF] shadow-sm"
                    />
                  </div>

                  <div className="absolute top-3 right-3 px-2.5 py-0.5 rounded-full bg-[#FAF8F5]/90 backdrop-blur-md border border-[#EFE6D5] text-[#2D2926] text-[10px] font-sans font-semibold uppercase">
                    {artist.artCategory}
                  </div>
                </div>

                {/* Content */}
                <div className="p-5 pt-8">
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <h3 className="font-serif font-bold text-lg text-[#2D2926] flex items-center gap-1.5">
                        <span>{artist.name}</span>
                        {artist.verified && <CheckCircle2 className="w-4 h-4 text-[#C5A059] fill-[#C5A059] text-white inline" />}
                      </h3>
                      <div className="text-xs font-sans text-[#7D7571]">{artist.handle}</div>
                    </div>
                  </div>

                  <div className="text-xs font-sans font-semibold text-[#C5A059] mt-2">
                    {artist.specialization}
                  </div>

                  <p className="text-xs text-[#57514D] font-sans mt-1.5 line-clamp-2 leading-relaxed">
                    {artist.bio}
                  </p>

                  <div className="flex items-center gap-1.5 text-xs text-[#7D7571] font-sans mt-3">
                    <MapPin className="w-3.5 h-3.5 text-[#C5A059]" />
                    <span>{artist.location}</span>
                  </div>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="p-5 pt-0 flex items-center justify-between border-t border-[#EFE8DE] mt-2">
                <button
                  onClick={() => toggleFollow(artist.id)}
                  className={`px-4 py-1.5 rounded-full text-xs font-sans font-semibold border transition-colors ${
                    isFollowing 
                      ? 'bg-[#FAF2F0] text-[#2D2926] border-[#C5A059]'
                      : 'bg-[#FFFFFF] border-[#EFE8DE] text-[#2D2926] hover:bg-[#FAF2F0]'
                  }`}
                >
                  {isFollowing ? 'Following' : 'Follow Atelier'}
                </button>

                <button
                  id={`view-profile-btn-${artist.id}`}
                  onClick={() => setActiveProfile(artist)}
                  className="px-4 py-1.5 rounded-full bg-[#C5A059] hover:bg-[#B38E46] text-[#2D2926] text-xs font-sans font-semibold shadow-2xs transition-colors"
                >
                  View Atelier
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Full Artist Profile Modal */}
      {activeProfile && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-xs animate-in fade-in duration-200">
          <div 
            className="w-full max-w-4xl max-h-[90vh] overflow-y-auto bg-[#FAF8F5] rounded-2xl border border-[#EFE8DE] shadow-2xl overflow-hidden"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Cover & Header */}
            <div className="relative h-44 sm:h-52 bg-[#FAF2F0]">
              <img src={activeProfile.coverImage} alt="" className="w-full h-full object-cover" />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
              
              <button
                onClick={() => setActiveProfile(null)}
                className="absolute top-4 right-4 p-2 rounded-full bg-[#FAF8F5]/90 text-[#2D2926] hover:bg-[#FAF2F0] transition-colors"
              >
                <X className="w-5 h-5" />
              </button>

              <div className="absolute -bottom-8 left-6 sm:left-8 flex items-end gap-4">
                <img 
                  src={activeProfile.avatar} 
                  alt={activeProfile.name} 
                  className="w-20 h-20 sm:w-24 sm:h-24 rounded-2xl object-cover border-4 border-[#FAF8F5] shadow-lg"
                />
              </div>
            </div>

            {/* Profile Info Bar */}
            <div className="p-6 sm:p-8 pt-10 sm:pt-12">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-[#EFE8DE]">
                <div>
                  <div className="flex items-center gap-2">
                    <h2 className="text-2xl sm:text-3xl font-serif font-bold text-[#2D2926]">
                      {activeProfile.name}
                    </h2>
                    {activeProfile.verified && <CheckCircle2 className="w-5 h-5 text-[#C5A059] fill-[#C5A059] text-white" />}
                  </div>
                  <div className="text-xs text-[#7D7571] font-sans">{activeProfile.handle} • {activeProfile.location}</div>
                  <div className="text-xs font-sans font-semibold text-[#C5A059] mt-1">{activeProfile.specialization}</div>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => toggleFollow(activeProfile.id)}
                    className={`px-5 py-2 rounded-full text-xs font-sans font-semibold ${
                      followedArtistIds.includes(activeProfile.id)
                        ? 'bg-[#FAF2F0] text-[#2D2926] border border-[#C5A059]'
                        : 'bg-[#FFFFFF] border border-[#EFE8DE] text-[#2D2926] hover:bg-[#FAF2F0]'
                    }`}
                  >
                    {followedArtistIds.includes(activeProfile.id) ? 'Following' : 'Follow Atelier'}
                  </button>

                  <button
                    onClick={() => setProfileTab('commission')}
                    className="px-5 py-2 rounded-full bg-[#C5A059] hover:bg-[#B38E46] text-[#2D2926] text-xs font-sans font-semibold uppercase tracking-wider shadow-2xs"
                  >
                    Commission Piece
                  </button>
                </div>
              </div>

              {/* Profile Subtabs */}
              <div className="flex items-center gap-4 border-b border-[#EFE8DE] py-3 my-4">
                <button
                  onClick={() => setProfileTab('portfolio')}
                  className={`text-xs font-sans font-semibold pb-1 border-b-2 transition-all ${
                    profileTab === 'portfolio' ? 'border-[#C5A059] text-[#2D2926]' : 'border-transparent text-[#7D7571]'
                  }`}
                >
                  Gallery & Works
                </button>
                <button
                  onClick={() => setProfileTab('about')}
                  className={`text-xs font-sans font-semibold pb-1 border-b-2 transition-all ${
                    profileTab === 'about' ? 'border-[#C5A059] text-[#2D2926]' : 'border-transparent text-[#7D7571]'
                  }`}
                >
                  Artist Bio & Awards
                </button>
                <button
                  onClick={() => setProfileTab('commission')}
                  className={`text-xs font-sans font-semibold pb-1 border-b-2 transition-all ${
                    profileTab === 'commission' ? 'border-[#C5A059] text-[#2D2926]' : 'border-transparent text-[#7D7571]'
                  }`}
                >
                  Commission Request
                </button>
              </div>

              {/* Tab: Portfolio */}
              {profileTab === 'portfolio' && (
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4 pt-2">
                  {ARTWORKS_DATA.filter(a => a.artistId === activeProfile.id || activeProfile.id === 'artist-elena-rostova').map((art) => (
                    <div key={art.id} className="rounded-xl overflow-hidden border border-[#EFE8DE] bg-[#FFFFFF] shadow-2xs">
                      <div className="aspect-4/3 overflow-hidden bg-[#FAF2F0]">
                        <img src={art.image} alt={art.title} className="w-full h-full object-cover" />
                      </div>
                      <div className="p-3">
                        <div className="font-serif font-bold text-sm text-[#2D2926] truncate">{art.title}</div>
                        <div className="text-[11px] font-sans text-[#7D7571]">${art.price} • {art.artForm}</div>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {/* Tab: About */}
              {profileTab === 'about' && (
                <div className="space-y-4 pt-2 font-sans">
                  <div className="p-4 rounded-xl bg-[#FFFFFF] border border-[#EFE8DE]">
                    <h4 className="text-xs font-semibold uppercase tracking-[0.2em] text-[#7D7571] mb-2">Artist Philosophy</h4>
                    <p className="text-sm text-[#2D2926] leading-relaxed">{activeProfile.bio}</p>
                  </div>
                  <div>
                    <h4 className="text-xs font-semibold uppercase tracking-[0.2em] text-[#7D7571] mb-2">Exhibitions & Distinctions</h4>
                    <div className="flex flex-wrap gap-2">
                      {activeProfile.badges.map((b, i) => (
                        <span key={i} className="px-3 py-1 rounded-full bg-[#FAF2F0] border border-[#EFE6D5] text-[#2D2926] text-xs font-semibold">
                          ★ {b}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {/* Tab: Commission */}
              {profileTab === 'commission' && (
                <div className="pt-2 max-w-lg mx-auto font-sans">
                  {commissionSent ? (
                    <div className="text-center py-6">
                      <CheckCircle2 className="w-10 h-10 text-[#C5A059] mx-auto mb-2" />
                      <h4 className="font-serif font-bold text-base text-[#2D2926]">Commission Brief Dispatched!</h4>
                      <p className="text-xs text-[#7D7571] mt-1">{activeProfile.name} will review your specifications and contact your email.</p>
                    </div>
                  ) : (
                    <form onSubmit={handleCommissionSubmit} className="space-y-3">
                      <h4 className="font-serif font-bold text-base text-[#2D2926]">Commission a Custom Masterpiece</h4>
                      <input 
                        type="text" 
                        required 
                        placeholder="Your Name" 
                        className="w-full text-xs p-3 rounded-xl border border-[#EFE8DE] bg-[#FFFFFF] text-[#2D2926] outline-none focus:border-[#C5A059]"
                      />
                      <input 
                        type="email" 
                        required 
                        placeholder="Your Email" 
                        className="w-full text-xs p-3 rounded-xl border border-[#EFE8DE] bg-[#FFFFFF] text-[#2D2926] outline-none focus:border-[#C5A059]"
                      />
                      <textarea 
                        rows={3} 
                        required 
                        placeholder="Describe what you would like created (medium, subject, approximate scale, timeline)..." 
                        className="w-full text-xs p-3 rounded-xl border border-[#EFE8DE] bg-[#FFFFFF] text-[#2D2926] outline-none focus:border-[#C5A059]"
                      />
                      <button 
                        type="submit" 
                        className="w-full py-3 rounded-full bg-[#C5A059] hover:bg-[#B38E46] text-[#2D2926] text-xs font-sans font-semibold uppercase tracking-wider shadow-2xs"
                      >
                        Submit Commission Proposal
                      </button>
                    </form>
                  )}
                </div>
              )}

            </div>
          </div>
        </div>
      )}
    </div>
  );
};
