import React, { useState, useEffect } from 'react';
import { Play, Pause, X, Music, Volume2, Maximize2 } from 'lucide-react';
import { MusicTrack } from '../types';
import { audioSynth } from '../utils/audioSynthesizer';

interface FloatingAudioPlayerProps {
  track: MusicTrack | null;
  onClose: () => void;
  onOpenMusicMode: () => void;
}

export const FloatingAudioPlayer: React.FC<FloatingAudioPlayerProps> = ({
  track,
  onClose,
  onOpenMusicMode
}) => {
  const [isPlaying, setIsPlaying] = useState(true);
  const [currentTime, setCurrentTime] = useState(0);

  useEffect(() => {
    if (track) {
      setIsPlaying(audioSynth.isCurrentlyPlaying());
    }
    
    audioSynth.setTimeUpdateListener((time, playing) => {
      setCurrentTime(time);
      setIsPlaying(playing);
    });
  }, [track]);

  if (!track) return null;

  const togglePlay = () => {
    if (isPlaying) {
      audioSynth.pause();
      setIsPlaying(false);
    } else {
      audioSynth.resume();
      setIsPlaying(true);
    }
  };

  const progressPercent = Math.min(100, (currentTime / track.duration) * 100);

  return (
    <div className="fixed bottom-20 sm:bottom-6 right-4 sm:right-6 z-40 animate-in slide-in-from-bottom-4 duration-300 font-sans">
      <div className="w-80 sm:w-96 rounded-2xl bg-[#FFFFFF] text-[#2D2926] border border-[#EFE8DE] shadow-[0_8px_30px_rgba(45,41,38,0.12)] p-3.5 backdrop-blur-md">
        
        {/* Top Progress Line */}
        <div className="w-full h-1 bg-[#EFE8DE] rounded-full mb-2.5 overflow-hidden">
          <div 
            className="h-full bg-[#C5A059] rounded-full transition-all duration-150"
            style={{ width: `${progressPercent}%` }}
          />
        </div>

        <div className="flex items-center justify-between gap-3">
          
          {/* Track Info */}
          <div 
            onClick={onOpenMusicMode}
            className="flex items-center gap-2.5 min-w-0 cursor-pointer group"
          >
            <img 
              src={track.coverImage} 
              alt="" 
              className="w-10 h-10 rounded-xl object-cover shrink-0 border border-[#EFE8DE] group-hover:scale-105 transition-transform" 
            />
            <div className="min-w-0">
              <h4 className="font-serif font-bold text-xs truncate group-hover:text-[#C5A059] transition-colors text-[#2D2926]">
                {track.title}
              </h4>
              <p className="text-[10px] text-[#7D7571] truncate">
                {track.artist} • {track.genre}
              </p>
            </div>
          </div>

          {/* Controls */}
          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={togglePlay}
              className="w-8 h-8 rounded-full bg-[#C5A059] hover:bg-[#B38E46] text-[#2D2926] flex items-center justify-center transition-colors shadow-2xs"
              title={isPlaying ? 'Pause' : 'Play'}
            >
              {isPlaying ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5 fill-current ml-0.5" />}
            </button>

            <button
              onClick={onClose}
              className="p-1 rounded-lg text-[#7D7571] hover:text-[#2D2926] hover:bg-[#FAF2F0] transition-colors"
              title="Close music player"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
