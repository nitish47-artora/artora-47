import React, { useRef, useState } from 'react';
import { 
  ChevronLeft, 
  ChevronRight, 
  Sparkles, 
  Grid, 
  Layers, 
  Palette, 
  CheckCircle2,
  Compass
} from 'lucide-react';
import { ArtCategory } from '../types';

interface CategoryPickerProps {
  categories: ArtCategory[];
  activeCategory: ArtCategory;
  onSelectCategory: (category: ArtCategory) => void;
  showFullGridPrompt?: boolean;
  onContinue?: () => void;
}

export const CategoryPicker: React.FC<CategoryPickerProps> = ({
  categories,
  activeCategory,
  onSelectCategory,
  showFullGridPrompt = false,
  onContinue
}) => {
  const scrollRef = useRef<HTMLDivElement>(null);

  const scroll = (direction: 'left' | 'right') => {
    if (scrollRef.current) {
      const scrollAmount = direction === 'left' ? -280 : 280;
      scrollRef.current.scrollBy({ left: scrollAmount, behavior: 'smooth' });
    }
  };

  // If this is the standalone onboarding step ("What kind of art are you interested in?")
  if (showFullGridPrompt) {
    return (
      <div className="w-full max-w-6xl mx-auto px-4 py-10 animate-in fade-in duration-300 bg-[#FAF8F5] text-[#2D2926]">
        <div className="text-center max-w-2xl mx-auto mb-10">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#FAF2F0] border border-[#EFE6D5] text-[#2D2926] text-xs font-sans font-medium uppercase tracking-[0.2em] mb-4">
            <Sparkles className="w-3.5 h-3.5 text-[#C5A059]" />
            <span>Curate Your Journey</span>
          </div>
          <h2 className="text-3xl sm:text-5xl font-bodoni font-normal text-[#2D2926] tracking-tight">
            What kind of art are you interested in?
          </h2>
          <p className="mt-3 text-sm sm:text-base text-[#7D7571] font-sans">
            Select an art discipline to enter the atelier. You can effortlessly switch between all 26+ art forms anytime.
          </p>
        </div>

        {/* 26+ Art Categories Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4 sm:gap-5 mb-10">
          {categories.map((cat) => {
            const isSelected = cat.id === activeCategory.id;
            return (
              <button
                key={cat.id}
                id={`category-card-select-${cat.id}`}
                onClick={() => onSelectCategory(cat)}
                className={`group relative flex flex-col items-start p-3.5 sm:p-4 rounded-2xl text-left border transition-all duration-200 overflow-hidden ${
                  isSelected
                    ? 'border-[#C5A059] bg-[#FAF2F0] shadow-[0_4px_16px_rgba(197,160,89,0.15)] ring-1 ring-[#C5A059] scale-[1.02]'
                    : 'border-[#EFE8DE] bg-[#FFFFFF] hover:border-[#C5A059] hover:shadow-[0_4px_12px_rgba(0,0,0,0.03)]'
                }`}
              >
                <div className="relative w-full aspect-4/3 rounded-xl overflow-hidden mb-3 bg-[#FAF8F5] border border-[#EFE8DE]">
                  <img 
                    src={cat.coverImage} 
                    alt={cat.name} 
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    loading="lazy"
                  />
                  {isSelected && (
                    <div className="absolute top-2 right-2 bg-[#C5A059] text-white rounded-full p-1 shadow-sm">
                      <CheckCircle2 className="w-3.5 h-3.5" />
                    </div>
                  )}
                </div>

                <div className="w-full">
                  <h3 className="font-serif font-bold text-sm text-[#2D2926] truncate">
                    {cat.name}
                  </h3>
                  <p className="text-[11px] text-[#7D7571] font-sans line-clamp-1 mt-0.5">
                    {cat.tagline}
                  </p>
                </div>
              </button>
            );
          })}
        </div>

        {/* Continue Action */}
        <div className="flex items-center justify-center gap-4">
          <button
            id="continue-after-category-select-button"
            onClick={onContinue}
            className="flex items-center gap-2 px-8 py-3.5 rounded-full bg-[#C5A059] hover:bg-[#B38E46] text-[#2D2926] text-xs font-sans font-semibold tracking-wider uppercase shadow-[0_4px_16px_rgba(197,160,89,0.25)] transition-all duration-200"
          >
            <span>Explore {activeCategory.name} Atelier</span>
            <Compass className="w-4 h-4" />
          </button>
        </div>
      </div>
    );
  }

  {/* Sticky Horizontal Carousel for top of gallery pages */}
  return (
    <div className="w-full bg-[#FAF8F5] border-b border-[#EFE8DE] py-3.5 transition-colors sticky top-20 z-30 backdrop-blur-md bg-[#FAF8F5]/95">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between gap-3">
          
          {/* Scroll Left Button */}
          <button
            id="carousel-scroll-left-button"
            onClick={() => scroll('left')}
            className="hidden sm:flex items-center justify-center w-8 h-8 rounded-full bg-[#FFFFFF] border border-[#EFE8DE] hover:border-[#C5A059] text-[#2D2926] transition-colors shrink-0 shadow-2xs"
            aria-label="Scroll categories left"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>

          {/* Horizontal Category Chips Container */}
          <nav 
            ref={scrollRef}
            className="flex items-center gap-2 overflow-x-auto no-scrollbar scroll-smooth py-1 px-1 flex-1"
          >
            {categories.map((cat) => {
              const isSelected = cat.id === activeCategory.id;
              return (
                <button
                  key={cat.id}
                  id={`category-chip-${cat.id}`}
                  onClick={() => onSelectCategory(cat)}
                  className={`px-4 py-2 rounded-full text-xs font-sans font-medium whitespace-nowrap transition-all duration-200 shrink-0 border ${
                    isSelected
                      ? 'bg-[#FAF2F0] text-[#2D2926] border-[#C5A059] font-semibold shadow-[0_2px_8px_rgba(197,160,89,0.12)]'
                      : 'bg-[#FFFFFF] text-[#57514D] border-[#EFE8DE] hover:border-[#C5A059] hover:text-[#2D2926]'
                  }`}
                >
                  {cat.name}
                </button>
              );
            })}
          </nav>

          {/* Scroll Right Button */}
          <button
            id="carousel-scroll-right-button"
            onClick={() => scroll('right')}
            className="hidden sm:flex items-center justify-center w-8 h-8 rounded-full bg-[#FFFFFF] border border-[#EFE8DE] hover:border-[#C5A059] text-[#2D2926] transition-colors shrink-0 shadow-2xs"
            aria-label="Scroll categories right"
          >
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
