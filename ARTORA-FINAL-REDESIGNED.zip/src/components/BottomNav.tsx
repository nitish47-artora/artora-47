import React from 'react';
import { 
  Compass, 
  BookOpen, 
  Sparkles, 
  ShoppingBag, 
  PlusCircle
} from 'lucide-react';
import { MainMode } from '../types';

interface BottomNavProps {
  currentMode: MainMode;
  onSelectMode: (mode: MainMode) => void;
}

export const BottomNav: React.FC<BottomNavProps> = ({
  currentMode,
  onSelectMode
}) => {
  const items: { mode: MainMode; label: string; icon: React.ComponentType<{ className?: string }> }[] = [
    { mode: 'home', label: 'Home', icon: Compass },
    { mode: 'learn', label: 'Learn', icon: BookOpen },
    { mode: 'discover', label: 'Discover', icon: Sparkles },
    { mode: 'buy', label: 'Buy Art', icon: ShoppingBag },
    { mode: 'pitch', label: 'Pitch', icon: PlusCircle }
  ];

  return (
    <nav className="lg:hidden fixed bottom-0 left-0 right-0 z-40 bg-[#FAF8F5]/95 backdrop-blur-md border-t border-[#EFE8DE] transition-colors shadow-[0_-4px_20px_rgba(45,41,38,0.04)]">
      <div className="grid grid-cols-5 h-16 max-w-lg mx-auto px-2">
        {items.map((item) => {
          const Icon = item.icon;
          const isActive = currentMode === item.mode;
          return (
            <button
              key={item.mode}
              id={`bottom-nav-${item.mode}-button`}
              onClick={() => onSelectMode(item.mode)}
              className={`flex flex-col items-center justify-center gap-1 focus:outline-none transition-all py-1 ${
                isActive 
                  ? 'text-[#2D2926]' 
                  : 'text-[#7D7571] hover:text-[#2D2926]'
              }`}
            >
              <div className={`p-1.5 rounded-full transition-all duration-200 ${
                isActive 
                  ? 'bg-[#FAF2F0] text-[#C5A059] border border-[#EFE6D5] scale-110 shadow-xs' 
                  : 'text-[#2D2926]'
              }`}>
                <Icon className="w-4 h-4" />
              </div>
              <span className={`text-[10px] font-sans tracking-tight ${isActive ? 'font-bold text-[#2D2926]' : 'font-medium text-[#7D7571]'}`}>
                {item.label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
};
