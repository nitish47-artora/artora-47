import React, { useState } from 'react';
import { Calendar, MapPin, Users, ArrowRight } from 'lucide-react';
import { WORKSHOPS_DATA } from '../data/workshopsData';

export const WorkshopsLanding: React.FC = () => {
  const [booked, setBooked] = useState<string[]>([]);
  const arts = ['All', ...Array.from(new Set(WORKSHOPS_DATA.map(w => w.artForm)))];
  const [filter, setFilter] = useState('All');
  const workshops = filter === 'All' ? WORKSHOPS_DATA : WORKSHOPS_DATA.filter(w => w.artForm === filter);
  return <div className="max-w-6xl mx-auto px-4 sm:px-6 py-8">
    <div className="mb-7"><div className="text-[10px] font-bold tracking-[.22em] text-[#C5A059] uppercase">Workshops</div><h1 className="font-serif text-4xl font-bold text-[#2D2926] mt-1">Learn with artists, live.</h1><p className="text-sm text-[#7D7571] mt-2">Choose your interested art, reserve a place, and build your ARTORA score through performance.</p></div>
    <div className="flex gap-2 overflow-x-auto no-scrollbar pb-2 mb-6">{arts.map(a => <button key={a} onClick={() => setFilter(a)} className={`px-4 py-2 rounded-full text-xs font-semibold whitespace-nowrap border ${filter===a?'bg-[#C5A059] text-[#2D2926] border-[#C5A059]':'bg-white text-[#7D7571] border-[#EFE8DE]'}`}>{a}</button>)}</div>
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">{workshops.map(w => { const isBooked=booked.includes(w.id); return <div key={w.id} className="bg-white border border-[#EFE8DE] rounded-2xl overflow-hidden shadow-[0_4px_20px_rgba(45,41,38,.03)]"><img src={w.image} className="w-full h-44 object-cover"/><div className="p-5"><div className="text-[10px] font-bold uppercase tracking-wider text-[#C5A059]">{w.artForm} • {w.difficulty}</div><h3 className="font-serif text-xl font-bold text-[#2D2926] mt-1">{w.title}</h3><p className="text-xs text-[#7D7571] mt-2 line-clamp-2">{w.description}</p><div className="space-y-2 mt-4 text-xs text-[#57514D]"><div className="flex gap-2"><Calendar className="w-3.5 h-3.5 text-[#C5A059]"/>{w.date} • {w.time}</div><div className="flex gap-2"><MapPin className="w-3.5 h-3.5 text-[#C5A059]"/>{w.locationName}</div><div className="flex gap-2"><Users className="w-3.5 h-3.5 text-[#C5A059]"/>{w.spotsRemaining} spots remaining</div></div><button onClick={()=>setBooked(v=>isBooked?v.filter(id=>id!==w.id):[...v,w.id])} className={`mt-5 w-full py-2.5 rounded-full text-xs font-bold ${isBooked?'bg-[#FAF2F0] text-[#2D2926] border border-[#C5A059]':'bg-[#C5A059] text-[#2D2926]'}`}>{isBooked?'Booked • Added to My Activity':'Book Workshop'} <ArrowRight className="inline w-3.5 h-3.5 ml-1"/></button></div></div>})}</div>
  </div>;
};
