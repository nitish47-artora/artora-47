import React, { useState } from 'react';
import { 
  Sparkles, 
  Search, 
  Settings, 
  Bookmark, 
  PlusCircle, 
  Music, 
  Compass, 
  BookOpen, 
  ShoppingBag, 
  MapPin, 
  Menu,
  X,
  Palette,
  ChevronDown,
  Smartphone
} from 'lucide-react';
import { MainMode, ArtCategory } from '../types';

interface NavbarProps {
  currentMode: MainMode;
  onSelectMode: (mode: MainMode) => void;
  activeCategory: ArtCategory;
  categories: ArtCategory[];
  onSelectCategory: (category: ArtCategory) => void;
  darkMode: boolean;
  onToggleDarkMode: () => void;
  onOpenSettings: () => void;
  onOpenBookmarks: () => void;
  onOpenAndroidHub?: () => void;
  savedCount: number;
  onSearchQuery?: (q: string) => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentMode,
  onSelectMode,
  activeCategory,
  categories,
  onSelectCategory,
  onOpenSettings,
  onOpenBookmarks,
  onOpenAndroidHub,
  savedCount,
  onSearchQuery
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [searchValue, setSearchValue] = useState('');
  const [categoryDropdownOpen, setCategoryDropdownOpen] = useState(false);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (onSearchQuery) onSearchQuery(searchValue);
  };

  const navLinks: { mode: MainMode; label: string; icon: React.ComponentType<{ className?: string }> }[] = [
    { mode: 'home', label: 'Home', icon: Compass },
    { mode: 'learn', label: 'Learn & Explore', icon: BookOpen },
    { mode: 'discover', label: 'Discover', icon: Sparkles },
    { mode: 'buy', label: 'Buy Art', icon: ShoppingBag },
    { mode: 'pitch', label: 'Pitch Art', icon: PlusCircle },
    { mode: 'music', label: 'Music', icon: Music },
    { mode: 'events', label: 'Exhibitions', icon: MapPin }
  ];

  return (
    <header className="sticky top-0 z-40 w-full backdrop-blur-md bg-[#FAF8F5]/90 border-b border-[#EFE8DE] transition-colors duration-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20 gap-4">
          
          {/* Left: Brand Logo & Discipline Switcher */}
          <div className="flex items-center gap-4 sm:gap-6">
            <button 
              id="brand-logo-button"
              onClick={() => onSelectMode('home')}
              className="flex items-center gap-3 text-left group focus:outline-none"
              title="ARTORA — Contemporary Fine Art & Creative Studio"
            >
              {/* Refined Fine-Art Emblem */}
              <div className="relative w-10 h-10 rounded-xl bg-[#FAF2F0] border border-[#EFE8DE] flex items-center justify-center shadow-[0_2px_8px_rgba(197,160,89,0.12)] group-hover:border-[#C5A059] group-hover:scale-105 transition-all duration-300">
                <svg className="w-5 h-5 transition-transform duration-300 group-hover:scale-110" viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path 
                    d="M 50 14 L 32 82 L 41 82 L 45 66 L 55 66 L 59 82 L 68 82 L 50 14 Z M 50 28 L 53.5 58 L 46.5 58 L 50 28 Z" 
                    fill="#2D2926"
                  />
                  <circle cx="50" cy="12" r="4.5" fill="#C5A059" />
                  <path 
                    d="M 28 84 Q 50 92 72 84" 
                    stroke="#C5A059" 
                    strokeWidth="3" 
                    strokeLinecap="round" 
                  />
                </svg>
              </div>
              <div className="flex flex-col justify-center">
                <span className="font-bodoni font-bold text-2xl tracking-[0.24em] text-[#2D2926] leading-none group-hover:text-[#C5A059] transition-colors">
                  ARTORA
                </span>
                <span className="text-[9px] uppercase tracking-[0.38em] text-[#7D7571] font-medium mt-1 font-sans">
                  Fine Art Platform
                </span>
              </div>
            </button>

            {/* Quick Active Category Badge / Dropdown */}
            <div className="relative">
              <button
                id="active-category-pill-button"
                onClick={() => setCategoryDropdownOpen(!categoryDropdownOpen)}
                className="hidden md:flex items-center gap-2 px-3.5 py-1.5 rounded-full text-xs font-medium border border-[#EFE8DE] bg-[#FFFFFF] hover:border-[#C5A059] text-[#2D2926] transition-all duration-200 shadow-[0_2px_6px_rgba(0,0,0,0.02)]"
                title="Current active art category — tap to switch"
              >
                <span 
                  className="w-2 h-2 rounded-full ring-2 ring-[#FAF2F0]"
                  style={{ backgroundColor: activeCategory.color || '#C5A059' }}
                />
                <span className="text-[#57514D] font-sans">{activeCategory.name}</span>
                <ChevronDown className="w-3 h-3 text-[#7D7571]" />
              </button>

              {/* Category Quick Selector Dropdown */}
              {categoryDropdownOpen && (
                <div 
                  className="absolute left-0 mt-2 w-64 max-h-80 overflow-y-auto rounded-2xl bg-[#FFFFFF] border border-[#EFE8DE] shadow-[0_10px_30px_rgba(45,41,38,0.08)] py-2 z-50 animate-in fade-in zoom-in-95 duration-150"
                  onMouseLeave={() => setCategoryDropdownOpen(false)}
                >
                  <div className="px-3.5 py-1.5 text-[10px] font-semibold uppercase tracking-[0.2em] text-[#7D7571] border-b border-[#EFE8DE]">
                    Select Art Discipline
                  </div>
                  {categories.map((cat) => (
                    <button
                      key={cat.id}
                      onClick={() => {
                        onSelectCategory(cat);
                        setCategoryDropdownOpen(false);
                      }}
                      className={`w-full text-left px-3.5 py-2 text-xs font-sans flex items-center justify-between transition-colors ${
                        cat.id === activeCategory.id 
                          ? 'bg-[#FAF2F0] text-[#2D2926] font-semibold' 
                          : 'text-[#57514D] hover:bg-[#FAF8F5]'
                      }`}
                    >
                      <span className="flex items-center gap-2.5">
                        <span 
                          className="w-2 h-2 rounded-full" 
                          style={{ backgroundColor: cat.color }} 
                        />
                        {cat.name}
                      </span>
                      {cat.id === activeCategory.id && (
                        <span className="text-[10px] px-2 py-0.5 rounded-full bg-[#C5A059] text-white font-medium">
                          Active
                        </span>
                      )}
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Center: Editorial Navigation Links */}
          <nav className="hidden lg:flex items-center gap-1.5">
            {navLinks.slice(0, 5).map((item) => {
              const Icon = item.icon;
              const isActive = currentMode === item.mode;
              return (
                <button
                  key={item.mode}
                  id={`nav-${item.mode}-button`}
                  onClick={() => onSelectMode(item.mode)}
                  className={`flex items-center gap-2 px-4 py-2 rounded-full text-xs tracking-wide transition-all duration-200 whitespace-nowrap ${
                    isActive
                      ? 'bg-[#FAF2F0] text-[#2D2926] font-semibold border border-[#EFE6D5] shadow-[0_2px_8px_rgba(197,160,89,0.1)]'
                      : 'text-[#57514D] hover:text-[#2D2926] hover:bg-[#FFFFFF]'
                  }`}
                >
                  <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-[#C5A059]' : 'text-[#7D7571]'}`} />
                  <span className="font-sans">{item.label}</span>
                </button>
              );
            })}
          </nav>

          {/* Right Actions */}
          <div className="flex items-center gap-2 sm:gap-3">
            
            {/* Search Input */}
            <form onSubmit={handleSearch} className="relative hidden sm:flex items-center bg-[#FFFFFF] px-3.5 py-1.5 rounded-full w-44 md:w-56 border border-[#EFE8DE] focus-within:border-[#C5A059] transition-all shadow-[0_2px_6px_rgba(0,0,0,0.02)]">
              <Search className="w-3.5 h-3.5 text-[#7D7571] mr-2" />
              <input
                id="global-search-input"
                type="text"
                placeholder="Search artworks, artists..."
                value={searchValue}
                onChange={(e) => {
                  setSearchValue(e.target.value);
                  if (onSearchQuery) onSearchQuery(e.target.value);
                }}
                className="bg-transparent border-none outline-none text-xs w-full text-[#2D2926] placeholder-[#7D7571] font-sans"
              />
            </form>

            {/* Android Native Kotlin Compose App Inspector */}
            {onOpenAndroidHub && (
              <button
                id="open-android-hub-button"
                onClick={onOpenAndroidHub}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-[#FAF2F0] hover:bg-[#FAF8F5] text-[#2D2926] border border-[#EFE6D5] transition-all shadow-[0_2px_6px_rgba(0,0,0,0.02)]"
                title="View Native Android (Kotlin + Jetpack Compose) Source Code"
              >
                <Smartphone className="w-3.5 h-3.5 text-[#C5A059]" />
                <span className="text-[11px] font-semibold font-sans hidden md:inline">Android Compose</span>
              </button>
            )}

            {/* Saved Bookmarks Button with Pale Pink Badge */}
            <button
              id="saved-bookmarks-button"
              onClick={onOpenBookmarks}
              className="relative p-2.5 rounded-full bg-[#FFFFFF] text-[#2D2926] hover:bg-[#FAF2F0] border border-[#EFE8DE] transition-colors focus:outline-none shadow-[0_2px_6px_rgba(0,0,0,0.02)]"
              title="Saved Collection & Tutorials"
            >
              <Bookmark className="w-4 h-4 text-[#57514D] hover:text-[#C5A059]" />
              {savedCount > 0 && (
                <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-[#FCEAE6] text-[#9E4A3B] border border-[#F5D5CE] text-[10px] font-bold flex items-center justify-center">
                  {savedCount}
                </span>
              )}
            </button>

            {/* Settings Modal Button */}
            <button
              id="open-settings-button"
              onClick={onOpenSettings}
              className="p-2.5 rounded-full bg-[#FFFFFF] text-[#57514D] hover:text-[#2D2926] hover:bg-[#FAF2F0] border border-[#EFE8DE] transition-colors focus:outline-none shadow-[0_2px_6px_rgba(0,0,0,0.02)]"
              title="Studio Preferences"
            >
              <Settings className="w-4 h-4" />
            </button>

            {/* User Profile Emblem */}
            <div className="hidden xl:flex items-center gap-2.5 pl-2 border-l border-[#EFE8DE]">
              <div className="text-right">
                <p className="text-xs font-semibold text-[#2D2926] font-sans">Alex Rivera</p>
                <p className="text-[10px] text-[#7D7571] font-serif italic">Collector & Creator</p>
              </div>
              <div className="w-9 h-9 rounded-full bg-[#FAF2F0] border border-[#EFE6D5] shadow-xs flex items-center justify-center font-serif font-bold text-xs text-[#2D2926]">
                AR
              </div>
            </div>

            {/* Pitch Art Primary Action - Sophisticated Gold / Soft Yellow CTA */}
            <button
              id="pitch-art-cta-header-button"
              onClick={() => onSelectMode('pitch')}
              className="flex items-center gap-2 px-4 py-2 rounded-full bg-[#C5A059] hover:bg-[#B38E46] text-[#2D2926] text-xs font-semibold tracking-wide shadow-[0_2px_10px_rgba(197,160,89,0.25)] transition-all font-sans"
            >
              <PlusCircle className="w-3.5 h-3.5 text-[#2D2926]" />
              <span>Pitch Art</span>
            </button>

            {/* Mobile Menu Toggle */}
            <button
              id="mobile-menu-toggle-button"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden p-2.5 rounded-full bg-[#FFFFFF] text-[#2D2926] border border-[#EFE8DE] hover:bg-[#FAF2F0] transition-colors"
            >
              {mobileMenuOpen ? <X className="w-4 h-4" /> : <Menu className="w-4 h-4" />}
            </button>
          </div>
        </div>

        {/* Mobile Dropdown Menu */}
        {mobileMenuOpen && (
          <div className="lg:hidden py-4 border-t border-[#EFE8DE] animate-in slide-in-from-top-2 duration-150">
            <div className="grid grid-cols-2 gap-2 mb-2">
              {navLinks.map((item) => {
                const Icon = item.icon;
                const isActive = currentMode === item.mode;
                return (
                  <button
                    key={item.mode}
                    onClick={() => {
                      onSelectMode(item.mode);
                      setMobileMenuOpen(false);
                    }}
                    className={`flex items-center gap-2 px-3.5 py-2.5 rounded-xl text-xs font-sans transition-colors ${
                      isActive
                        ? 'bg-[#FAF2F0] text-[#2D2926] font-semibold border border-[#EFE6D5]'
                        : 'bg-[#FFFFFF] text-[#57514D] hover:bg-[#FAF8F5] border border-[#EFE8DE]'
                    }`}
                  >
                    <Icon className={`w-4 h-4 ${isActive ? 'text-[#C5A059]' : 'text-[#7D7571]'}`} />
                    <span>{item.label}</span>
                  </button>
                );
              })}
            </div>
          </div>
        )}
      </div>
    </header>
  );
};
