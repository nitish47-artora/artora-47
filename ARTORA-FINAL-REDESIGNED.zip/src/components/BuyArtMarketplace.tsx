import React, { useState } from 'react';
import { 
  ShoppingBag, 
  Search, 
  Filter, 
  Sparkles, 
  CheckCircle2, 
  X, 
  Mail, 
  ExternalLink, 
  Send, 
  Bookmark, 
  Heart,
  SlidersHorizontal,
  ChevronRight
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { Artwork, ArtistProfile } from '../types';
import { ARTWORKS_DATA } from '../data/artworksData';
import { ARTISTS_DATA } from '../data/artistsData';

interface BuyArtMarketplaceProps {
  initialArtwork?: Artwork | null;
  onSelectArtist: (artist: ArtistProfile) => void;
  userArtworks?: Artwork[];
  savedArtworkIds: string[];
  onToggleSave: (id: string) => void;
}

export const BuyArtMarketplace: React.FC<BuyArtMarketplaceProps> = ({
  initialArtwork,
  onSelectArtist,
  userArtworks = [],
  savedArtworkIds,
  onToggleSave
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedMedium, setSelectedMedium] = useState('all');
  const [maxPrice, setMaxPrice] = useState(1500);
  const [selectedArtwork, setSelectedArtwork] = useState<Artwork | null>(initialArtwork || null);
  
  // Inquiry Modal State
  const [inquiryArtwork, setInquiryArtwork] = useState<Artwork | null>(null);
  const [inquiryType, setInquiryType] = useState<'purchase' | 'commission' | 'question'>('purchase');
  const [inquiryName, setInquiryName] = useState('');
  const [inquiryEmail, setInquiryEmail] = useState('');
  const [inquiryMessage, setInquiryMessage] = useState('');
  const [inquirySent, setInquirySent] = useState(false);

  // Combine default artworks with any published user artworks
  const allMarketplaceArt = [...userArtworks, ...ARTWORKS_DATA];

  const mediums = ['all', 'Watercolor', 'Photography', 'Pottery & Ceramics', 'Crochet', 'Digital Painting', 'Traditional Madhubani'];

  const filteredArt = allMarketplaceArt.filter((art) => {
    const matchesSearch = art.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          art.artistName.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          art.artForm.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesMedium = selectedMedium === 'all' || art.artForm.toLowerCase().includes(selectedMedium.toLowerCase());
    const matchesPrice = art.price <= maxPrice;
    return matchesSearch && matchesMedium && matchesPrice;
  });

  const handleSendInquiry = (e: React.FormEvent) => {
    e.preventDefault();
    setInquirySent(true);
    confetti({
      particleCount: 70,
      spread: 60,
      origin: { y: 0.6 }
    });
    setTimeout(() => {
      setInquirySent(false);
      setInquiryArtwork(null);
      setInquiryMessage('');
    }, 2500);
  };

  return (
    <div className="w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 animate-in fade-in duration-300 bg-[#FAF8F5] text-[#2D2926]">
      
      {/* Header */}
      <div className="text-center max-w-2xl mx-auto mb-10">
        <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-[#FAF2F0] border border-[#EFE6D5] text-[#2D2926] text-xs font-sans font-semibold uppercase tracking-widest mb-3">
          <ShoppingBag className="w-3.5 h-3.5 text-[#C5A059]" />
          <span>Curated Fine Art Atelier</span>
        </div>
        <h1 className="text-3xl sm:text-5xl font-bodoni font-normal text-[#2D2926] tracking-tight">
          Original Masterworks <span className="font-serif italic font-light text-2xl sm:text-4xl text-[#7D7571]">For Sale</span>
        </h1>
        <p className="text-xs sm:text-sm text-[#7D7571] font-sans mt-2 leading-relaxed">
          Acquire authentic originals, signed limited editions, and bespoke commissions directly from independent fine artists.
        </p>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-[#FFFFFF] rounded-2xl p-5 border border-[#EFE8DE] shadow-[0_4px_20px_rgba(45,41,38,0.02)] mb-8">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-4 items-center">
          
          {/* Search Box */}
          <div className="md:col-span-5 relative">
            <input
              type="text"
              placeholder="Search by title, master artist, or technique..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full text-xs sm:text-sm pl-9 pr-3 py-2.5 rounded-xl bg-[#FAF8F5] border border-[#EFE8DE] text-[#2D2926] placeholder-[#A09890] outline-none focus:border-[#C5A059] font-sans"
            />
            <Search className="w-4 h-4 text-[#7D7571] absolute left-3 top-1/2 -translate-y-1/2" />
          </div>

          {/* Medium Chips */}
          <div className="md:col-span-5 flex items-center gap-1.5 overflow-x-auto no-scrollbar py-1">
            {mediums.map((m) => (
              <button
                key={m}
                onClick={() => setSelectedMedium(m)}
                className={`px-3 py-1.5 rounded-full text-xs font-sans font-semibold whitespace-nowrap transition-all ${
                  selectedMedium === m
                    ? 'bg-[#C5A059] text-[#2D2926] shadow-2xs'
                    : 'bg-[#FAF8F5] border border-[#EFE8DE] text-[#7D7571] hover:bg-[#FAF2F0] hover:text-[#2D2926]'
                }`}
              >
                {m === 'all' ? 'All Mediums' : m}
              </button>
            ))}
          </div>

          {/* Price Range Slider */}
          <div className="md:col-span-2 flex items-center gap-2">
            <span className="text-[11px] text-[#7D7571] font-sans font-semibold whitespace-nowrap">Under ${maxPrice}</span>
            <input
              type="range"
              min={100}
              max={2000}
              step={50}
              value={maxPrice}
              onChange={(e) => setMaxPrice(Number(e.target.value))}
              className="w-full accent-[#C5A059]"
            />
          </div>
        </div>
      </div>

      {/* Artwork Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredArt.map((art) => {
          const isSaved = savedArtworkIds.includes(art.id);
          const artist = ARTISTS_DATA.find(a => a.id === art.artistId) || ARTISTS_DATA[0];

          return (
            <div
              key={art.id}
              className="group bg-[#FFFFFF] rounded-2xl border border-[#EFE8DE] overflow-hidden shadow-[0_4px_20px_rgba(45,41,38,0.02)] hover:border-[#C5A059] hover:shadow-[0_8px_24px_rgba(197,160,89,0.08)] transition-all duration-300 flex flex-col justify-between"
            >
              <div>
                <div 
                  className="relative w-full aspect-4/3 overflow-hidden bg-[#FAF2F0] cursor-pointer"
                  onClick={() => setSelectedArtwork(art)}
                >
                  <img 
                    src={art.image} 
                    alt={art.title} 
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                  <div className="absolute top-3.5 left-3.5 px-3 py-1 rounded-full bg-[#FAF8F5]/95 backdrop-blur-md border border-[#EFE6D5] text-[#2D2926] text-[10px] font-sans font-semibold uppercase tracking-wider">
                    {art.artForm}
                  </div>
                  <div className="absolute top-3.5 right-3.5 px-3.5 py-1 rounded-full bg-[#C5A059] text-[#2D2926] text-xs font-sans font-bold shadow-sm">
                    ${art.price}
                  </div>
                </div>

                <div className="p-5">
                  <div className="flex items-start justify-between gap-2 mb-1">
                    <h3 
                      onClick={() => setSelectedArtwork(art)}
                      className="font-serif font-bold text-lg text-[#2D2926] truncate cursor-pointer hover:text-[#C5A059] transition-colors"
                    >
                      {art.title}
                    </h3>
                  </div>
                  <p className="text-xs text-[#7D7571] font-sans truncate">
                    {art.materials}
                  </p>
                  <p className="text-xs text-[#57514D] font-sans mt-2 line-clamp-2 leading-relaxed">
                    {art.description}
                  </p>
                </div>
              </div>

              {/* Action Bar */}
              <div className="p-5 pt-0 flex items-center justify-between border-t border-[#EFE8DE] mt-2">
                <button
                  onClick={() => onSelectArtist(artist)}
                  className="text-xs font-sans font-semibold text-[#2D2926] hover:text-[#C5A059] flex items-center gap-2"
                >
                  <img src={art.artistAvatar} alt="" className="w-6 h-6 rounded-full object-cover border border-[#EFE8DE]" />
                  <span className="truncate max-w-[110px]">{art.artistName}</span>
                </button>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => {
                      setInquiryArtwork(art);
                      setInquiryType('purchase');
                    }}
                    className="px-4 py-1.5 rounded-full bg-[#C5A059] hover:bg-[#B38E46] text-[#2D2926] text-xs font-sans font-semibold shadow-2xs transition-colors"
                  >
                    Acquire / Inquire
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Purchase / Inquiry Modal */}
      {inquiryArtwork && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-xs animate-in fade-in duration-200">
          <div 
            className="w-full max-w-lg bg-[#FAF8F5] rounded-2xl border border-[#EFE8DE] p-7 shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between pb-3 mb-4 border-b border-[#EFE8DE]">
              <div className="flex items-center gap-2">
                <Mail className="w-5 h-5 text-[#C5A059]" />
                <h3 className="font-serif font-bold text-lg text-[#2D2926]">
                  Atelier Acquisition & Commission
                </h3>
              </div>
              <button 
                onClick={() => setInquiryArtwork(null)}
                className="p-1 rounded-full text-[#7D7571] hover:bg-[#FAF2F0]"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {inquirySent ? (
              <div className="text-center py-6 space-y-2">
                <CheckCircle2 className="w-12 h-12 text-[#C5A059] mx-auto" />
                <h4 className="font-serif font-bold text-lg text-[#2D2926]">Inquiry Sent Successfully!</h4>
                <p className="text-xs text-[#7D7571] font-sans">The artist will review your request and reply via email shortly.</p>
              </div>
            ) : (
              <form onSubmit={handleSendInquiry} className="space-y-4 font-sans">
                <div className="p-3.5 rounded-xl bg-[#FFFFFF] border border-[#EFE8DE] flex items-center gap-3.5">
                  <img src={inquiryArtwork.image} alt="" className="w-12 h-12 rounded-lg object-cover" />
                  <div>
                    <div className="text-xs font-serif font-bold text-[#2D2926]">{inquiryArtwork.title}</div>
                    <div className="text-[11px] text-[#7D7571]">by {inquiryArtwork.artistName} • ${inquiryArtwork.price}</div>
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-2">
                  <button
                    type="button"
                    onClick={() => setInquiryType('purchase')}
                    className={`py-2 rounded-xl text-xs font-sans font-semibold border ${
                      inquiryType === 'purchase' ? 'bg-[#C5A059] text-[#2D2926] border-[#C5A059]' : 'bg-[#FFFFFF] border-[#EFE8DE] text-[#7D7571]'
                    }`}
                  >
                    Buy Original
                  </button>
                  <button
                    type="button"
                    onClick={() => setInquiryType('commission')}
                    className={`py-2 rounded-xl text-xs font-sans font-semibold border ${
                      inquiryType === 'commission' ? 'bg-[#C5A059] text-[#2D2926] border-[#C5A059]' : 'bg-[#FFFFFF] border-[#EFE8DE] text-[#7D7571]'
                    }`}
                  >
                    Commission
                  </button>
                  <button
                    type="button"
                    onClick={() => setInquiryType('question')}
                    className={`py-2 rounded-xl text-xs font-sans font-semibold border ${
                      inquiryType === 'question' ? 'bg-[#C5A059] text-[#2D2926] border-[#C5A059]' : 'bg-[#FFFFFF] border-[#EFE8DE] text-[#7D7571]'
                    }`}
                  >
                    Atelier Question
                  </button>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <input
                    type="text"
                    required
                    placeholder="Your Name"
                    value={inquiryName}
                    onChange={(e) => setInquiryName(e.target.value)}
                    className="w-full text-xs p-3 rounded-xl border border-[#EFE8DE] bg-[#FFFFFF] text-[#2D2926] outline-none focus:border-[#C5A059]"
                  />
                  <input
                    type="email"
                    required
                    placeholder="Your Email"
                    value={inquiryEmail}
                    onChange={(e) => setInquiryEmail(e.target.value)}
                    className="w-full text-xs p-3 rounded-xl border border-[#EFE8DE] bg-[#FFFFFF] text-[#2D2926] outline-none focus:border-[#C5A059]"
                  />
                </div>

                <textarea
                  rows={3}
                  required
                  placeholder="Inquire about delivery, framing options, or custom commission details..."
                  value={inquiryMessage}
                  onChange={(e) => setInquiryMessage(e.target.value)}
                  className="w-full text-xs p-3 rounded-xl border border-[#EFE8DE] bg-[#FFFFFF] text-[#2D2926] outline-none focus:border-[#C5A059]"
                />

                {inquiryArtwork.externalSellerUrl && (
                  <div className="text-center pt-1">
                    <a 
                      href={inquiryArtwork.externalSellerUrl} 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="text-[11px] text-[#7D7571] hover:text-[#C5A059] flex items-center justify-center gap-1"
                    >
                      <span>Available directly on External Gallery Store</span>
                      <ExternalLink className="w-3 h-3" />
                    </a>
                  </div>
                )}

                <button
                  type="submit"
                  className="w-full py-3 rounded-full bg-[#C5A059] hover:bg-[#B38E46] text-[#2D2926] text-xs font-sans font-semibold uppercase tracking-wider shadow-md flex items-center justify-center gap-2"
                >
                  <Send className="w-4 h-4" />
                  <span>Send Acquisition Message to {inquiryArtwork.artistName}</span>
                </button>
              </form>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
