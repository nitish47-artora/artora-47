import React from 'react';
import { BookOpen, GraduationCap, Lightbulb, ShoppingBag, Ticket, Brush, ArrowRight } from 'lucide-react';

interface WelcomeScreenProps { onSelectOption: (option: 'learn'|'workshops'|'discover'|'buy'|'expos'|'studio') => void; onExploreDirectly: () => void; }

export const WelcomeScreen: React.FC<WelcomeScreenProps> = ({ onSelectOption }) => {
  const cards = [
    ['learn','Learn','Explore tutorials & improve your skills',BookOpen],
    ['workshops','Workshops','Join workshops & enhance your talent',GraduationCap],
    ['discover','Discover','Discover arts and creative ideas',Lightbulb],
    ['buy','Buy','Buy or pitch your artworks',ShoppingBag],
    ['expos','Expos','Find expos & exhibitions near you',Ticket],
    ['studio','Studio','Get inspired by professional artists',Brush]
  ] as const;
  return <div className="min-h-[calc(100vh-64px)] flex items-center justify-center px-4 py-8 bg-[#FAF8F5]">
    <div className="w-full max-w-5xl">
      <div className="text-center mb-8">
        <div className="mx-auto w-28 h-28 rounded-2xl overflow-hidden bg-black shadow-[0_10px_35px_rgba(197,160,89,.18)] border border-[#C5A059]/40"><img src="/artora-logo.png" alt="ARTORA" className="w-full h-full object-cover"/></div>
        <p className="mt-4 text-[10px] tracking-[.25em] font-bold text-[#C5A059] uppercase">Where Art Inspires You</p>
        <h1 className="font-serif text-3xl sm:text-4xl font-bold text-[#2D2926] mt-2">What would you like to do today?</h1>
        <p className="text-sm text-[#7D7571] mt-2">Learn, create, discover, collect, experience, and grow with ARTORA.</p>
      </div>
      <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
        {cards.map(([id,title,subtitle,Icon]) => <button key={id} onClick={()=>onSelectOption(id)} className="group bg-white border border-[#EFE8DE] hover:border-[#C5A059] rounded-2xl p-5 min-h-40 text-center shadow-[0_4px_24px_rgba(45,41,38,.03)] hover:shadow-[0_12px_30px_rgba(197,160,89,.12)] transition-all"><div className="mx-auto w-12 h-12 rounded-2xl bg-[#FAF2F0] flex items-center justify-center text-[#C5A059] group-hover:bg-[#C5A059] group-hover:text-white transition-colors"><Icon className="w-6 h-6"/></div><div className="font-serif font-bold text-xl text-[#2D2926] mt-3">{title}</div><div className="text-[11px] text-[#7D7571] mt-1 leading-relaxed">{subtitle}</div><div className="mt-3 text-[10px] uppercase tracking-wider font-bold text-[#7D7571] group-hover:text-[#2D2926]">Enter <ArrowRight className="inline w-3 h-3 ml-1"/></div></button>)}
      </div>
    </div>
  </div>;
};
