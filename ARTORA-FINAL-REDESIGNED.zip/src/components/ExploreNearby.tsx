import React, { useState } from 'react';
import { 
  MapPin, 
  Calendar, 
  Clock, 
  Sparkles, 
  Map as MapIcon, 
  List, 
  Filter, 
  CheckCircle2, 
  X, 
  Share2, 
  Navigation,
  DollarSign,
  Ticket
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { ArtEvent } from '../types';
import { ART_EVENTS_DATA, AVAILABLE_CITIES } from '../data/eventsData';

export const ExploreNearby: React.FC = () => {
  const [selectedCity, setSelectedCity] = useState<string>('San Francisco');
  const [viewMode, setViewMode] = useState<'list' | 'map'>('list');
  const [dateFilter, setDateFilter] = useState<string>('all');
  const [isFreeFilter, setIsFreeFilter] = useState<boolean | null>(null);
  const [selectedEvent, setSelectedEvent] = useState<ArtEvent | null>(null);
  const [rsvpSuccess, setRsvpSuccess] = useState(false);
  const [usingGeoLocation, setUsingGeoLocation] = useState(false);

  const handleUseMyLocation = () => {
    setUsingGeoLocation(true);
    setTimeout(() => {
      setSelectedCity('San Francisco');
      setUsingGeoLocation(false);
    }, 600);
  };

  const filteredEvents = ART_EVENTS_DATA.filter((evt) => {
    const matchesCity = evt.city.toLowerCase() === selectedCity.toLowerCase() || selectedCity === 'San Francisco';
    const matchesDate = dateFilter === 'all' || evt.dateFilter === dateFilter;
    const matchesFree = isFreeFilter === null || evt.isFree === isFreeFilter;
    return matchesCity && matchesDate && matchesFree;
  });

  const handleRSVP = () => {
    setRsvpSuccess(true);
    confetti({ particleCount: 70, spread: 60, origin: { y: 0.6 } });
    setTimeout(() => setRsvpSuccess(false), 2500);
  };

  return (
    <div className="w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 animate-in fade-in duration-300 bg-[#FAF8F5] text-[#2D2926]">
      
      {/* Header */}
      <div className="text-center max-w-2xl mx-auto mb-10">
        <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-[#FAF2F0] border border-[#EFE6D5] text-[#2D2926] text-xs font-sans font-semibold uppercase tracking-widest mb-3">
          <MapPin className="w-3.5 h-3.5 text-[#C5A059]" />
          <span>Cultural Geolocation & Salons</span>
        </div>
        <h1 className="text-3xl sm:text-5xl font-bodoni font-normal text-[#2D2926] tracking-tight">
          Explore Nearby <span className="font-serif italic font-light text-2xl sm:text-4xl text-[#7D7571]">Exhibitions & Salons</span>
        </h1>
        <p className="text-xs sm:text-sm text-[#7D7571] font-sans mt-2 leading-relaxed">
          Discover museum exhibitions, craft salons, acoustic evenings, and atelier masterclasses across major creative capitals.
        </p>
      </div>

      {/* Control Bar: Location & Filters */}
      <div className="bg-[#FFFFFF] rounded-2xl p-4 sm:p-5 border border-[#EFE8DE] shadow-[0_4px_24px_rgba(45,41,38,0.03)] mb-8 font-sans">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          
          {/* City Selection & Geolocation */}
          <div className="flex flex-wrap items-center gap-2">
            <button
              onClick={handleUseMyLocation}
              className="flex items-center gap-1.5 px-4 py-2 rounded-full bg-[#C5A059] hover:bg-[#B38E46] text-[#2D2926] text-xs font-semibold shadow-2xs transition-all"
            >
              <Navigation className={`w-3.5 h-3.5 ${usingGeoLocation ? 'animate-spin' : ''}`} />
              <span>{usingGeoLocation ? 'Detecting...' : 'Use My Location'}</span>
            </button>

            <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar py-1">
              {AVAILABLE_CITIES.map((city) => (
                <button
                  key={city}
                  onClick={() => setSelectedCity(city)}
                  className={`px-3.5 py-1.5 rounded-full text-xs font-semibold whitespace-nowrap transition-all ${
                    selectedCity === city
                      ? 'bg-[#2D2926] text-white shadow-2xs'
                      : 'bg-[#FAF8F5] border border-[#EFE8DE] text-[#7D7571] hover:bg-[#FAF2F0]'
                  }`}
                >
                  {city}
                </button>
              ))}
            </div>
          </div>

          {/* View Toggle (List vs Map) & Filters */}
          <div className="flex items-center gap-3 shrink-0">
            <div className="flex items-center p-1 rounded-xl bg-[#FAF8F5] border border-[#EFE8DE]">
              <button
                onClick={() => setViewMode('list')}
                className={`flex items-center gap-1 px-3 py-1 rounded-lg text-xs font-semibold transition-all ${
                  viewMode === 'list' ? 'bg-[#FFFFFF] text-[#2D2926] shadow-2xs' : 'text-[#7D7571]'
                }`}
              >
                <List className="w-3.5 h-3.5" />
                <span>List</span>
              </button>
              <button
                onClick={() => setViewMode('map')}
                className={`flex items-center gap-1 px-3 py-1 rounded-lg text-xs font-semibold transition-all ${
                  viewMode === 'map' ? 'bg-[#FFFFFF] text-[#2D2926] shadow-2xs' : 'text-[#7D7571]'
                }`}
              >
                <MapIcon className="w-3.5 h-3.5" />
                <span>Map</span>
              </button>
            </div>

            <select
              value={dateFilter}
              onChange={(e) => setDateFilter(e.target.value)}
              className="text-xs font-semibold px-3.5 py-2 rounded-xl bg-[#FAF8F5] border border-[#EFE8DE] text-[#2D2926] outline-none focus:border-[#C5A059]"
            >
              <option value="all">Any Date</option>
              <option value="today">Today</option>
              <option value="this_weekend">This Weekend</option>
              <option value="this_week">This Week</option>
              <option value="this_month">This Month</option>
            </select>
          </div>
        </div>
      </div>

      {/* Content: List or Interactive Map representation */}
      {viewMode === 'list' ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredEvents.map((evt) => (
            <div
              key={evt.id}
              className="group bg-[#FFFFFF] rounded-2xl border border-[#EFE8DE] overflow-hidden shadow-[0_4px_20px_rgba(45,41,38,0.02)] hover:border-[#C5A059] hover:shadow-[0_8px_24px_rgba(197,160,89,0.08)] transition-all duration-300 flex flex-col justify-between"
            >
              <div>
                <div className="relative w-full aspect-16/9 overflow-hidden bg-[#FAF2F0]">
                  <img 
                    src={evt.image} 
                    alt={evt.title} 
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  <div className="absolute top-3 left-3 px-2.5 py-0.5 rounded-full bg-[#FAF8F5]/90 backdrop-blur-md text-[#2D2926] border border-[#EFE6D5] text-[10px] font-sans font-semibold uppercase">
                    {evt.type}
                  </div>
                  <div className="absolute top-3 right-3 px-2.5 py-0.5 rounded-full bg-[#2D2926]/90 text-[#C5A059] font-serif text-xs font-bold">
                    {evt.priceStr}
                  </div>
                </div>

                <div className="p-5 font-sans">
                  <div className="flex items-center gap-1.5 text-xs text-[#C5A059] font-semibold mb-1.5">
                    <Calendar className="w-3.5 h-3.5" />
                    <span>{evt.dateStr}</span>
                  </div>

                  <h3 className="font-serif font-bold text-lg text-[#2D2926] group-hover:text-[#C5A059] transition-colors">
                    {evt.title}
                  </h3>

                  <p className="text-xs text-[#7D7571] mt-1 flex items-center gap-1">
                    <MapPin className="w-3.5 h-3.5 text-[#C5A059] shrink-0" />
                    <span className="truncate">{evt.venue} ({evt.distanceKm} km away)</span>
                  </p>

                  <p className="text-xs text-[#57514D] mt-2 line-clamp-2 leading-relaxed">
                    {evt.description}
                  </p>
                </div>
              </div>

              <div className="p-5 pt-0 flex items-center justify-between border-t border-[#EFE8DE] mt-2 font-sans">
                <span className="text-xs text-[#7D7571]">
                  {evt.rsvpCount} patrons attending
                </span>
                <button
                  onClick={() => setSelectedEvent(evt)}
                  className="px-4 py-1.5 rounded-full bg-[#C5A059] hover:bg-[#B38E46] text-[#2D2926] text-xs font-semibold shadow-2xs transition-colors"
                >
                  View Salon & RSVP
                </button>
              </div>
            </div>
          ))}
        </div>
      ) : (
        /* Map View */
        <div className="relative rounded-2xl overflow-hidden border border-[#EFE8DE] bg-[#FAF2F0] min-h-[480px] p-6 shadow-sm flex flex-col justify-between font-sans">
          <div className="absolute inset-0 opacity-40 bg-[radial-gradient(#C5A059_1px,transparent_1px)] [background-size:24px_24px]" />
          
          <div className="relative z-10 flex items-center justify-between">
            <span className="px-4 py-1.5 rounded-full bg-[#FFFFFF]/90 border border-[#EFE8DE] text-[#2D2926] text-xs font-semibold shadow-2xs">
              Atelier Map • {selectedCity} Region ({filteredEvents.length} Cultural Venues)
            </span>
          </div>

          <div className="relative z-10 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4 my-8">
            {filteredEvents.map((evt) => (
              <div 
                key={evt.id}
                onClick={() => setSelectedEvent(evt)}
                className="cursor-pointer p-4 rounded-xl bg-[#FFFFFF]/95 backdrop-blur-md border border-[#EFE8DE] shadow-md hover:scale-105 hover:border-[#C5A059] transition-all"
              >
                <div className="flex items-center gap-2 mb-1">
                  <span className="w-2 h-2 rounded-full bg-[#C5A059] animate-pulse" />
                  <span className="text-[10px] font-semibold text-[#C5A059] uppercase">{evt.type}</span>
                </div>
                <div className="font-serif font-bold text-xs text-[#2D2926] truncate">{evt.title}</div>
                <div className="text-[11px] text-[#7D7571] truncate">{evt.venue}</div>
              </div>
            ))}
          </div>

          <div className="relative z-10 text-xs text-[#7D7571] text-center">
            Select any venue salon beacon to explore hours, resident artists, and reserve gallery admission.
          </div>
        </div>
      )}

      {/* Event Details & RSVP Modal */}
      {selectedEvent && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-xs animate-in fade-in duration-200">
          <div 
            className="w-full max-w-xl bg-[#FAF8F5] rounded-2xl border border-[#EFE8DE] p-6 sm:p-7 shadow-2xl overflow-hidden font-sans"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between pb-3 mb-4 border-b border-[#EFE8DE]">
              <span className="px-3 py-0.5 rounded-full bg-[#FAF2F0] border border-[#EFE6D5] text-[#2D2926] text-xs font-semibold uppercase">
                {selectedEvent.type}
              </span>
              <button 
                onClick={() => setSelectedEvent(null)}
                className="p-1 rounded-full text-[#7D7571] hover:bg-[#FAF2F0]"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-4">
              <div className="relative h-44 rounded-xl overflow-hidden bg-[#FAF2F0] border border-[#EFE8DE]">
                <img src={selectedEvent.image} alt="" className="w-full h-full object-cover" />
              </div>

              <div>
                <h3 className="font-serif font-bold text-xl text-[#2D2926]">{selectedEvent.title}</h3>
                <div className="text-xs font-semibold text-[#C5A059] mt-1 flex items-center gap-1.5">
                  <Calendar className="w-3.5 h-3.5" />
                  <span>{selectedEvent.dateStr} • {selectedEvent.timeStr}</span>
                </div>
              </div>

              <div className="p-4 rounded-xl bg-[#FFFFFF] border border-[#EFE8DE] text-xs space-y-1 text-[#2D2926]">
                <div><strong>Venue:</strong> {selectedEvent.venue}</div>
                <div><strong>Address:</strong> {selectedEvent.address}</div>
                <div><strong>Admission:</strong> {selectedEvent.priceStr}</div>
              </div>

              <p className="text-xs sm:text-sm text-[#57514D] leading-relaxed">
                {selectedEvent.description}
              </p>

              {rsvpSuccess ? (
                <div className="p-3.5 rounded-xl bg-[#FAF2F0] border border-[#EFE6D5] text-[#C5A059] text-xs font-semibold text-center flex items-center justify-center gap-2">
                  <CheckCircle2 className="w-4 h-4" />
                  <span>RSVP Confirmed! Invitation sent to your calendar.</span>
                </div>
              ) : (
                <button
                  onClick={handleRSVP}
                  className="w-full py-3 rounded-full bg-[#C5A059] hover:bg-[#B38E46] text-[#2D2926] text-xs font-semibold uppercase tracking-wider shadow-sm flex items-center justify-center gap-2"
                >
                  <Ticket className="w-4 h-4" />
                  <span>Confirm RSVP / Attend Exhibition</span>
                </button>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
