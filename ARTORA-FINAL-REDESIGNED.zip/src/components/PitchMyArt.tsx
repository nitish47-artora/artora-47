import React, { useState } from 'react';
import { 
  Upload, 
  CheckCircle2, 
  ChevronRight, 
  ChevronLeft, 
  Sparkles, 
  Image as ImageIcon, 
  DollarSign, 
  User, 
  Eye, 
  Award,
  ArrowRight,
  Check
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { Artwork, ArtCategory } from '../types';

interface PitchMyArtProps {
  categories: ArtCategory[];
  onPublishSuccess: (artwork: Artwork) => void;
  onGoToBuyArt: () => void;
}

export const PitchMyArt: React.FC<PitchMyArtProps> = ({
  categories,
  onPublishSuccess,
  onGoToBuyArt
}) => {
  const [currentStep, setCurrentStep] = useState(1);
  const [isPublished, setIsPublished] = useState(false);

  // Form State
  const [imagePreview, setImagePreview] = useState<string>('https://images.unsplash.com/photo-1579783900882-c0d3dad7b119?auto=format&fit=crop&w=1000&q=80');
  const [title, setTitle] = useState('');
  const [categoryId, setCategoryId] = useState('painting');
  const [artForm, setArtForm] = useState('Watercolor Painting');
  const [materials, setMaterials] = useState('');
  const [dimensions, setDimensions] = useState('');
  const [description, setDescription] = useState('');
  
  // Pricing
  const [isForSale, setIsForSale] = useState(true);
  const [price, setPrice] = useState('450');
  const [openForCommissions, setOpenForCommissions] = useState(true);

  // Artist Info
  const [artistName, setArtistName] = useState('Alex Rivera');
  const [bio, setBio] = useState('Independent fine artist passionate about organic chiaroscuro and atmospheric landscapes.');
  const [location, setLocation] = useState('Paris & New York');
  const [contactEmail, setContactEmail] = useState('alex.rivera.art@example.com');
  const [handle, setHandle] = useState('@alexrivera_art');

  const steps = [
    { num: 1, label: 'Upload Artwork', icon: Upload },
    { num: 2, label: 'Artwork Details', icon: ImageIcon },
    { num: 3, label: 'Pricing & Terms', icon: DollarSign },
    { num: 4, label: 'Artist Bio', icon: User },
    { num: 5, label: 'Preview Pitch', icon: Eye },
    { num: 6, label: 'Published', icon: Award }
  ];

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        setImagePreview(event.target?.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handlePublish = () => {
    const newArtwork: Artwork = {
      id: `art-user-${Date.now()}`,
      title: title || 'Luminous Mountain Reverie',
      artistId: 'artist-user-me',
      artistName: artistName || 'Alex Rivera',
      artistAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&q=80',
      categoryId: categoryId,
      artForm: artForm || 'Watercolor Painting',
      style: 'Contemporary Impressionism',
      materials: materials || 'Artists Watercolor on 300gsm Arches 100% Cotton',
      dimensions: dimensions || '18" x 24" Framed',
      image: imagePreview,
      price: Number(price) || 450,
      currency: 'USD',
      isForSale: isForSale,
      isSold: false,
      description: description || 'Created with fluid, layered washes exploring morning fog and golden light transitions.',
      likesCount: 1,
      savesCount: 0,
      createdAt: '2026-08-27'
    };

    setIsPublished(true);
    setCurrentStep(6);
    confetti({
      particleCount: 150,
      spread: 90,
      origin: { y: 0.5 }
    });

    onPublishSuccess(newArtwork);
  };

  return (
    <div className="w-full max-w-4xl mx-auto px-4 py-8 animate-in fade-in duration-300 bg-[#FAF8F5] text-[#2D2926]">
      
      {/* Header */}
      <div className="text-center max-w-xl mx-auto mb-10">
        <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-[#FAF2F0] border border-[#EFE6D5] text-[#2D2926] text-xs font-sans font-semibold uppercase tracking-widest mb-3">
          <Sparkles className="w-3.5 h-3.5 text-[#C5A059]" />
          <span>Atelier Showcase & Submission</span>
        </div>
        <h1 className="text-3xl sm:text-5xl font-bodoni font-normal text-[#2D2926] tracking-tight">
          Pitch Your Art <span className="font-serif italic font-light text-2xl sm:text-4xl text-[#7D7571]">To Curators</span>
        </h1>
        <p className="text-xs sm:text-sm text-[#7D7571] font-sans mt-2 leading-relaxed">
          Exhibit your creations to art collectors, gallery directors, and patrons in 5 curated steps.
        </p>
      </div>

      {/* Progress Steps Header */}
      <div className="flex items-center justify-between mb-8 overflow-x-auto no-scrollbar py-2">
        {steps.slice(0, 5).map((s) => {
          const isCurr = s.num === currentStep;
          const isDone = s.num < currentStep || isPublished;
          return (
            <div key={s.num} className="flex items-center gap-2 shrink-0">
              <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-sans font-bold transition-all ${
                isCurr
                  ? 'bg-[#C5A059] text-[#2D2926] ring-4 ring-[#C5A059]/20 shadow-xs'
                  : isDone
                  ? 'bg-[#FAF2F0] border border-[#EFE6D5] text-[#C5A059]'
                  : 'bg-[#FFFFFF] border border-[#EFE8DE] text-[#7D7571]'
              }`}>
                {isDone ? <Check className="w-4 h-4" /> : s.num}
              </div>
              <span className={`text-xs font-sans font-semibold hidden sm:inline ${
                isCurr ? 'text-[#2D2926]' : 'text-[#7D7571]'
              }`}>
                {s.label}
              </span>
              {s.num < 5 && <ChevronRight className="w-4 h-4 text-[#D8D2C6] mx-1 hidden sm:inline" />}
            </div>
          );
        })}
      </div>

      {/* Wizard Form Cards */}
      <div className="bg-[#FFFFFF] rounded-2xl border border-[#EFE8DE] p-7 sm:p-9 shadow-[0_4px_24px_rgba(45,41,38,0.03)]">
        
        {/* STEP 1: Upload Artwork Image */}
        {currentStep === 1 && (
          <div className="space-y-6">
            <div>
              <h2 className="text-2xl font-serif font-bold text-[#2D2926]">
                Step 1: Upload Artwork Photography
              </h2>
              <p className="text-xs sm:text-sm text-[#7D7571] font-sans mt-1">
                Provide a crisp, studio-lit photograph or digital master export of your finished piece.
              </p>
            </div>

            <div className="border-2 border-dashed border-[#EFE8DE] rounded-2xl p-6 sm:p-10 text-center bg-[#FAF8F5]">
              {imagePreview ? (
                <div className="space-y-4">
                  <div className="max-w-md mx-auto aspect-4/3 rounded-xl overflow-hidden shadow-sm bg-[#FAF2F0] border border-[#EFE8DE]">
                    <img 
                      src={imagePreview} 
                      alt="Artwork Preview" 
                      className="w-full h-full object-contain"
                    />
                  </div>
                  <label className="cursor-pointer inline-flex items-center gap-2 px-5 py-2 rounded-full bg-[#2D2926] text-white text-xs font-sans font-semibold shadow-2xs hover:bg-[#1A1A1A]">
                    <span>Replace Image</span>
                    <input 
                      type="file" 
                      accept="image/*" 
                      onChange={handleFileUpload} 
                      className="hidden" 
                    />
                  </label>
                </div>
              ) : (
                <div className="space-y-3">
                  <Upload className="w-10 h-10 text-[#C5A059] mx-auto" />
                  <div className="font-serif font-bold text-base text-[#2D2926]">
                    Drag and drop your file here, or select
                  </div>
                  <p className="text-xs text-[#7D7571] font-sans">
                    Supports high-res PNG, JPG, or WEBP up to 25MB
                  </p>
                  <label className="cursor-pointer inline-flex items-center gap-2 px-6 py-2.5 rounded-full bg-[#C5A059] hover:bg-[#B38E46] text-[#2D2926] text-xs font-sans font-semibold shadow-xs">
                    <span>Select Master File</span>
                    <input 
                      type="file" 
                      accept="image/*" 
                      onChange={handleFileUpload} 
                      className="hidden" 
                    />
                  </label>
                </div>
              )}
            </div>

            <div className="flex justify-end pt-4">
              <button
                id="pitch-step1-next-btn"
                onClick={() => setCurrentStep(2)}
                className="flex items-center gap-2 px-6 py-2.5 rounded-full bg-[#C5A059] hover:bg-[#B38E46] text-[#2D2926] text-xs font-sans font-semibold uppercase tracking-wider shadow-2xs transition-colors"
              >
                <span>Continue to Artwork Info</span>
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {/* STEP 2: Artwork Information */}
        {currentStep === 2 && (
          <div className="space-y-6">
            <div>
              <h2 className="text-2xl font-serif font-bold text-[#2D2926]">
                Step 2: Artwork Provenance & Details
              </h2>
              <p className="text-xs sm:text-sm text-[#7D7571] font-sans mt-1">
                Detail the medium, materials, and dimension specs for collectors.
              </p>
            </div>

            <div className="space-y-4 font-sans">
              <div>
                <label className="block text-xs font-semibold uppercase tracking-[0.2em] text-[#7D7571] mb-1.5">
                  Artwork Title *
                </label>
                <input
                  type="text"
                  placeholder="e.g. Luminous Mountain Reverie"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  className="w-full text-sm px-4 py-2.5 rounded-xl border border-[#EFE8DE] bg-[#FAF8F5] text-[#2D2926] outline-none focus:border-[#C5A059]"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold uppercase tracking-[0.2em] text-[#7D7571] mb-1.5">
                    Art Discipline *
                  </label>
                  <select
                    value={categoryId}
                    onChange={(e) => setCategoryId(e.target.value)}
                    className="w-full text-sm px-4 py-2.5 rounded-xl border border-[#EFE8DE] bg-[#FAF8F5] text-[#2D2926] outline-none focus:border-[#C5A059]"
                  >
                    {categories.map((c) => (
                      <option key={c.id} value={c.id}>{c.name}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold uppercase tracking-[0.2em] text-[#7D7571] mb-1.5">
                    Specific Medium / Technique *
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. Watercolor & Ink, Oil on Linen"
                    value={artForm}
                    onChange={(e) => setArtForm(e.target.value)}
                    className="w-full text-sm px-4 py-2.5 rounded-xl border border-[#EFE8DE] bg-[#FAF8F5] text-[#2D2926] outline-none focus:border-[#C5A059]"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold uppercase tracking-[0.2em] text-[#7D7571] mb-1.5">
                    Archival Materials
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. Arches 300gsm Cotton, Schmincke Pigments"
                    value={materials}
                    onChange={(e) => setMaterials(e.target.value)}
                    className="w-full text-sm px-4 py-2.5 rounded-xl border border-[#EFE8DE] bg-[#FAF8F5] text-[#2D2926] outline-none focus:border-[#C5A059]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold uppercase tracking-[0.2em] text-[#7D7571] mb-1.5">
                    Dimensions & Framing
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. 18 x 24 inches (Custom Framed)"
                    value={dimensions}
                    onChange={(e) => setDimensions(e.target.value)}
                    className="w-full text-sm px-4 py-2.5 rounded-xl border border-[#EFE8DE] bg-[#FAF8F5] text-[#2D2926] outline-none focus:border-[#C5A059]"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold uppercase tracking-[0.2em] text-[#7D7571] mb-1.5">
                  Artist Statement & Inspiration
                </label>
                <textarea
                  rows={3}
                  placeholder="Share what inspired this piece, the creative techniques explored, and its emotional resonance..."
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  className="w-full text-sm p-3.5 rounded-xl border border-[#EFE8DE] bg-[#FAF8F5] text-[#2D2926] outline-none focus:border-[#C5A059]"
                />
              </div>
            </div>

            <div className="flex items-center justify-between pt-4">
              <button
                onClick={() => setCurrentStep(1)}
                className="px-5 py-2.5 rounded-full border border-[#EFE8DE] text-xs font-sans font-semibold text-[#2D2926] hover:bg-[#FAF2F0]"
              >
                Back
              </button>
              <button
                onClick={() => setCurrentStep(3)}
                className="flex items-center gap-2 px-6 py-2.5 rounded-full bg-[#C5A059] hover:bg-[#B38E46] text-[#2D2926] text-xs font-sans font-semibold uppercase tracking-wider shadow-2xs"
              >
                <span>Continue to Valuation</span>
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {/* STEP 3: Pricing & Availability */}
        {currentStep === 3 && (
          <div className="space-y-6">
            <div>
              <h2 className="text-2xl font-serif font-bold text-[#2D2926]">
                Step 3: Valuation & Availability
              </h2>
              <p className="text-xs sm:text-sm text-[#7D7571] font-sans mt-1">
                Configure your pricing and whether you accept custom commissions.
              </p>
            </div>

            <div className="space-y-4 font-sans">
              <div className="flex items-center justify-between p-4 rounded-xl bg-[#FAF8F5] border border-[#EFE8DE]">
                <div>
                  <div className="font-semibold text-sm text-[#2D2926]">Is this original piece available for acquisition?</div>
                  <div className="text-xs text-[#7D7571]">Allow collectors to purchase or express private interest.</div>
                </div>
                <input
                  type="checkbox"
                  checked={isForSale}
                  onChange={(e) => setIsForSale(e.target.checked)}
                  className="w-5 h-5 accent-[#C5A059] rounded cursor-pointer"
                />
              </div>

              {isForSale && (
                <div>
                  <label className="block text-xs font-semibold uppercase tracking-[0.2em] text-[#7D7571] mb-1.5">
                    Acquisition Price ($ USD)
                  </label>
                  <div className="relative">
                    <span className="absolute left-4 top-1/2 -translate-y-1/2 font-serif font-bold text-[#7D7571]">$</span>
                    <input
                      type="number"
                      value={price}
                      onChange={(e) => setPrice(e.target.value)}
                      className="w-full text-base font-bold pl-8 pr-4 py-2.5 rounded-xl border border-[#EFE8DE] bg-[#FAF8F5] text-[#2D2926] outline-none focus:border-[#C5A059]"
                    />
                  </div>
                </div>
              )}

              <div className="flex items-center justify-between p-4 rounded-xl bg-[#FAF8F5] border border-[#EFE8DE]">
                <div>
                  <div className="font-semibold text-sm text-[#2D2926]">Open to Custom Commissions?</div>
                  <div className="text-xs text-[#7D7571]">Allow patrons to commission new original pieces in this aesthetic.</div>
                </div>
                <input
                  type="checkbox"
                  checked={openForCommissions}
                  onChange={(e) => setOpenForCommissions(e.target.checked)}
                  className="w-5 h-5 accent-[#C5A059] rounded cursor-pointer"
                />
              </div>
            </div>

            <div className="flex items-center justify-between pt-4">
              <button
                onClick={() => setCurrentStep(2)}
                className="px-5 py-2.5 rounded-full border border-[#EFE8DE] text-xs font-sans font-semibold text-[#2D2926] hover:bg-[#FAF2F0]"
              >
                Back
              </button>
              <button
                onClick={() => setCurrentStep(4)}
                className="flex items-center gap-2 px-6 py-2.5 rounded-full bg-[#C5A059] hover:bg-[#B38E46] text-[#2D2926] text-xs font-sans font-semibold uppercase tracking-wider shadow-2xs"
              >
                <span>Continue to Artist Bio</span>
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {/* STEP 4: Artist Profile */}
        {currentStep === 4 && (
          <div className="space-y-6">
            <div>
              <h2 className="text-2xl font-serif font-bold text-[#2D2926]">
                Step 4: Your Artist Atelier Profile
              </h2>
              <p className="text-xs sm:text-sm text-[#7D7571] font-sans mt-1">
                Your public artist signature visible alongside the masterpiece.
              </p>
            </div>

            <div className="space-y-4 font-sans">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold uppercase tracking-[0.2em] text-[#7D7571] mb-1.5">
                    Artist / Studio Name *
                  </label>
                  <input
                    type="text"
                    value={artistName}
                    onChange={(e) => setArtistName(e.target.value)}
                    className="w-full text-sm px-4 py-2.5 rounded-xl border border-[#EFE8DE] bg-[#FAF8F5] text-[#2D2926] outline-none focus:border-[#C5A059]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold uppercase tracking-[0.2em] text-[#7D7571] mb-1.5">
                    Atelier Location (City, Country)
                  </label>
                  <input
                    type="text"
                    value={location}
                    onChange={(e) => setLocation(e.target.value)}
                    className="w-full text-sm px-4 py-2.5 rounded-xl border border-[#EFE8DE] bg-[#FAF8F5] text-[#2D2926] outline-none focus:border-[#C5A059]"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold uppercase tracking-[0.2em] text-[#7D7571] mb-1.5">
                  Artist Bio & Studio Philosophy
                </label>
                <textarea
                  rows={2}
                  value={bio}
                  onChange={(e) => setBio(e.target.value)}
                  className="w-full text-sm p-3.5 rounded-xl border border-[#EFE8DE] bg-[#FAF8F5] text-[#2D2926] outline-none focus:border-[#C5A059]"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold uppercase tracking-[0.2em] text-[#7D7571] mb-1.5">
                    Acquisition Contact Email *
                  </label>
                  <input
                    type="email"
                    value={contactEmail}
                    onChange={(e) => setContactEmail(e.target.value)}
                    className="w-full text-sm px-4 py-2.5 rounded-xl border border-[#EFE8DE] bg-[#FAF8F5] text-[#2D2926] outline-none focus:border-[#C5A059]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold uppercase tracking-[0.2em] text-[#7D7571] mb-1.5">
                    Social Handle / Website
                  </label>
                  <input
                    type="text"
                    value={handle}
                    onChange={(e) => setHandle(e.target.value)}
                    className="w-full text-sm px-4 py-2.5 rounded-xl border border-[#EFE8DE] bg-[#FAF8F5] text-[#2D2926] outline-none focus:border-[#C5A059]"
                  />
                </div>
              </div>
            </div>

            <div className="flex items-center justify-between pt-4">
              <button
                onClick={() => setCurrentStep(3)}
                className="px-5 py-2.5 rounded-full border border-[#EFE8DE] text-xs font-sans font-semibold text-[#2D2926] hover:bg-[#FAF2F0]"
              >
                Back
              </button>
              <button
                onClick={() => setCurrentStep(5)}
                className="flex items-center gap-2 px-6 py-2.5 rounded-full bg-[#C5A059] hover:bg-[#B38E46] text-[#2D2926] text-xs font-sans font-semibold uppercase tracking-wider shadow-2xs"
              >
                <span>Preview Pitch</span>
                <Eye className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {/* STEP 5: Live Pitch Preview */}
        {currentStep === 5 && (
          <div className="space-y-6">
            <div>
              <h2 className="text-2xl font-serif font-bold text-[#2D2926]">
                Step 5: Review Live Exhibition Pitch
              </h2>
              <p className="text-xs text-[#7D7571] font-sans">
                Review how art curators and collectors will experience your submission.
              </p>
            </div>

            <div className="border border-[#EFE8DE] rounded-2xl overflow-hidden bg-[#FAF8F5] p-5 sm:p-7">
              <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-center">
                <div className="md:col-span-6 aspect-4/3 rounded-xl overflow-hidden bg-[#FAF2F0] border border-[#EFE8DE]">
                  <img src={imagePreview} alt="Preview" className="w-full h-full object-cover" />
                </div>
                <div className="md:col-span-6 space-y-3 font-sans">
                  <div className="flex items-center gap-2">
                    <span className="px-3 py-0.5 rounded-full bg-[#FAF2F0] border border-[#EFE6D5] text-[#2D2926] text-xs font-semibold">
                      {artForm || 'Artwork'}
                    </span>
                    <span className="text-xs text-[#7D7571]">{dimensions || 'Standard format'}</span>
                  </div>
                  <h3 className="text-2xl font-serif font-bold text-[#2D2926]">
                    {title || 'Untitled Masterpiece'}
                  </h3>
                  <p className="text-xs sm:text-sm text-[#57514D] leading-relaxed">
                    {description || 'No description provided.'}
                  </p>
                  
                  <div className="pt-3 border-t border-[#EFE8DE] flex items-center justify-between">
                    <div>
                      <span className="text-[11px] text-[#7D7571] block font-medium">Creator</span>
                      <span className="text-xs font-semibold text-[#2D2926]">{artistName} • {location}</span>
                    </div>
                    {isForSale && (
                      <div className="text-right">
                        <span className="text-[11px] text-[#7D7571] block font-medium">Acquisition Price</span>
                        <span className="text-xl font-serif font-bold text-[#C5A059]">${price}</span>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>

            <div className="flex items-center justify-between pt-4">
              <button
                onClick={() => setCurrentStep(4)}
                className="px-5 py-2.5 rounded-full border border-[#EFE8DE] text-xs font-sans font-semibold text-[#2D2926] hover:bg-[#FAF2F0]"
              >
                Edit Info
              </button>
              <button
                id="confirm-publish-pitch-btn"
                onClick={handlePublish}
                className="flex items-center gap-2 px-8 py-3 rounded-full bg-[#C5A059] hover:bg-[#B38E46] text-[#2D2926] text-xs font-sans font-semibold uppercase tracking-wider shadow-md hover:shadow-lg transition-all"
              >
                <Sparkles className="w-4 h-4" />
                <span>Publish to Atelier Live</span>
              </button>
            </div>
          </div>
        )}

        {/* STEP 6: Confirmation */}
        {currentStep === 6 && isPublished && (
          <div className="text-center py-8 space-y-4 animate-in zoom-in-95 duration-300">
            <div className="w-16 h-16 rounded-full bg-[#FAF2F0] border border-[#EFE6D5] text-[#C5A059] flex items-center justify-center mx-auto mb-2">
              <CheckCircle2 className="w-8 h-8" />
            </div>
            <h2 className="text-3xl sm:text-4xl font-serif font-bold text-[#2D2926]">
              Masterpiece Published Live
            </h2>
            <p className="text-xs sm:text-sm text-[#7D7571] font-sans max-w-md mx-auto leading-relaxed">
              Your artwork is now live on the ARTORA Discover feed and Buy Art marketplace for international collectors and patrons.
            </p>

            <div className="flex flex-wrap items-center justify-center gap-3 pt-4">
              <button
                id="view-marketplace-after-pitch-btn"
                onClick={onGoToBuyArt}
                className="flex items-center gap-2 px-6 py-3 rounded-full bg-[#C5A059] hover:bg-[#B38E46] text-[#2D2926] text-xs font-sans font-semibold uppercase tracking-wider shadow-sm"
              >
                <span>View in Buy Art Atelier</span>
                <ArrowRight className="w-4 h-4" />
              </button>
              <button
                onClick={() => {
                  setIsPublished(false);
                  setCurrentStep(1);
                  setTitle('');
                }}
                className="px-5 py-3 rounded-full bg-[#FAF8F5] border border-[#EFE8DE] text-[#2D2926] text-xs font-sans font-medium hover:bg-[#FAF2F0]"
              >
                Pitch Another Masterpiece
              </button>
            </div>
          </div>
        )}

      </div>
    </div>
  );
};
