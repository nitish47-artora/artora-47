import React, { useState } from 'react';
import { 
  ChevronLeft, 
  ChevronRight, 
  CheckCircle2, 
  Bookmark, 
  Clock, 
  Sparkles, 
  Award, 
  Layers,
  ArrowRight,
  Check
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { Tutorial } from '../types';

interface TutorialViewerProps {
  tutorial: Tutorial;
  onBack: () => void;
  onGoToPractice: () => void;
  isSaved: boolean;
  onToggleSave: (id: string) => void;
}

export const TutorialViewer: React.FC<TutorialViewerProps> = ({
  tutorial,
  onBack,
  onGoToPractice,
  isSaved,
  onToggleSave
}) => {
  const [currentStepIndex, setCurrentStepIndex] = useState(0);
  const [completedSteps, setCompletedSteps] = useState<number[]>([]);
  const [isCompleted, setIsCompleted] = useState(false);

  const totalSteps = tutorial?.totalSteps || tutorial?.steps?.length || 1;
  const safeIndex = Math.min(Math.max(0, currentStepIndex), (tutorial?.steps?.length || 1) - 1);
  const step = tutorial?.steps?.[safeIndex] || {
    stepNumber: 1,
    title: 'Initial Setup & Materials',
    explanation: 'Prepare your workspace and arrange the essential supplies required for this discipline.',
    materials: ['Studio Starter Kit', 'Surface Paper / Canvas', 'Basic Tools'],
    image: tutorial?.coverImage || 'https://images.unsplash.com/photo-1579783902614-a3fb3927b675?auto=format&fit=crop&w=800&q=80',
    proTip: 'Work in good, even ambient daylight or high-CRI studio illumination.'
  };
  const progressPercent = Math.round(((safeIndex + 1) / totalSteps) * 100);

  const handleCompleteStep = () => {
    if (!completedSteps.includes(step.stepNumber)) {
      const nextCompleted = [...completedSteps, step.stepNumber];
      setCompletedSteps(nextCompleted);
      
      // If last step completed
      if (nextCompleted.length === tutorial.totalSteps || currentStepIndex === tutorial.totalSteps - 1) {
        setIsCompleted(true);
        confetti({
          particleCount: 100,
          spread: 70,
          origin: { y: 0.6 }
        });
      } else {
        setCurrentStepIndex((prev) => Math.min(prev + 1, tutorial.totalSteps - 1));
      }
    } else {
      setCompletedSteps(completedSteps.filter(s => s !== step.stepNumber));
    }
  };

  const handleFinishTutorial = () => {
    setIsCompleted(true);
    confetti({
      particleCount: 120,
      spread: 80,
      origin: { y: 0.5 }
    });
  };

  return (
    <div className="w-full max-w-5xl mx-auto px-4 py-8 animate-in fade-in duration-300 bg-[#FAF8F5] text-[#2D2926]">
      
      {/* Top Breadcrumb & Actions Bar */}
      <div className="flex items-center justify-between gap-4 mb-8 pb-4 border-b border-[#EFE8DE]">
        <button
          id="tutorial-back-button"
          onClick={onBack}
          className="inline-flex items-center gap-2 px-4 py-2 rounded-full text-xs font-sans font-semibold bg-[#FFFFFF] border border-[#EFE8DE] text-[#2D2926] hover:border-[#C5A059] hover:bg-[#FAF2F0] transition-colors shadow-2xs"
        >
          <ChevronLeft className="w-4 h-4 text-[#C5A059]" />
          <span>Back to Atelier</span>
        </button>

        <div className="flex items-center gap-2">
          <button
            id="tutorial-save-button"
            onClick={() => onToggleSave(tutorial.id)}
            className={`flex items-center gap-1.5 px-4 py-2 rounded-full text-xs font-sans font-semibold border transition-all ${
              isSaved
                ? 'bg-[#FAF2F0] text-[#2D2926] border-[#C5A059] shadow-2xs'
                : 'bg-[#FFFFFF] text-[#2D2926] border-[#EFE8DE] hover:border-[#C5A059] hover:bg-[#FAF2F0]'
            }`}
          >
            <Bookmark className={`w-3.5 h-3.5 ${isSaved ? 'fill-[#C5A059] text-[#C5A059]' : 'text-[#7D7571]'}`} />
            <span>{isSaved ? 'Saved in Atelier' : 'Save Tutorial'}</span>
          </button>
        </div>
      </div>

      {/* Tutorial Header Card */}
      <div className="bg-[#FFFFFF] rounded-2xl p-7 border border-[#EFE8DE] shadow-[0_4px_20px_rgba(45,41,38,0.03)] mb-8">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-5">
          <div>
            <div className="flex flex-wrap items-center gap-2.5 mb-2.5">
              <span className="px-3 py-0.5 rounded-full bg-[#FAF2F0] border border-[#EFE6D5] text-[#2D2926] text-[10px] font-sans font-semibold uppercase tracking-wider">
                {tutorial.difficulty}
              </span>
              <span className="flex items-center gap-1 text-xs text-[#7D7571] font-sans">
                <Clock className="w-3 h-3 text-[#C5A059]" />
                {tutorial.durationMinutes} minutes
              </span>
              <span className="flex items-center gap-1 text-xs text-[#7D7571] font-sans">
                <Layers className="w-3 h-3 text-[#C5A059]" />
                {tutorial.totalSteps} steps
              </span>
            </div>
            <h1 className="text-2xl sm:text-4xl font-serif font-bold text-[#2D2926] tracking-tight">
              {tutorial.title}
            </h1>
            <p className="text-xs sm:text-sm text-[#7D7571] font-sans mt-1.5 leading-relaxed">
              {tutorial.subtitle}
            </p>
          </div>

          {/* Instructor Bio */}
          <div className="flex items-center gap-3 p-3.5 rounded-xl bg-[#FAF8F5] border border-[#EFE8DE] shrink-0">
            <img 
              src={tutorial.creator.avatar} 
              alt={tutorial.creator.name} 
              className="w-11 h-11 rounded-full object-cover border border-[#EFE8DE]"
            />
            <div>
              <div className="text-xs font-sans font-semibold text-[#2D2926]">{tutorial.creator.name}</div>
              <div className="text-[11px] font-serif italic text-[#7D7571]">{tutorial.creator.role}</div>
            </div>
          </div>
        </div>

        {/* Global Progress Bar */}
        <div className="mt-6 pt-5 border-t border-[#EFE8DE]">
          <div className="flex items-center justify-between text-xs font-sans font-semibold text-[#7D7571] mb-2">
            <span>Progress: Step {currentStepIndex + 1} of {tutorial.totalSteps}</span>
            <span className="text-[#C5A059]">{progressPercent}% Completed</span>
          </div>
          <div className="w-full h-2 rounded-full bg-[#FAF2F0] overflow-hidden">
            <div 
              className="h-full bg-[#C5A059] rounded-full transition-all duration-300"
              style={{ width: `${progressPercent}%` }}
            />
          </div>

          {/* Step Pill Navigator */}
          <div className="flex items-center gap-2 mt-4 overflow-x-auto no-scrollbar py-1">
            {tutorial.steps.map((s, idx) => {
              const isCurr = idx === currentStepIndex;
              const isDone = completedSteps.includes(s.stepNumber);
              return (
                <button
                  key={s.stepNumber}
                  onClick={() => setCurrentStepIndex(idx)}
                  className={`px-3.5 py-1.5 rounded-full text-xs font-sans font-semibold whitespace-nowrap transition-all ${
                    isCurr
                      ? 'bg-[#C5A059] text-[#2D2926] shadow-2xs'
                      : isDone
                      ? 'bg-[#FAF2F0] text-[#2D2926] border border-[#EFE6D5]'
                      : 'bg-[#FAF8F5] text-[#7D7571] hover:bg-[#FAF2F0] border border-[#EFE8DE]'
                  }`}
                >
                  {isDone && <Check className="w-3 h-3 inline mr-1 text-[#C5A059]" />}
                  Step {s.stepNumber}
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* Main Step Instruction */}
      {!isCompleted ? (
        <div className="bg-[#FFFFFF] rounded-2xl border border-[#EFE8DE] shadow-[0_4px_20px_rgba(45,41,38,0.03)] overflow-hidden mb-8">
          <div className="p-6 sm:p-8">
            
            {/* Step Badge & Step Title */}
            <div className="flex items-center gap-3 mb-4">
              <span className="px-3 py-1 rounded-full bg-[#FAF2F0] border border-[#EFE6D5] text-[#2D2926] text-xs font-sans font-semibold">
                Step {step.stepNumber} of {tutorial.totalSteps}
              </span>
              <h2 className="text-xl sm:text-2xl font-serif font-bold text-[#2D2926]">
                {step.title}
              </h2>
            </div>

            {/* Large Instructional Pictorial Image */}
            <div className="relative w-full aspect-16/9 sm:aspect-21/9 rounded-xl overflow-hidden bg-[#FAF2F0] mb-6 border border-[#EFE8DE]">
              <img 
                src={step.image} 
                alt={step.title} 
                className="w-full h-full object-cover"
              />
              <div className="absolute top-3.5 left-3.5 px-3 py-1 rounded-full bg-[#FAF8F5]/90 backdrop-blur-md text-[#2D2926] text-[10px] font-sans font-medium uppercase tracking-widest border border-[#EFE6D5]">
                Pictorial Visual Atelier Guide
              </div>
            </div>

            {/* Short Clear Explanation */}
            <div className="prose max-w-none mb-6">
              <h4 className="text-xs font-sans font-semibold uppercase tracking-[0.2em] text-[#7D7571] mb-2">
                Atelier Instruction
              </h4>
              <p className="text-sm sm:text-base text-[#2D2926] font-sans leading-relaxed">
                {step.explanation}
              </p>
            </div>

            {/* Materials List */}
            <div className="p-5 rounded-xl bg-[#FAF8F5] border border-[#EFE8DE] mb-5">
              <h4 className="text-xs font-sans font-semibold uppercase tracking-[0.2em] text-[#7D7571] mb-3">
                Materials Required for this Step
              </h4>
              <div className="flex flex-wrap gap-2">
                {step.materials.map((mat, i) => (
                  <span 
                    key={i}
                    className="inline-flex items-center gap-1.5 px-3.5 py-1 rounded-full bg-[#FFFFFF] border border-[#EFE8DE] text-xs font-sans font-medium text-[#2D2926]"
                  >
                    <span className="w-1.5 h-1.5 rounded-full bg-[#C5A059]" />
                    {mat}
                  </span>
                ))}
              </div>
            </div>

            {/* Pro Tip Box */}
            {step.proTip && (
              <div className="p-4 rounded-xl bg-[#FAF2F0] border border-[#EFE6D5] text-[#2D2926] text-xs font-sans flex items-start gap-3">
                <Sparkles className="w-4 h-4 text-[#C5A059] shrink-0 mt-0.5" />
                <div>
                  <span className="font-semibold text-[#2D2926]">Artist Pro-Tip: </span>
                  <span className="text-[#57514D]">{step.proTip}</span>
                </div>
              </div>
            )}
          </div>

          {/* Bottom Step Navigation Bar */}
          <div className="flex flex-wrap items-center justify-between gap-4 px-6 sm:px-8 py-5 bg-[#FAF8F5] border-t border-[#EFE8DE]">
            <button
              id="tutorial-prev-step-button"
              disabled={currentStepIndex === 0}
              onClick={() => setCurrentStepIndex((prev) => Math.max(0, prev - 1))}
              className="flex items-center gap-2 px-4 py-2.5 rounded-full text-xs font-sans font-semibold bg-[#FFFFFF] border border-[#EFE8DE] text-[#2D2926] disabled:opacity-40 disabled:cursor-not-allowed hover:bg-[#FAF2F0] transition-colors"
            >
              <ChevronLeft className="w-4 h-4 text-[#C5A059]" />
              <span>Previous Step</span>
            </button>

            <div className="flex items-center gap-3">
              <button
                id="tutorial-complete-step-button"
                onClick={handleCompleteStep}
                className={`flex items-center gap-2 px-5 py-2.5 rounded-full text-xs font-sans font-semibold transition-all ${
                  completedSteps.includes(step.stepNumber)
                    ? 'bg-[#FAF2F0] text-[#2D2926] border border-[#C5A059]'
                    : 'bg-[#2D2926] hover:bg-[#1A1A1A] text-white'
                }`}
              >
                <CheckCircle2 className={`w-4 h-4 ${completedSteps.includes(step.stepNumber) ? 'text-[#C5A059]' : 'text-white'}`} />
                <span>{completedSteps.includes(step.stepNumber) ? 'Step Completed ✓' : 'Mark Step Complete'}</span>
              </button>

              {currentStepIndex < tutorial.totalSteps - 1 ? (
                <button
                  id="tutorial-next-step-button"
                  onClick={() => setCurrentStepIndex((prev) => Math.min(tutorial.totalSteps - 1, prev + 1))}
                  className="flex items-center gap-2 px-6 py-2.5 rounded-full text-xs font-sans font-semibold bg-[#C5A059] hover:bg-[#B38E46] text-[#2D2926] shadow-2xs transition-colors uppercase tracking-wider"
                >
                  <span>Next Step</span>
                  <ChevronRight className="w-4 h-4" />
                </button>
              ) : (
                <button
                  id="tutorial-finish-button"
                  onClick={handleFinishTutorial}
                  className="flex items-center gap-2 px-6 py-2.5 rounded-full text-xs font-sans font-semibold bg-[#C5A059] hover:bg-[#B38E46] text-[#2D2926] shadow-md transition-all uppercase tracking-wider"
                >
                  <Award className="w-4 h-4" />
                  <span>Complete Masterclass</span>
                </button>
              )}
            </div>
          </div>
        </div>
      ) : (
        /* Tutorial Completed Celebration Card */
        <div className="bg-[#FFFFFF] rounded-2xl p-10 text-center border border-[#EFE8DE] shadow-[0_4px_24px_rgba(45,41,38,0.04)] mb-8 animate-in zoom-in-95 duration-200">
          <div className="w-16 h-16 rounded-full bg-[#FAF2F0] border border-[#EFE6D5] text-[#C5A059] flex items-center justify-center mx-auto mb-4">
            <Award className="w-8 h-8" />
          </div>
          <h2 className="text-3xl sm:text-4xl font-serif font-bold text-[#2D2926]">
            Masterclass Completed
          </h2>
          <p className="text-xs sm:text-sm text-[#7D7571] font-sans max-w-md mx-auto mt-2 leading-relaxed">
            You've completed all {tutorial.totalSteps} steps of <strong>{tutorial.title}</strong>. Put your new techniques into practice in the atelier studio!
          </p>

          <div className="flex flex-wrap items-center justify-center gap-3 mt-8">
            <button
              id="tutorial-practice-cta-button"
              onClick={onGoToPractice}
              className="flex items-center gap-2 px-6 py-3.5 rounded-full bg-[#C5A059] hover:bg-[#B38E46] text-[#2D2926] text-xs font-sans font-semibold uppercase tracking-wider shadow-md transition-all"
            >
              <Sparkles className="w-4 h-4" />
              <span>Start Practical Task in "Create With Me"</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            <button
              id="tutorial-review-again-button"
              onClick={() => {
                setIsCompleted(false);
                setCurrentStepIndex(0);
              }}
              className="px-5 py-3.5 rounded-full bg-[#FAF8F5] border border-[#EFE8DE] text-[#2D2926] text-xs font-sans font-medium hover:bg-[#FAF2F0]"
            >
              Review Steps Again
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
