import React, { useState, useEffect } from 'react';
import { 
  MainMode, 
  ArtCategory, 
  Tutorial, 
  Artwork, 
  ArtistProfile, 
  MusicTrack 
} from './types';
import { ART_CATEGORIES } from './data/categoriesData';
import { TUTORIALS_DATA, getTutorialsForCategory } from './data/tutorialsData';
import { ARTWORKS_DATA } from './data/artworksData';
import { ARTISTS_DATA } from './data/artistsData';

import { Navbar } from './components/Navbar';
import { CategoryPicker } from './components/CategoryPicker';
import { WelcomeScreen } from './components/WelcomeScreen';
import { CategoryDashboard } from './components/CategoryDashboard';
import { TutorialViewer } from './components/TutorialViewer';
import { MusicExperience } from './components/MusicExperience';
import { DiscoverFeed } from './components/DiscoverFeed';
import { PitchMyArt } from './components/PitchMyArt';
import { BuyArtMarketplace } from './components/BuyArtMarketplace';
import { ArtistDiscovery } from './components/ArtistDiscovery';
import { ExploreNearby } from './components/ExploreNearby';
import { ContestPrep } from './components/ContestPrep';
import { IdeaGenerator } from './components/IdeaGenerator';
import { HomePersonalized } from './components/HomePersonalized';
import { SettingsModal } from './components/SettingsModal';
import { FloatingAudioPlayer } from './components/FloatingAudioPlayer';
import { BottomNav } from './components/BottomNav';
import { AndroidCodeHub } from './components/AndroidCodeHub';
import { WorkshopsLanding } from './components/WorkshopsLanding';

export default function App() {
  // Navigation & Mode
  const [currentMode, setCurrentMode] = useState<MainMode>('welcome');
  const [activeCategory, setActiveCategory] = useState<ArtCategory>(ART_CATEGORIES[0]);
  const [activeTutorial, setActiveTutorial] = useState<Tutorial | null>(null);
  const [activeArtist, setActiveArtist] = useState<ArtistProfile | null>(null);
  const [activeArtwork, setActiveArtwork] = useState<Artwork | null>(null);

  // Appearance & Preferences
  const [darkMode, setDarkMode] = useState<boolean>(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isAndroidHubOpen, setIsAndroidHubOpen] = useState(false);

  // User Saved & Liked Content
  const [savedTutorialIds, setSavedTutorialIds] = useState<string[]>(['tut-watercolor-landscape-01']);
  const [savedArtworkIds, setSavedArtworkIds] = useState<string[]>(['art-alpine-mist-01']);
  const [savedTrackIds, setSavedTrackIds] = useState<string[]>(['track-jazz-01']);
  const [likedArtworkIds, setLikedArtworkIds] = useState<string[]>(['art-alpine-mist-01']);
  const [userArtworks, setUserArtworks] = useState<Artwork[]>([]);

  // Floating Audio
  const [activeFloatingTrack, setActiveFloatingTrack] = useState<MusicTrack | null>(null);

  // Synchronize Dark Mode Class on Root
  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [darkMode]);

  // Handlers
  const handleToggleDarkMode = () => {
    setDarkMode(!darkMode);
  };

  const handleSelectCategory = (category: ArtCategory) => {
    setActiveCategory(category);
    if (category.id === 'music') {
      setCurrentMode('music');
    } else if (currentMode === 'welcome' || currentMode === 'category_pick') {
      setCurrentMode('learn');
    }
  };

  const handleWelcomeChoice = (option: 'learn' | 'pitch' | 'buy' | 'discover' | 'workshops' | 'expos' | 'studio') => {
    if (option === 'learn') {
      setCurrentMode('category_pick');
    } else if (option === 'pitch') {
      setCurrentMode('pitch');
    } else if (option === 'buy') {
      setCurrentMode('buy');
    } else if (option === 'discover') {
      setCurrentMode('discover');
    } else if (option === 'workshops') {
      setCurrentMode('workshops');
    } else if (option === 'expos') {
      setCurrentMode('events');
    } else if (option === 'studio') {
      setCurrentMode('artist_detail');
    }
  };

  const handleOpenTutorial = (tutorial: Tutorial) => {
    setActiveTutorial(tutorial);
    setCurrentMode('tutorial_view');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleToggleSaveTutorial = (id: string) => {
    if (savedTutorialIds.includes(id)) {
      setSavedTutorialIds(savedTutorialIds.filter(i => i !== id));
    } else {
      setSavedTutorialIds([...savedTutorialIds, id]);
    }
  };

  const handleToggleSaveArtwork = (id: string) => {
    if (savedArtworkIds.includes(id)) {
      setSavedArtworkIds(savedArtworkIds.filter(i => i !== id));
    } else {
      setSavedArtworkIds([...savedArtworkIds, id]);
    }
  };

  const handleToggleLikeArtwork = (id: string) => {
    if (likedArtworkIds.includes(id)) {
      setLikedArtworkIds(likedArtworkIds.filter(i => i !== id));
    } else {
      setLikedArtworkIds([...likedArtworkIds, id]);
    }
  };

  const handleToggleSaveTrack = (id: string) => {
    if (savedTrackIds.includes(id)) {
      setSavedTrackIds(savedTrackIds.filter(i => i !== id));
    } else {
      setSavedTrackIds([...savedTrackIds, id]);
    }
  };

  const handlePublishSuccess = (artwork: Artwork) => {
    setUserArtworks(prev => [artwork, ...prev]);
  };

  const handleSelectArtist = (artist: ArtistProfile) => {
    setActiveArtist(artist);
    setCurrentMode('artist_detail');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleOpenBuyArtwork = (artwork: Artwork) => {
    setActiveArtwork(artwork);
    setCurrentMode('buy');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleResetOnboarding = () => {
    setCurrentMode('welcome');
  };

  const savedTutorialsList = TUTORIALS_DATA.filter(t => savedTutorialIds.includes(t.id));
  const savedArtworksList = [...userArtworks, ...ARTWORKS_DATA].filter(a => savedArtworkIds.includes(a.id));

  return (
    <div className="min-h-screen bg-[#FDFCF9] dark:bg-[#0B1622] text-[#1A1A1A] dark:text-[#F8FAFC] flex flex-col font-sans antialiased transition-colors duration-200 pb-16 lg:pb-0">
      
      {/* Global Navbar */}
      {currentMode !== 'welcome' && <Navbar
        currentMode={currentMode}
        onSelectMode={(mode) => {
          setCurrentMode(mode);
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
        activeCategory={activeCategory}
        categories={ART_CATEGORIES}
        onSelectCategory={handleSelectCategory}
        darkMode={darkMode}
        onToggleDarkMode={handleToggleDarkMode}
        onOpenSettings={() => setIsSettingsOpen(true)}
        onOpenBookmarks={() => setIsSettingsOpen(true)}
        onOpenAndroidHub={() => setIsAndroidHubOpen(true)}
        savedCount={savedTutorialIds.length + savedArtworkIds.length}
      />}

      {/* Sticky Horizontal Category Carousel (Visible whenever NOT on first-open welcome) */}
      {currentMode !== 'welcome' && currentMode !== 'category_pick' && (
        <CategoryPicker
          categories={ART_CATEGORIES}
          activeCategory={activeCategory}
          onSelectCategory={handleSelectCategory}
        />
      )}

      {/* Main App Content Viewport */}
      <main className="flex-1 w-full">
        
        {/* FIRST-OPEN WELCOME SCREEN */}
        {currentMode === 'welcome' && (
          <WelcomeScreen
            onSelectOption={handleWelcomeChoice}
            onExploreDirectly={() => setCurrentMode('home')}
          />
        )}

        {/* ONBOARDING: "What kind of art are you interested in?" Grid Picker */}
        {currentMode === 'category_pick' && (
          <CategoryPicker
            categories={ART_CATEGORIES}
            activeCategory={activeCategory}
            onSelectCategory={handleSelectCategory}
            showFullGridPrompt={true}
            onContinue={() => setCurrentMode('learn')}
          />
        )}

        {/* HOME DASHBOARD (Personalized & Structured) */}
        {currentMode === 'home' && (
          <HomePersonalized
            onSelectMode={(mode) => {
              setCurrentMode(mode);
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            activeCategory={activeCategory}
            onSelectCategory={handleSelectCategory}
            onOpenTutorial={handleOpenTutorial}
            onOpenIdeaGenerator={() => setCurrentMode('idea_gen')}
            onOpenContestPrep={() => setCurrentMode('contest_prep')}
            savedTutorialIds={savedTutorialIds}
          />
        )}

        {currentMode === 'workshops' && <WorkshopsLanding />}

        {/* LEARN & EXPLORE CATEGORY DASHBOARD */}
        {currentMode === 'learn' && (
          <CategoryDashboard
            category={activeCategory}
            onOpenTutorial={handleOpenTutorial}
            onOpenIdeaGenerator={() => setCurrentMode('idea_gen')}
            onOpenContestPrep={() => setCurrentMode('contest_prep')}
            onOpenNearbyEvents={() => setCurrentMode('events')}
            onOpenArtists={() => setCurrentMode('artist_detail')}
            savedTutorialIds={savedTutorialIds}
            onToggleSaveTutorial={handleToggleSaveTutorial}
          />
        )}

        {/* STEP-BY-STEP PICTORIAL TUTORIAL VIEWER */}
        {currentMode === 'tutorial_view' && (
          <TutorialViewer
            tutorial={activeTutorial || getTutorialsForCategory(activeCategory)[0] || TUTORIALS_DATA[0]}
            onBack={() => setCurrentMode('learn')}
            onGoToPractice={() => setCurrentMode('learn')}
            isSaved={activeTutorial ? savedTutorialIds.includes(activeTutorial.id) : false}
            onToggleSave={handleToggleSaveTutorial}
          />
        )}

        {/* DEDICATED MUSIC JOURNEY & ROYALTY-FREE WEBAUDIO */}
        {currentMode === 'music' && (
          <MusicExperience
            savedTrackIds={savedTrackIds}
            onToggleSaveTrack={handleToggleSaveTrack}
            onActiveTrackChange={(track) => setActiveFloatingTrack(track)}
          />
        )}

        {/* DISCOVER INSPIRING ART FEED */}
        {currentMode === 'discover' && (
          <DiscoverFeed
            onSelectArtist={handleSelectArtist}
            onOpenBuyArtwork={handleOpenBuyArtwork}
            likedArtworkIds={likedArtworkIds}
            onToggleLike={handleToggleLikeArtwork}
            savedArtworkIds={savedArtworkIds}
            onToggleSave={handleToggleSaveArtwork}
          />
        )}

        {/* PITCH MY ART CREATOR FLOW */}
        {currentMode === 'pitch' && (
          <PitchMyArt
            categories={ART_CATEGORIES}
            onPublishSuccess={handlePublishSuccess}
            onGoToBuyArt={() => setCurrentMode('buy')}
          />
        )}

        {/* BUY ART MARKETPLACE */}
        {currentMode === 'buy' && (
          <BuyArtMarketplace
            initialArtwork={activeArtwork}
            onSelectArtist={handleSelectArtist}
            userArtworks={userArtworks}
            savedArtworkIds={savedArtworkIds}
            onToggleSave={handleToggleSaveArtwork}
          />
        )}

        {/* ARTIST DIRECTORY & PROFILES */}
        {currentMode === 'artist_detail' && (
          <ArtistDiscovery
            selectedArtistInitial={activeArtist}
            onOpenArtworkDetail={handleOpenBuyArtwork}
          />
        )}

        {/* NEARBY EVENTS & GEOLOCATION */}
        {currentMode === 'events' && (
          <ExploreNearby />
        )}

        {/* CREATE FOR A CHALLENGE / CONTEST PREP */}
        {currentMode === 'contest_prep' && (
          <ContestPrep />
        )}

        {/* GET CREATIVE IDEAS GENERATOR */}
        {currentMode === 'idea_gen' && (
          <IdeaGenerator
            categories={ART_CATEGORIES}
            activeCategory={activeCategory}
          />
        )}

      </main>

      {/* Floating Audio Playback Bar */}
      <FloatingAudioPlayer
        track={activeFloatingTrack}
        onClose={() => setActiveFloatingTrack(null)}
        onOpenMusicMode={() => setCurrentMode('music')}
      />

      {/* Settings & Bookmarks Modal */}
      <SettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        darkMode={darkMode}
        onToggleDarkMode={handleToggleDarkMode}
        onResetOnboarding={handleResetOnboarding}
        savedTutorials={savedTutorialsList}
        savedArtworks={savedArtworksList}
        onOpenTutorial={handleOpenTutorial}
      />

      {/* Android Kotlin Jetpack Compose Code Inspector */}
      {isAndroidHubOpen && (
        <AndroidCodeHub onClose={() => setIsAndroidHubOpen(false)} />
      )}

      {/* Mobile Bottom Navigation */}
      {currentMode !== 'welcome' && <BottomNav
        currentMode={currentMode}
        onSelectMode={(mode) => {
          setCurrentMode(mode);
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
      />}
    </div>
  );
}
