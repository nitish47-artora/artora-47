import { ContestChallenge } from '../types';

export const CONTESTS_DATA: ContestChallenge[] = [
  {
    id: 'challenge-7day-portrait',
    title: '7-Day Expressive Portrait Challenge',
    subtitle: 'From reference selection to final gallery-ready presentation step-by-step.',
    organizer: 'ARTORA International Creative Guild',
    category: 'Painting & Drawing',
    deadline: 'November 15, 2026',
    daysRemaining: 12,
    prizePool: '$2,500 Artist Grants + Global Feature',
    image: 'https://images.unsplash.com/photo-1544717305-2782549b5136?auto=format&fit=crop&w=800&q=80',
    theme: 'Empathy & Light: The Human Spirit',
    sevenDayPlan: [
      { day: 1, title: 'Choose Reference & Mood Board', task: 'Select a high-resolution reference with clear directional lighting (Rembrandt or side light). Study the facial skull tilt.', focus: 'Observational lighting clarity' },
      { day: 2, title: 'Loomis Skeleton & Contour Sketch', task: 'Construct the cranial sphere, brow crosshairs, and establish anatomical facial thirds lightly.', focus: 'Structural proportions & symmetry' },
      { day: 3, title: 'Value Map & Shadow Grouping', task: 'Squint and block in all shadow areas in one unified flat tone. Establish the 5-point value scale.', focus: 'Value hierarchy' },
      { day: 4, title: 'Color Blocking & Temperature Harmony', task: 'Establish skin undertones: warm forehead, neutral midface/cheeks, cool jawline.', focus: 'Color temperature contrast' },
      { day: 5, title: 'Render Micro-Features & Details', task: 'Carve crisp edges around the iris reflections, nose cartilage, and lips without over-smoothing.', focus: 'Focal sharpness' },
      { day: 6, title: 'Atmospheric Background & Edge Control', task: 'Blend lost and found edges between hair/jawline and background shadows.', focus: 'Depth & unity' },
      { day: 7, title: 'Photograph, Sign & Presentation', task: 'Photograph under diffused daylight, crop with clean margins, write an artist statement, and submit!', focus: 'Portfolio presentation' }
    ],
    guidelines: [
      'Original work created during the 7-day window using traditional or digital medium',
      'Minimum resolution of 3000px on long edge or high-res scan',
      'Include a short 150-word statement describing your subject'
    ],
    evaluationCriteria: [
      'Emotional storytelling and gaze impact (35%)',
      'Value mastery and anatomical proportions (30%)',
      'Brushwork confidence and material craftsmanship (25%)',
      'Presentation clarity and artist statement (10%)'
    ],
    portfolioTips: [
      'Avoid high-contrast artificial ring light references; natural light reveals authentic planes',
      'Always shoot flat art in indirect outdoor shade to avoid camera glare and hot spots',
      'Submit high-res TIFF or uncompressed JPG files with accurate sRGB color profiles'
    ]
  },
  {
    id: 'challenge-botanical-biophilia',
    title: 'Biophilia & Botanical Form Contest',
    subtitle: 'Celebrating plant intelligence, seed morphology, and organic patterns.',
    organizer: 'National Botanical Art Association',
    category: 'Watercolor & Illustration',
    deadline: 'December 01, 2026',
    daysRemaining: 24,
    prizePool: '$4,000 in Fine Art Supplies + Solo Exhibition',
    image: 'https://images.unsplash.com/photo-1579783900882-c0d3dad7b119?auto=format&fit=crop&w=800&q=80',
    theme: 'Flora in Transition: Bloom to Seed',
    sevenDayPlan: [
      { day: 1, title: 'Botanical Foraging & Specimen Dissection', task: 'Gather live plant specimens and examine leaf venation under a magnifying loupe.', focus: 'Scientific accuracy' },
      { day: 2, title: 'Precision Line Study', task: 'Draw 1:1 scale contour outlines using 2H graphite on smooth hot-press paper.', focus: 'Exact botanical geometry' },
      { day: 3, title: 'Translucent Glaze Base', task: 'Apply pale yellow-green undertones across all foliage shapes.', focus: 'Luminosity' },
      { day: 4, title: 'Building Vein Contrast', task: 'Paint negative spaces between secondary leaf veins with deep Sap Green and Raw Umber.', focus: 'Depth & shadow' },
      { day: 5, title: 'Texture & Granulation', task: 'Add organic stem hair texture and petal velvet sheen using dry-brush strokes.', focus: 'Tactile fidelity' },
      { day: 6, title: 'Stem Anatomy & Shadow Casts', task: 'Paint delicate cast shadows where overlapping petals throw shade onto lower leaves.', focus: 'Dimensionality' },
      { day: 7, title: 'Archival Mounting & Submission', task: 'Mount behind acid-free 4-ply museum matboard and finalize submission form.', focus: 'Gallery readiness' }
    ],
    guidelines: [
      'Botanical species must be accurately named with binomial Latin nomenclature',
      'Pure watercolor, gouache, or colored pencil on acid-free cotton'
    ],
    evaluationCriteria: [
      'Scientific fidelity and morphological proportion (40%)',
      'Watercolor glaze translucency and edge control (40%)',
      'Compositional elegance and white space balance (20%)'
    ],
    portfolioTips: [
      'Use a magnifying glass to check that delicate stamens and pistils are intact',
      'Leave ample breathing room around your specimen rather than crowding the frame'
    ]
  }
];
