import { ArtCategory } from '../types';

export const ART_CATEGORIES: ArtCategory[] = [
  {
    id: 'painting',
    name: 'Painting',
    tagline: 'Explore, learn and create.',
    description: 'Transform blank canvases into vibrant expressions with oils, acrylics, watercolours, and mixed mediums.',
    icon: 'Palette',
    color: '#E11D48', // rose-600
    bgGradient: 'from-rose-500/10 via-amber-500/5 to-transparent',
    coverImage: 'https://images.unsplash.com/photo-1579783902614-a3fb3927b675?auto=format&fit=crop&w=1000&q=80',
    types: [
      { name: 'Watercolor', description: 'Fluid, translucent washes capturing light and soft gradients.', image: 'https://images.unsplash.com/photo-1579783900882-c0d3dad7b119?auto=format&fit=crop&w=600&q=80' },
      { name: 'Oil', description: 'Rich, blendable pigments with deep luster and slow drying versatility.', image: 'https://images.unsplash.com/photo-1579783902614-a3fb3927b675?auto=format&fit=crop&w=600&q=80' },
      { name: 'Acrylic', description: 'Fast-drying, vibrant, and flexible on almost any surface.', image: 'https://images.unsplash.com/photo-1541701494587-cb58502866ab?auto=format&fit=crop&w=600&q=80' },
      { name: 'Gouache', description: 'Opaque watercolor allowing velvety flat coats and reworkable layers.', image: 'https://images.unsplash.com/photo-1582201942988-13e60e4556ee?auto=format&fit=crop&w=600&q=80' },
      { name: 'Tempera', description: 'Historic egg-emulsion medium known for permanent, crisp detail.', image: 'https://images.unsplash.com/photo-1549887534-1541e9326642?auto=format&fit=crop&w=600&q=80' },
      { name: 'Ink & Wash', description: 'Expressive monochromatic brushwork with bold contrast and tone.', image: 'https://images.unsplash.com/photo-1607604276583-eef5d076aa5f?auto=format&fit=crop&w=600&q=80' },
      { name: 'Mixed Media', description: 'Combining acrylics, collage, pastels, and textures in unified works.', image: 'https://images.unsplash.com/photo-1513364776144-60967b0f800f?auto=format&fit=crop&w=600&q=80' }
    ],
    styles: [
      { name: 'Realism', description: 'Precise depiction of light, anatomy, and everyday reality.' },
      { name: 'Impressionism', description: 'Capturing transient light and spontaneous brushstroke gestures.' },
      { name: 'Abstract', description: 'Focus on pure color harmony, geometric form, and emotional rhythm.' },
      { name: 'Portrait', description: 'Exploring character, skin tones, and expressive facial identity.' },
      { name: 'Landscape', description: 'Atmospheric depth, natural horizons, and environmental light.' },
      { name: 'Still Life', description: 'Inanimate arrangements studying light reflection and texture.' },
      { name: 'Expressionism', description: 'Distorted reality to evoke raw psychological emotion.' },
      { name: 'Surrealism', description: 'Dreamlike imagery juxtaposing realistic elements unpredictably.' },
      { name: 'Traditional', description: 'Classical academic techniques rooted in heritage traditions.' },
      { name: 'Modern', description: 'Contemporary experimental concepts pushing visual frontiers.' },
      { name: 'Digital Painting', description: 'Using stylus tablets to paint with unlimited virtual palettes.' }
    ],
    techniques: [
      { title: 'Glazing & Layering', difficulty: 'Intermediate', description: 'Applying thin, transparent films of paint over dried underpaintings to achieve luminous optical depth.', tip: 'Ensure bottom layers are thoroughly dry before applying next glaze.', tools: ['Liquin / Glazing medium', 'Soft mop brush', 'Lint-free rag'] },
      { title: 'Wet-on-Wet (Alla Prima)', difficulty: 'Beginner', description: 'Blending wet pigment directly into wet paper or canvas for seamless atmospheric gradients.', tip: 'Control water saturation by tilting your work board gently.', tools: ['Heavy cold-press paper', 'Round squirrel brush', 'Spray mister'] },
      { title: 'Impasto Knife Sculpting', difficulty: 'Intermediate', description: 'Thick, dimensional application of paint leaving prominent ridges that catch gallery lighting.', tip: 'Use heavy-body acrylics or oil gel mediums to build relief without cracking.', tools: ['Palette knives', 'Heavy gel medium', 'Stretched canvas'] },
      { title: 'Sfumato & Soft Blending', difficulty: 'Advanced', description: 'Gradual softening of edges and tones without sharp transitions, famously used by Da Vinci.', tip: 'Feather dry fan brushes across boundaries with feather-light touch.', tools: ['Dry fan brush', 'Soft blending sponge', 'Retarder'] }
    ],
    popularMaterials: ['Stretched Cotton Canvas', 'Kolinsky Sable / Synthetic Brushes', 'Cadmium & Cobalt Pigments', 'Gamsol Solvent', 'Cold-Press Watercolor Blocks'],
    historyFact: 'The earliest known cave paintings date back over 45,000 years, using ochre and charcoal blown through hollow bone reeds.'
  },
  {
    id: 'drawing',
    name: 'Drawing',
    tagline: 'Master line, form, and proportion.',
    description: 'The foundation of all visual arts. Explore graphite, charcoal, pens, and pastels to build structural accuracy.',
    icon: 'Pencil',
    color: '#2563EB', // blue-600
    bgGradient: 'from-blue-500/10 via-indigo-500/5 to-transparent',
    coverImage: 'https://images.unsplash.com/photo-1544717305-2782549b5136?auto=format&fit=crop&w=1000&q=80',
    types: [
      { name: 'Graphite Sketching', description: 'Precision grading from 9H to 9B for delicate tonal gradation.', image: 'https://images.unsplash.com/photo-1513364776144-60967b0f800f?auto=format&fit=crop&w=600&q=80' },
      { name: 'Charcoal & Conté', description: 'Velvety deep blacks and atmospheric smudging for dynamic gesture.', image: 'https://images.unsplash.com/photo-1579783902614-a3fb3927b675?auto=format&fit=crop&w=600&q=80' },
      { name: 'Ink & Cross-Hatching', description: 'Clean archival fineliner work building volume through density.', image: 'https://images.unsplash.com/photo-1607604276583-eef5d076aa5f?auto=format&fit=crop&w=600&q=80' },
      { name: 'Colored Pencil', description: 'Wax and oil-based burnishing for photo-realistic saturation.', image: 'https://images.unsplash.com/photo-1582201942988-13e60e4556ee?auto=format&fit=crop&w=600&q=80' }
    ],
    styles: [
      { name: 'Figure & Anatomy', description: 'Dynamic skeletal and muscular proportion studies.' },
      { name: 'Architectural Perspective', description: 'One, two, and three-point vanishing point systems.' },
      { name: 'Botanical Illustration', description: 'Precise scientific recording of flora and leaf venation.' },
      { name: 'Gesture & Quick-Sketch', description: 'Capturing movement and weight in 30-second energetic poses.' }
    ],
    techniques: [
      { title: 'Sight-Size Proportioning', difficulty: 'Beginner', description: 'Using your pencil as a plumb line and measuring stick to compare proportional ratios.', tip: 'Keep your elbow locked at arms length when taking measurements.', tools: ['2B Pencil', 'Plumb line', 'Kneaded eraser'] },
      { title: 'Cross-Contour Hatching', difficulty: 'Intermediate', description: 'Lines curving around the volumetric cylinder of forms to communicate 3D mass.', tip: 'Follow the natural curvature of the object like latitude lines on a globe.', tools: ['0.3mm Pigment Liner', 'Smooth Bristol paper'] }
    ],
    popularMaterials: ['Strathmore 400 Sketchbook', 'Faber-Castell 9000 Pencils', 'Nitram Willow Charcoal', 'Sakura Pigma Micron Pens'],
    historyFact: 'Leonardo da Vinci created over 13,000 pages of drawings detailing mechanics, flight, and human anatomy.'
  },
  {
    id: 'sketching',
    name: 'Sketching',
    tagline: 'Capture spontaneous moments everywhere.',
    description: 'Quick visual notetaking, urban sketching, and loose compositional thumbnails in your daily journal.',
    icon: 'PenTool',
    color: '#0D9488', // teal-600
    bgGradient: 'from-teal-500/10 via-cyan-500/5 to-transparent',
    coverImage: 'https://images.unsplash.com/photo-1580196969807-cc6de06c05be?auto=format&fit=crop&w=1000&q=80',
    types: [
      { name: 'Urban Sketching', description: 'Drawing on-location in bustling city streets and cafés.', image: 'https://images.unsplash.com/photo-1580196969807-cc6de06c05be?auto=format&fit=crop&w=600&q=80' },
      { name: 'Travel Journaling', description: 'Combining watercolors, maps, and handwritten notes.', image: 'https://images.unsplash.com/photo-1544717305-2782549b5136?auto=format&fit=crop&w=600&q=80' },
      { name: 'Thumbnail Composition', description: 'Miniature value sketches planning master studio artworks.', image: 'https://images.unsplash.com/photo-1513364776144-60967b0f800f?auto=format&fit=crop&w=600&q=80' }
    ],
    styles: [
      { name: 'Loose Line & Wash', description: 'Bold fountain pen lines splashed with spontaneous watercolours.' },
      { name: 'Continuous Line', description: 'Drawing without lifting your pen from the paper once.' }
    ],
    techniques: [
      { title: 'Blind Contour Sketching', difficulty: 'Beginner', description: 'Looking only at the subject and never at your paper while your pen follows every visual edge.', tip: 'Helps bypass left-brain assumptions and train pure observational fidelity.', tools: ['Fountain pen', 'Pocket sketchbook'] }
    ],
    popularMaterials: ['Lamy Safari Fountain Pen', 'Moleskine Art Watercolor Pocket Album', 'Pocket Watercolor Pan Kit'],
    historyFact: 'Urban Sketchers is a global movement with thousands of official chapters meeting weekly worldwide.'
  },
  {
    id: 'watercolor',
    name: 'Watercolor',
    tagline: 'Let light and water dance across paper.',
    description: 'Master transparent pigments, atmospheric washes, controlled granulating textures, and dry-brush details.',
    icon: 'Droplets',
    color: '#0284C7', // sky-600
    bgGradient: 'from-sky-500/10 via-cyan-500/5 to-transparent',
    coverImage: 'https://images.unsplash.com/photo-1579783900882-c0d3dad7b119?auto=format&fit=crop&w=1000&q=80',
    types: [
      { name: 'Botanical Watercolor', description: 'Detailed organic studies of petals, seed pods, and leaves.', image: 'https://images.unsplash.com/photo-1579783900882-c0d3dad7b119?auto=format&fit=crop&w=600&q=80' },
      { name: 'Loose Atmospheric Landscape', description: 'Misty mountain gradients and reflective water reflections.', image: 'https://images.unsplash.com/photo-1579783902614-a3fb3927b675?auto=format&fit=crop&w=600&q=80' },
      { name: 'Portraits & Skin Tones', description: 'Luminescent glaze layering capturing subtle vascular undertones.', image: 'https://images.unsplash.com/photo-1582201942988-13e60e4556ee?auto=format&fit=crop&w=600&q=80' }
    ],
    styles: [
      { name: 'Granulating & Mineral', description: 'Using heavy earth minerals (Ultramarine, Lunar Black) that settle into paper texture.' },
      { name: 'High-Key Minimalist', description: 'Spacious white preserves with decisive, minimal brush accents.' }
    ],
    techniques: [
      { title: 'Preserving Whites with Masking Fluid', difficulty: 'Beginner', description: 'Protecting clean sparkling highlights before painting big washes.', tip: 'Never apply masking fluid with expensive sable brushes; use a silicone color shaper.', tools: ['Pebeo Drawing Gum', 'Silicone tool', '300gsm 100% Cotton Paper'] }
    ],
    popularMaterials: ['Arches 140lb Cold Press 100% Cotton', 'Winsor & Newton Professional Pans', 'Escoda Reserva Tajmyr Kolinsky Brushes'],
    historyFact: 'In traditional watercolor, there is no white paint; the white of the cotton paper provides every highlight.'
  },
  {
    id: 'oil-painting',
    name: 'Oil Painting',
    tagline: 'The timeless medium of the Old Masters.',
    description: 'Work with linseed oils, rich pigment load, slow oxidation, and historical academic glazing.',
    icon: 'Brush',
    color: '#D97706', // amber-600
    bgGradient: 'from-amber-500/10 via-orange-500/5 to-transparent',
    coverImage: 'https://images.unsplash.com/photo-1579783902614-a3fb3927b675?auto=format&fit=crop&w=1000&q=80',
    types: [
      { name: 'Classical Academic Underpainting', description: 'Grisaille and verdaccio value foundations.', image: 'https://images.unsplash.com/photo-1579783902614-a3fb3927b675?auto=format&fit=crop&w=600&q=80' },
      { name: 'Plein Air Alla Prima', description: 'Fast outdoor landscape painting in a single dynamic session.', image: 'https://images.unsplash.com/photo-1541701494587-cb58502866ab?auto=format&fit=crop&w=600&q=80' }
    ],
    styles: [
      { name: 'Chiaroscuro', description: 'Dramatic high-contrast spotlighting pioneered by Caravaggio and Rembrandt.' },
      { name: 'Contemporary Figurative', description: 'Bold color palettes and expressive textured strokes.' }
    ],
    techniques: [
      { title: 'Fat Over Lean Principle', difficulty: 'Beginner', description: 'Ensuring early under-layers have less oil (lean) and top layers have more oil (fat) to prevent paint cracking.', tip: 'Thin base layers with odorless mineral spirits; add linseed stand oil to subsequent glazes.', tools: ['Linseed Oil', 'Gamsol', 'Glass palette'] }
    ],
    popularMaterials: ['Old Holland / Williamsburg Oil Paints', 'Belgian Linen Canvases', 'Rosemary & Co Hog Bristle Brushes'],
    historyFact: 'Jan van Eyck was historically credited with perfecting stable oil binders in the 15th-century Flemish Renaissance.'
  },
  {
    id: 'acrylic-painting',
    name: 'Acrylic Painting',
    tagline: 'Versatile, bold, and modern.',
    description: 'Fast-drying polymer mediums suitable for pouring, heavy texture sculpting, and mixed-surface versatility.',
    icon: 'Sparkles',
    color: '#EA580C', // orange-600
    bgGradient: 'from-orange-500/10 via-red-500/5 to-transparent',
    coverImage: 'https://images.unsplash.com/photo-1541701494587-cb58502866ab?auto=format&fit=crop&w=1000&q=80',
    types: [
      { name: 'Fluid Acrylic Pouring', description: 'Dutch pours, ring pours, and silicone cell creation.', image: 'https://images.unsplash.com/photo-1541701494587-cb58502866ab?auto=format&fit=crop&w=600&q=80' },
      { name: 'Heavy Body Palette Knife', description: 'Crisp impasto reliefs and dynamic geometric slab cuts.', image: 'https://images.unsplash.com/photo-1513364776144-60967b0f800f?auto=format&fit=crop&w=600&q=80' }
    ],
    styles: [
      { name: 'Pop Art & Hard Edge', description: 'Bold graphic shapes, flat saturated color planes, and crisp tape lines.' },
      { name: 'Modern Abstract Texture', description: 'Plaster pastes, pumice, and gold leaf additions.' }
    ],
    techniques: [
      { title: 'Stay-Wet Palette Management', difficulty: 'Beginner', description: 'Using sponge and permeable parchment to keep acrylic blends workable for days.', tip: 'A light mist of distilled water before closing the lid keeps paint ready.', tools: ['Masterson Sta-Wet Palette', 'Heavy Body Acrylics'] }
    ],
    popularMaterials: ['Golden Heavy Body Acrylics', 'Liquitex Pouring Medium', 'Liquitex Flexible Modeling Paste'],
    historyFact: 'Acrylic paint was invented in the 1940s and popularized by abstract expressionists like Helen Frankenthaler.'
  },
  {
    id: 'digital-art',
    name: 'Digital Art',
    tagline: 'Infinite canvases and digital wizardry.',
    description: 'Concept art, character design, vector illustration, matte painting, and 3D digital sculpting.',
    icon: 'Laptop',
    color: '#9333EA', // purple-600
    bgGradient: 'from-purple-500/10 via-pink-500/5 to-transparent',
    coverImage: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=1000&q=80',
    types: [
      { name: 'Concept Art & Worldbuilding', description: 'Cinematic environments and vehicles for film and gaming.', image: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=600&q=80' },
      { name: 'Stylized Character Design', description: 'Expressive poses, silhouette clarity, and color turnarounds.', image: 'https://images.unsplash.com/photo-1634017839464-5c339ebe3cb4?auto=format&fit=crop&w=600&q=80' },
      { name: 'Vector Illustration', description: 'Scalable geometric artwork for branding and digital interfaces.', image: 'https://images.unsplash.com/photo-1550745165-9bc0b252726f?auto=format&fit=crop&w=600&q=80' }
    ],
    styles: [
      { name: 'Cyberpunk & Sci-Fi', description: 'Neon glows, rain reflections, and futuristic mechanical detailing.' },
      { name: 'Fantasy & Painterly', description: 'Textured brush engines emulating organic oils and gouache.' }
    ],
    techniques: [
      { title: 'Color Dodge Light Bloom', difficulty: 'Intermediate', description: 'Layer blending mode setups for ethereal magical glows and neon highlights.', tip: 'Paint glows with a soft round brush on low flow over dark backgrounds.', tools: ['Procreate / Photoshop', 'Pressure-sensitive Stylus'] }
    ],
    popularMaterials: ['Apple iPad Pro + Apple Pencil', 'Wacom Cintiq Pro', 'Clip Studio Paint / Photoshop / Procreate'],
    historyFact: 'The first digital paint program, SuperPaint, was developed in 1972 at Xerox PARC.'
  },
  {
    id: 'photography',
    name: 'Photography',
    tagline: 'Capture light, soul, and fleeting instants.',
    description: 'Master exposure triangle (ISO, Aperture, Shutter Speed), composition, street narrative, and darkroom/digital grading.',
    icon: 'Camera',
    color: '#059669', // emerald-600
    bgGradient: 'from-emerald-500/10 via-teal-500/5 to-transparent',
    coverImage: 'https://images.unsplash.com/photo-1516035069371-29a1b244cc32?auto=format&fit=crop&w=1000&q=80',
    types: [
      { name: 'Portrait', description: 'Capturing personality, gaze, and natural or studio lighting.', image: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=600&q=80' },
      { name: 'Landscape', description: 'Wide vistas, dramatic golden hour skies, and long exposures.', image: 'https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=600&q=80' },
      { name: 'Street', description: 'Unposed candid human moments in urban environments.', image: 'https://images.unsplash.com/photo-1477959858617-67f30bc75b82?auto=format&fit=crop&w=600&q=80' },
      { name: 'Wildlife', description: 'Patience and telephoto precision capturing animals in habitat.', image: 'https://images.unsplash.com/photo-1474511320723-9a56873ee008?auto=format&fit=crop&w=600&q=80' },
      { name: 'Macro', description: 'Extreme close-ups revealing unseen textures in insects and dew.', image: 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?auto=format&fit=crop&w=600&q=80' },
      { name: 'Fashion', description: 'Editorial styling, haute couture, and narrative aesthetics.', image: 'https://images.unsplash.com/photo-1490481651871-ab68de25d43d?auto=format&fit=crop&w=600&q=80' },
      { name: 'Architecture', description: 'Clean leading lines, symmetry, and geometric shadow play.', image: 'https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=600&q=80' }
    ],
    styles: [
      { name: 'Monochrome High-Contrast', description: 'Timeless black & white prioritizing tonal forms and geometry.' },
      { name: 'Cinematic Color Grade', description: 'Teal and orange color harmony with film grain emulation.' }
    ],
    techniques: [
      { title: 'Rule of Thirds & Leading Lines', difficulty: 'Beginner', description: 'Placing focal subjects on grid intersections and using pathways to pull the viewer’s eye.', tip: 'Turn on 3x3 camera grid overlay in your viewfinder.', tools: ['Prime 35mm / 50mm Lens', 'Tripod', 'Polarizing Filter'] }
    ],
    popularMaterials: ['Mirrorless Full-Frame Cameras (Sony/Canon/Fuji)', 'Fast f/1.4 - f/1.8 Prime Lenses', 'ND Filters'],
    historyFact: 'The oldest surviving photograph was taken in 1826 by Nicéphore Niépce, requiring an 8-hour exposure.'
  },
  {
    id: 'sculpture',
    name: 'Sculpture',
    tagline: 'Shape physical volume in three dimensions.',
    description: 'Work in clay, stone, bronze casting, wood carving, and modern kinetic wire constructions.',
    icon: 'Layers',
    color: '#7C3AED', // violet-600
    bgGradient: 'from-violet-500/10 via-purple-500/5 to-transparent',
    coverImage: 'https://images.unsplash.com/photo-1544816155-12df9643f363?auto=format&fit=crop&w=1000&q=80',
    types: [
      { name: 'Clay Modeling & Armature', description: 'Building up oil or water-based clay on wire skeletons.', image: 'https://images.unsplash.com/photo-1544816155-12df9643f363?auto=format&fit=crop&w=600&q=80' },
      { name: 'Direct Stone Carving', description: 'Subtractive sculpting in marble, soapstone, and limestone.', image: 'https://images.unsplash.com/photo-1579783902614-a3fb3927b675?auto=format&fit=crop&w=600&q=80' }
    ],
    styles: [
      { name: 'Classical Figurative', description: 'Anatomical contrapposto balance and realistic drapery.' },
      { name: 'Minimalist Kinetic', description: 'Abstract forms that interact with wind, light, and gravity.' }
    ],
    techniques: [
      { title: 'Aluminum Wire Armature Building', difficulty: 'Beginner', description: 'Constructing the structural backbone that supports clay figures without sagging.', tip: 'Anchor wire joints firmly with epoxy putty or wire tie wrap.', tools: ['1/8" Armature wire', 'Pliers', 'Wooden base mount'] }
    ],
    popularMaterials: ['Chavant NSP Monster Clay', 'Wax carving tools', 'Silicone mold making rubber'],
    historyFact: 'Michelangelo believed the finished sculpture was already hidden inside the marble block, and his job was merely to chisel away the excess stone.'
  },
  {
    id: 'pottery',
    name: 'Pottery',
    tagline: 'Centering clay, heart, and wheel.',
    description: 'Transform raw earthenware, stoneware, and porcelain into functional vessels and artistic cups.',
    icon: 'Coffee',
    color: '#B45309', // amber-700
    bgGradient: 'from-amber-600/10 via-yellow-500/5 to-transparent',
    coverImage: 'https://images.unsplash.com/photo-1565193566173-7a0ee3dbe261?auto=format&fit=crop&w=1000&q=80',
    types: [
      { name: 'Wheel Throwing', description: 'Centering and pulling cylinders, bowls, and vases on the potter’s wheel.', image: 'https://images.unsplash.com/photo-1565193566173-7a0ee3dbe261?auto=format&fit=crop&w=600&q=80' },
      { name: 'Hand-building (Pinch & Coil)', description: 'Sculpting organic vessels with rhythmic finger coils.', image: 'https://images.unsplash.com/photo-1578749556568-bc2c40e68b61?auto=format&fit=crop&w=600&q=80' }
    ],
    styles: [
      { name: 'Wabi-Sabi Aesthetics', description: 'Celebrating organic imperfection, natural ash deposits, and earthiness.' },
      { name: 'Nordic Minimalist Functional', description: 'Clean lines, ergonomic handles, and soft satin matte glazes.' }
    ],
    techniques: [
      { title: 'Centering the Clay Cone', difficulty: 'Beginner', description: 'Using core arm leverage against your thighs to force spinning clay into exact equilibrium.', tip: 'Anchor your elbows firmly into your inner thighs rather than using arm muscle alone.', tools: ['Potter wheel', 'Clay sponge', 'Cutting wire'] }
    ],
    popularMaterials: ['Stoneware Clay (B-Mix)', 'High-fire Glazes (Cone 6/10)', 'Kemper Trimming Tools'],
    historyFact: 'Pottery is one of the oldest human inventions, with vessels dating back over 20,000 years discovered in Xianrendong Cave, China.'
  },
  {
    id: 'ceramics',
    name: 'Ceramics',
    tagline: 'High-fire alchemy, glazes, and ceramic sculpture.',
    description: 'Advanced kiln chemistry, raku firing, crystalline glazes, porcelain refinement, and structural ceramic tiles.',
    icon: 'Sparkles',
    color: '#0891B2', // cyan-600
    bgGradient: 'from-cyan-500/10 via-teal-500/5 to-transparent',
    coverImage: 'https://images.unsplash.com/photo-1578749556568-bc2c40e68b61?auto=format&fit=crop&w=1000&q=80',
    types: [
      { name: 'Porcelain Slip Casting', description: 'Pouring liquid clay into multi-part plaster molds for fine translucency.', image: 'https://images.unsplash.com/photo-1578749556568-bc2c40e68b61?auto=format&fit=crop&w=600&q=80' },
      { name: 'Raku & Smoke Firing', description: 'Removing red-hot ceramics directly from the kiln into sawdust reduction chambers.', image: 'https://images.unsplash.com/photo-1565193566173-7a0ee3dbe261?auto=format&fit=crop&w=600&q=80' }
    ],
    styles: [
      { name: 'Crystalline Glaze Art', description: 'Growing zinc silicate crystals inside the glaze during controlled kiln cooling.' }
    ],
    techniques: [
      { title: 'Sgraffito Carving', difficulty: 'Intermediate', description: 'Carving through colored underglaze on leather-hard clay to reveal contrasting clay body.', tip: 'Wait until clay is firm leather-hard so carved cuts come away clean without burrs.', tools: ['Loop carving ribbon', 'Underglazes', 'Soft hake brush'] }
    ],
    popularMaterials: ['Cone 10 Porcelain', 'Electric / Gas Kiln', 'Underglaze Applicator Bottles'],
    historyFact: 'Kintsugi is the Japanese ceramic art of repairing broken pottery with lacquer dusted with powdered gold, silver, or platinum.'
  },
  {
    id: 'crochet',
    name: 'Crochet',
    tagline: 'Loop by loop into cozy creations.',
    description: 'Create amigurumi plushies, wearable garments, blankets, accessories, and intricate lace patterns with hook and yarn.',
    icon: 'Feather',
    color: '#DB2777', // pink-600
    bgGradient: 'from-pink-500/10 via-rose-500/5 to-transparent',
    coverImage: 'https://images.unsplash.com/photo-1584992236310-6edddc08acff?auto=format&fit=crop&w=1000&q=80',
    types: [
      { name: 'Amigurumi', description: 'Japanese art of crocheting stuffed plush characters and dolls.', image: 'https://images.unsplash.com/photo-1584992236310-6edddc08acff?auto=format&fit=crop&w=600&q=80' },
      { name: 'Garments & Cardigans', description: 'Wearable sweaters, bralettes, and textured cardigans.', image: 'https://images.unsplash.com/photo-1606760227091-3dd870d97f1d?auto=format&fit=crop&w=600&q=80' },
      { name: 'Home Decor', description: 'Throw blankets, pillow covers, plant hangers, and storage baskets.', image: 'https://images.unsplash.com/photo-1584992236310-6edddc08acff?auto=format&fit=crop&w=600&q=80' },
      { name: 'Accessories', description: 'Tote bags, bucket hats, scrunchies, and winter beanies.', image: 'https://images.unsplash.com/photo-1606760227091-3dd870d97f1d?auto=format&fit=crop&w=600&q=80' },
      { name: 'Patterns & Granny Squares', description: 'Modular motifs combined into kaleidoscope afghans.', image: 'https://images.unsplash.com/photo-1584992236310-6edddc08acff?auto=format&fit=crop&w=600&q=80' },
      { name: 'Techniques & Stitches', description: 'Single, double, treble, bobble, and waffle stitch masteries.', image: 'https://images.unsplash.com/photo-1584992236310-6edddc08acff?auto=format&fit=crop&w=600&q=80' }
    ],
    styles: [
      { name: 'Boho Vintage Granny Square', description: 'Retro 70s color palettes and modular floral geometric blocks.' },
      { name: 'Kawaii Pastel Miniatures', description: 'Cute, miniature plushies with safety eyes and soft embroidery.' }
    ],
    techniques: [
      { title: 'The Magic Ring (Magic Circle)', difficulty: 'Beginner', description: 'Creating an adjustable yarn loop that tightens completely closed with zero center hole for round amigurumi.', tip: 'Wrap yarn twice around two fingers and pull first loop through before chaining one.', tools: ['3.5mm - 4.0mm Crochet Hook', 'DK / Worsted Cotton Yarn', 'Stitch marker'] },
      { title: 'Invisible Decrease (invdec)', difficulty: 'Intermediate', description: 'Working into front loops only of adjacent stitches for seamless, gap-free shaping.', tip: 'Keep yarn tension steady so no stuffing pokes out through holes.', tools: ['Ergonomic crochet hook', 'Yarn needle', 'Polyfill'] }
    ],
    popularMaterials: ['Clover Amour Ergonomic Hooks', '100% Mercerized Cotton Yarn', 'Locking Stitch Markers'],
    historyFact: 'Unlike knitting which can be replicated by industrial machines, crochet can still ONLY be made by human hands!'
  },
  {
    id: 'knitting',
    name: 'Knitting',
    tagline: 'Two needles, endless rhythm.',
    description: 'Knit and purl your way through cable sweaters, cozy socks, lace shawls, and colorwork Scandinavian mittens.',
    icon: 'Grid',
    color: '#9333EA', // purple-600
    bgGradient: 'from-purple-500/10 via-violet-500/5 to-transparent',
    coverImage: 'https://images.unsplash.com/photo-1606760227091-3dd870d97f1d?auto=format&fit=crop&w=1000&q=80',
    types: [
      { name: 'Cable Knits & Textures', description: 'Intricate braided ropes and honeycombs.', image: 'https://images.unsplash.com/photo-1606760227091-3dd870d97f1d?auto=format&fit=crop&w=600&q=80' },
      { name: 'Fair Isle & Colorwork', description: 'Stranded multi-colored Nordic and Shetland motifs.', image: 'https://images.unsplash.com/photo-1584992236310-6edddc08acff?auto=format&fit=crop&w=600&q=80' }
    ],
    styles: [
      { name: 'Scandinavian Hygge', description: 'Neutral wools, chunky cardigans, and timeless raglan yokes.' }
    ],
    techniques: [
      { title: 'German Twisted Cast-On', difficulty: 'Beginner', description: 'An elastic, durable cast-on method ideal for sock cuffs and sweater necklines.', tip: 'Leave a generous tail three times the width of your project.', tools: ['Circular knitting needles', 'Wool yarn'] }
    ],
    popularMaterials: ['KnitPro Symfonie Wood Needles', 'Merino Wool / Alpaca Blends', 'Cable needle'],
    historyFact: 'During World War II, knitting was used to encode secret espionage messages into garments using knit and purl binary morse code.'
  },
  {
    id: 'embroidery',
    name: 'Embroidery',
    tagline: 'Painting with thread and needle.',
    description: 'Thread painting, satin stitch florals, French knots, goldwork, and modern botanical hoop art.',
    icon: 'Feather',
    color: '#BE185D', // pink-700
    bgGradient: 'from-pink-500/10 via-rose-500/5 to-transparent',
    coverImage: 'https://images.unsplash.com/photo-1544816155-12df9643f363?auto=format&fit=crop&w=1000&q=80',
    types: [
      { name: 'Thread Painting (Silk Shading)', description: 'Blended single-strand long and short stitches emulating realistic animal fur and petals.', image: 'https://images.unsplash.com/photo-1544816155-12df9643f363?auto=format&fit=crop&w=600&q=80' },
      { name: 'Modern Hoop Art', description: 'Minimalist line art and textured floral French knot bouquets.', image: 'https://images.unsplash.com/photo-1584992236310-6edddc08acff?auto=format&fit=crop&w=600&q=80' }
    ],
    styles: [
      { name: 'Botanical & Foliage', description: 'Lush eucalyptus leaves, wildflowers, and delicate ferns on linen.' }
    ],
    techniques: [
      { title: 'The Perfect French Knot', difficulty: 'Beginner', description: 'Wrapping thread twice around the needle while keeping tension taut as it passes through fabric.', tip: 'Hold working thread tight with your non-dominant thumb until needle pulls through fully.', tools: ['DMC 6-Strand Floss', 'Size 5 Embroidery Needle', 'Beechwood Hoop'] }
    ],
    popularMaterials: ['DMC Mouliné Spécial Floss', 'Unbleached Belgian Linen Fabric', 'Elbesee Wooden Hoops'],
    historyFact: 'The Bayeux Tapestry from the 1070s is actually an embroidered cloth nearly 70 meters long depicting the Norman conquest of England.'
  },
  {
    id: 'textile-art',
    name: 'Textile Art',
    tagline: 'Weaving, dyeing, and structural fibers.',
    description: 'Tapestry loom weaving, natural plant indigo dyeing (Shibori), punch needle, and macramé knotting.',
    icon: 'Layers',
    color: '#4F46E5', // indigo-600
    bgGradient: 'from-indigo-500/10 via-blue-500/5 to-transparent',
    coverImage: 'https://images.unsplash.com/photo-1528459801416-a9e53bbf4e17?auto=format&fit=crop&w=1000&q=80',
    types: [
      { name: 'Tapestry Loom Weaving', description: 'Warp and weft interlocking textured wools and roving fibers.', image: 'https://images.unsplash.com/photo-1528459801416-a9e53bbf4e17?auto=format&fit=crop&w=600&q=80' },
      { name: 'Punch Needle & Tufting', description: 'Quick volumetric loop art for wall hangings and custom rugs.', image: 'https://images.unsplash.com/photo-1584992236310-6edddc08acff?auto=format&fit=crop&w=600&q=80' }
    ],
    styles: [
      { name: 'Shibori Indigo Resist', description: 'Japanese folding and clamp dye techniques producing hypnotic indigo patterns.' }
    ],
    techniques: [
      { title: 'Rya Knot Fringe Weaving', difficulty: 'Beginner', description: 'Creating lush cascading tassels across the bottom edge of wall hangings.', tip: 'Cut uniform lengths using a piece of stiff cardboard as a winding guide.', tools: ['Frame Loom', 'Chunky roving wool', 'Weaving comb'] }
    ],
    popularMaterials: ['Wooden Lap Frame Loom', 'Unspun Merino Wool Roving', 'Oxford Punch Needle #10'],
    historyFact: 'The Jacquard Loom invented in 1804 used punch cards and is considered one of the primary conceptual ancestors of modern computer programming.'
  },
  {
    id: 'calligraphy',
    name: 'Calligraphy',
    tagline: 'The timeless beauty of the written letter.',
    description: 'Pointed pen Copperplate, broad-edge Blackletter, expressive Asian brush calligraphy, and modern brush lettering.',
    icon: 'PenTool',
    color: '#0F766E', // teal-700
    bgGradient: 'from-teal-600/10 via-emerald-500/5 to-transparent',
    coverImage: 'https://images.unsplash.com/photo-1580196969807-cc6de06c05be?auto=format&fit=crop&w=1000&q=80',
    types: [
      { name: 'Copperplate & Spencerian', description: 'Delicate hairline upstrokes and rich shaded downstrokes with flexible nibs.', image: 'https://images.unsplash.com/photo-1580196969807-cc6de06c05be?auto=format&fit=crop&w=600&q=80' },
      { name: 'Broad-Edge Gothic & Italic', description: 'Geometric, authoritative medieval script with chisel nibs.', image: 'https://images.unsplash.com/photo-1544717305-2782549b5136?auto=format&fit=crop&w=600&q=80' }
    ],
    styles: [
      { name: 'Modern Organic Brush Script', description: 'Bouncy baselines and relaxed flourishes favored in luxury branding.' }
    ],
    techniques: [
      { title: 'Tension & Pressure Transition', difficulty: 'Beginner', description: 'Light as a feather on upstrokes, firm deliberate pressure on downstrokes.', tip: 'Hold pen at a 45-degree angle to the baseline guide and write with whole arm movement.', tools: ['Nikko G Nib', 'Oblique Pen Holder', 'Sumi Ink', 'Rhodia Dot Pad'] }
    ],
    popularMaterials: ['Brause Steno & Nikko G Nibs', 'Moon Palace Sumi Ink', 'Tombow Fudenosuke Brush Pens'],
    historyFact: 'Steve Jobs attributed the typography and proportional fonts in Apple computers to calligraphy classes he audited at Reed College.'
  },
  {
    id: 'origami',
    name: 'Origami',
    tagline: 'Geometry and poetry in folded paper.',
    description: 'Transform single uncut sheets of paper into intricate animals, geometric tessellations, and modular modular polyhedra.',
    icon: 'Layers',
    color: '#C026D3', // fuchsia-600
    bgGradient: 'from-fuchsia-500/10 via-purple-500/5 to-transparent',
    coverImage: 'https://images.unsplash.com/photo-1579783900882-c0d3dad7b119?auto=format&fit=crop&w=1000&q=80',
    types: [
      { name: 'Traditional & Animal Figurative', description: 'Cranes, dragons, beetles, and lotus blooms from single squares.', image: 'https://images.unsplash.com/photo-1579783900882-c0d3dad7b119?auto=format&fit=crop&w=600&q=80' },
      { name: 'Geometric Tessellations', description: 'Repeating pleated patterns that play with light and translucency.', image: 'https://images.unsplash.com/photo-1580196969807-cc6de06c05be?auto=format&fit=crop&w=600&q=80' }
    ],
    styles: [
      { name: 'Wet-Folding Sculptural', description: 'Dampening thick paper to fold gentle curved organic animals with lifelike weight.' }
    ],
    techniques: [
      { title: 'The Squash & Petal Fold', difficulty: 'Beginner', description: 'Opening a pocket of paper and flattening it symmetrically along centerline.', tip: 'Use a bone folder to burnish crisp, razor-sharp creases.', tools: ['Kami Paper / Tant Paper', 'Bone folder'] }
    ],
    popularMaterials: ['Japanese Washi Paper', 'Tant / Elephant Hide Paper', 'Teflon Bone Folder'],
    historyFact: 'Modern origami mathematical algorithms are used by NASA engineers to fold solar arrays and space telescopes into rocket payloads.'
  },
  {
    id: 'woodcraft',
    name: 'Woodcraft',
    tagline: 'Carve, join, and honor the grain.',
    description: 'Hand-tool woodworking, whittling, woodturning, joinery (dovetails, mortise & tenon), and bespoke furniture craft.',
    icon: 'Hammer',
    color: '#78350F', // amber-900
    bgGradient: 'from-amber-800/10 via-yellow-700/5 to-transparent',
    coverImage: 'https://images.unsplash.com/photo-1544816155-12df9643f363?auto=format&fit=crop&w=1000&q=80',
    types: [
      { name: 'Spoon Whittling & Green Woodworking', description: 'Carving ergonomic eating utensils from freshly felled branches.', image: 'https://images.unsplash.com/photo-1544816155-12df9643f363?auto=format&fit=crop&w=600&q=80' },
      { name: 'Traditional Hand Joinery', description: 'Cutting airtight dovetails and Japanese shoji frames without nails or screws.', image: 'https://images.unsplash.com/photo-1578749556568-bc2c40e68b61?auto=format&fit=crop&w=600&q=80' }
    ],
    styles: [
      { name: 'Japanese Sashimono & Kumiko', description: 'Intricate interlocking wooden lattice grids of geometric cedar.' }
    ],
    techniques: [
      { title: 'Reading Grain Direction', difficulty: 'Beginner', description: 'Carving with the grain rather than against it to prevent wood fibers from tearing.', tip: 'If your gouge begins to dig or chatter, reverse cutting direction.', tools: ['Mora 106 Whittling Knife', 'Hook knife', 'Diamond sharpening stone'] }
    ],
    popularMaterials: ['Black Walnut & White Oak', 'Basswood (Linden) for Carving', 'Tung Oil & Beeswax Finish'],
    historyFact: 'Horyu-ji temple in Japan is the oldest wooden structure in the world, standing firm for over 1,400 years with traditional wood joinery.'
  },
  {
    id: 'paper-craft',
    name: 'Paper Craft',
    tagline: 'Quilling, pop-ups, and paper sculpture.',
    description: 'Paper quilling, intricate laser/knife paper cutting (Kirie), 3D paper engineering, and handcrafted bookbinding.',
    icon: 'Layers',
    color: '#0284C7', // sky-600
    bgGradient: 'from-sky-500/10 via-blue-500/5 to-transparent',
    coverImage: 'https://images.unsplash.com/photo-1580196969807-cc6de06c05be?auto=format&fit=crop&w=1000&q=80',
    types: [
      { name: 'Paper Quilling Art', description: 'Rolling, shaping, and gluing narrow paper strips into decorative filigree.', image: 'https://images.unsplash.com/photo-1580196969807-cc6de06c05be?auto=format&fit=crop&w=600&q=80' },
      { name: 'Shadow Box Cut-Paper Dioramas', description: 'Layering multi-plane illuminated paper scenes with LED backlights.', image: 'https://images.unsplash.com/photo-1579783900882-c0d3dad7b119?auto=format&fit=crop&w=600&q=80' }
    ],
    styles: [
      { name: 'Botanical Quilled Mosaic', description: 'Lush 3D floral arrangements with tight concentric coil petals.' }
    ],
    techniques: [
      { title: 'Slotted Tool Rolling & Tension Release', difficulty: 'Beginner', description: 'Coiling paper strips and expanding them to exact diameters in a circle sizer board.', tip: 'Use fine-tip needle glue bottles so paper stays pristine without smudges.', tools: ['Quilling slotted tool', 'Circle sizer ruler', 'PVA glue pen'] }
    ],
    popularMaterials: ['Acid-Free Quilling Strips (3mm/5mm)', 'Canson Mi-Teintes Cardstock', 'Precision Craft Scalpel #11'],
    historyFact: 'Paper quilling originated during the Renaissance when French and Italian nuns used gilded paper trimmed from books to decorate religious artifacts.'
  },
  {
    id: 'jewelry-making',
    name: 'Jewelry Making',
    tagline: 'Adornment, metalsmithing, and wire craft.',
    description: 'Silversmithing, bezel gemstone setting, wire wrapping, polymer clay earrings, and beading loom arts.',
    icon: 'Sparkles',
    color: '#D97706', // amber-600
    bgGradient: 'from-amber-500/10 via-yellow-500/5 to-transparent',
    coverImage: 'https://images.unsplash.com/photo-1535632066927-ab7c9ab60908?auto=format&fit=crop&w=1000&q=80',
    types: [
      { name: 'Metalsmithing & Soldering', description: 'Sawing, soldering, and polishing sterling silver and brass.', image: 'https://images.unsplash.com/photo-1535632066927-ab7c9ab60908?auto=format&fit=crop&w=600&q=80' },
      { name: 'Wire Wrapping & Gemstones', description: 'Weaving raw crystals and cabochons securely with dead-soft wire.', image: 'https://images.unsplash.com/photo-1535632066927-ab7c9ab60908?auto=format&fit=crop&w=600&q=80' }
    ],
    styles: [
      { name: 'Organic Raw Mineral Boho', description: 'Oxidized metals framing unpolished crystals and sea glass.' }
    ],
    techniques: [
      { title: 'Soldering a Flush Ring Band', difficulty: 'Intermediate', description: 'Filing seamless butt joints and flowing silver solder with a butane micro torch.', tip: 'Both metal ends must touch with zero light gap for capillary action to pull solder through.', tools: ['Jeweler Saw Frame', 'Butane micro-torch', 'Pickle pot', 'Ring mandrel'] }
    ],
    popularMaterials: ['Sterling Silver Wire (925)', 'Natural Turquoise & Moonstone Cabochons', 'Liver of Sulfur patina'],
    historyFact: 'The oldest known jewelry items are 100,000-year-old Nassarius shell beads discovered in Skhul Cave, Israel.'
  },
  {
    id: 'traditional-folk-art',
    name: 'Traditional / Folk Art',
    tagline: 'Living heritage, indigenous motifs, and folk tales.',
    description: 'Madhubani, Warli, Kalamkari, Gond, Mexican Talavera, Nordic Rosemaling, and Ukrainian Petrykivka painting.',
    icon: 'Sparkles',
    color: '#DC2626', // red-600
    bgGradient: 'from-red-500/10 via-amber-500/5 to-transparent',
    coverImage: 'https://images.unsplash.com/photo-1549887534-1541e9326642?auto=format&fit=crop&w=1000&q=80',
    types: [
      { name: 'Madhubani & Mithila Painting', description: 'Intricate geometric borders and nature motifs filled with natural dye pigments.', image: 'https://images.unsplash.com/photo-1549887534-1541e9326642?auto=format&fit=crop&w=600&q=80' },
      { name: 'Warli Tribal Art', description: 'Rhythmic white rice-paste geometric figures depicting harvest and dance.', image: 'https://images.unsplash.com/photo-1549887534-1541e9326642?auto=format&fit=crop&w=600&q=80' },
      { name: 'Gond Art', description: 'Hypnotic dot and line pattern fills tracing spirits of trees and wildlife.', image: 'https://images.unsplash.com/photo-1549887534-1541e9326642?auto=format&fit=crop&w=600&q=80' }
    ],
    styles: [
      { name: 'Sacred Ritual Geometries', description: 'Dual-line borders filled with cross-hatchings and sun/moon iconography.' }
    ],
    techniques: [
      { title: 'Nib & Twig Double-Line Drawing', difficulty: 'Beginner', description: 'Drawing synchronized parallel contour lines without crossing or smudging.', tip: 'Maintain steady breath cadence when drawing continuous ritual border lines.', tools: ['Bamboo dip pens', 'Handmade cotton paper', 'Natural mineral dyes'] }
    ],
    popularMaterials: ['Handmade Cow-Dung Treated Paper', 'Turmeric, Indigo & Ochre Dyes', 'Fine calligraphy dip pens'],
    historyFact: 'Madhubani art is believed to have originated when King Janaka commissioned artists to decorate his kingdom for the wedding of his daughter Sita.'
  },
  {
    id: 'street-art',
    name: 'Street Art',
    tagline: 'Public murals, stencils, and monumental scale.',
    description: 'Aerosol spray can control, multi-layer stenciling, paste-ups, monumental outdoor murals, and typography.',
    icon: 'Zap',
    color: '#E11D48', // rose-600
    bgGradient: 'from-rose-600/10 via-orange-500/5 to-transparent',
    coverImage: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=1000&q=80',
    types: [
      { name: 'Aerosol Can Flare & Cut', description: 'Mastering low-pressure spray cans and specialized cap nozzles.', image: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=600&q=80' },
      { name: 'Multi-Layer Acetate Stencil', description: 'Precision multi-color registration stencil art.', image: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=600&q=80' }
    ],
    styles: [
      { name: 'Photorealistic Muralism', description: 'Gigantic realistic human portraits and endangered wildlife on 5-story building facades.' }
    ],
    techniques: [
      { title: 'Can Distance & Speed Modulation', difficulty: 'Beginner', description: 'Controlling distance from wall to vary line sharpness from razor thin to wide soft flares.', tip: 'Keep your wrist stiff and move from your entire shoulder when spraying long lines.', tools: ['Montana 94 Spray Cans', 'Skinny NY caps', 'Respirator mask with organic vapor cartridges'] }
    ],
    popularMaterials: ['Montana Gold / Belton Molotow Spray Cans', '3M Half-Face Dual Cartridge Respirator', 'Mylar stencil film'],
    historyFact: 'The Berlin Wall became the world’s longest open-air gallery in 1989, preserved today as the East Side Gallery.'
  },
  {
    id: 'graphic-design',
    name: 'Graphic Design',
    tagline: 'Visual communication, identity, and typography.',
    description: 'Brand identity systems, editorial layouts, poster design, packaging, and grid-based visual hierarchy.',
    icon: 'Layout',
    color: '#2563EB', // blue-600
    bgGradient: 'from-blue-500/10 via-indigo-500/5 to-transparent',
    coverImage: 'https://images.unsplash.com/photo-1550745165-9bc0b252726f?auto=format&fit=crop&w=1000&q=80',
    types: [
      { name: 'Brand Identity Systems', description: 'Logomarks, design guidelines, typography pairing, and color rules.', image: 'https://images.unsplash.com/photo-1550745165-9bc0b252726f?auto=format&fit=crop&w=600&q=80' },
      { name: 'Swiss Poster & Grid Design', description: 'Strict mathematical baseline grids and asymmetric white space.', image: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=600&q=80' }
    ],
    styles: [
      { name: 'Modernist Bauhaus', description: 'Form follows function with bold primary colors and clean geometric typography.' }
    ],
    techniques: [
      { title: 'Modular Baseline Grid Construction', difficulty: 'Beginner', description: 'Aligning typography leading to 8pt or 12pt baseline grids for visual harmony.', tip: 'Consistent vertical rhythm makes multi-page documents instantly feel professional.', tools: ['Figma / Illustrator / InDesign'] }
    ],
    popularMaterials: ['Pantone Formula Guide Coated', 'Type Specimen Books', 'Vector bezier curve engines'],
    historyFact: 'Paul Rand designed the iconic IBM logo in 1956, which remains globally recognized today with its 8 horizontal stripes.'
  },
  {
    id: 'animation',
    name: 'Animation',
    tagline: 'Bring still drawings to dynamic life.',
    description: '2D hand-drawn frame-by-frame, 3D character rigging, stop-motion, and motion graphics.',
    icon: 'Film',
    color: '#84CC16', // lime-500
    bgGradient: 'from-lime-500/10 via-emerald-500/5 to-transparent',
    coverImage: 'https://images.unsplash.com/photo-1550745165-9bc0b252726f?auto=format&fit=crop&w=1000&q=80',
    types: [
      { name: '2D Hand-Drawn Frame-by-Frame', description: 'Traditional light-table keyframing, inbetweening, and cleanups.', image: 'https://images.unsplash.com/photo-1634017839464-5c339ebe3cb4?auto=format&fit=crop&w=600&q=80' },
      { name: 'Stop Motion Claymation', description: 'Physically posing clay puppets frame by frame at 24fps.', image: 'https://images.unsplash.com/photo-1544816155-12df9643f363?auto=format&fit=crop&w=600&q=80' }
    ],
    styles: [
      { name: 'Anime & Dynamic Action', description: 'Exaggerated perspectives, speed lines, and impactful impact frames.' }
    ],
    techniques: [
      { title: 'Squash & Stretch with Volume Preservation', difficulty: 'Beginner', description: 'Compressing and elongating shapes to communicate weight and speed while maintaining mass.', tip: 'If you squash a bouncing ball horizontally, it must expand vertically by the exact same proportion.', tools: ['RoughAnimator / Toon Boom Harmony / Blender'] }
    ],
    popularMaterials: ['Dragonframe Stop Motion Software', 'Toon Boom Harmony', '24fps Lightbox Table'],
    historyFact: 'The "12 Basic Principles of Animation" were introduced by Disney animators Ollie Johnston and Frank Thomas in their 1981 book "The Illusion of Life".'
  },
  {
    id: 'music',
    name: 'Music',
    tagline: 'Sound, harmony, rhythm, and emotion.',
    description: 'Explore musical genres, instruments, chord progressions, demo tracks, and composer techniques.',
    icon: 'Music',
    color: '#6366F1', // indigo-500
    bgGradient: 'from-indigo-500/10 via-purple-500/5 to-transparent',
    coverImage: 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?auto=format&fit=crop&w=1000&q=80',
    types: [
      { name: 'Instrumental Performance', description: 'Mastering piano, guitar, strings, brass, and percussion.', image: 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?auto=format&fit=crop&w=600&q=80' },
      { name: 'Music Theory & Composition', description: 'Chord voicings, counterpoint, harmonic cadences, and melody writing.', image: 'https://images.unsplash.com/photo-1514525253161-7a46d19cd819?auto=format&fit=crop&w=600&q=80' },
      { name: 'Audio Production & Synthesis', description: 'Sound design, mixing, mastering, and analog synthesizers.', image: 'https://images.unsplash.com/photo-1598488035139-bdbb2231ce04?auto=format&fit=crop&w=600&q=80' }
    ],
    styles: [
      { name: 'Acoustic & Orchestral', description: 'Natural reverberant resonance of wood, brass, and grand halls.' },
      { name: 'Electronic & Synthesized', description: 'Modular oscillators, filtered basslines, and programmable drum machines.' }
    ],
    techniques: [
      { title: 'The Circle of Fifths Navigation', difficulty: 'Beginner', description: 'Visualizing key signatures and complementary harmonic modulations effortlessly.', tip: 'Adjacent keys on the circle share 6 out of 7 notes, creating seamless musical transitions.', tools: ['Piano Keyboard', 'Metronome', 'Notation Sheet'] }
    ],
    popularMaterials: ['Grand Acoustic Piano', 'Fender Stratocaster / Gibson Les Paul', 'Audio-Technica M50x Studio Headphones'],
    historyFact: 'The earliest known musical instrument is the 40,000-year-old Divje Babe flute carved from the femur bone of a cave bear.'
  },
  {
    id: 'dance',
    name: 'Dance',
    tagline: 'The poetry of human movement.',
    description: 'Ballet, Contemporary, Hip-Hop, Bharatanatyam, Flamenco, Salsa, and choreographic improvisation.',
    icon: 'Sparkles',
    color: '#EC4899', // pink-500
    bgGradient: 'from-pink-500/10 via-rose-500/5 to-transparent',
    coverImage: 'https://images.unsplash.com/photo-1508700115892-45ecd05ae2ad?auto=format&fit=crop&w=1000&q=80',
    types: [
      { name: 'Classical Ballet', description: 'Turnout, pointe work, precise geometric lines, and fluid grand jetés.', image: 'https://images.unsplash.com/photo-1508700115892-45ecd05ae2ad?auto=format&fit=crop&w=600&q=80' },
      { name: 'Contemporary & Lyrical', description: 'Floor work, release technique, and gravity-defying emotional storytelling.', image: 'https://images.unsplash.com/photo-1547153760-18fc86324498?auto=format&fit=crop&w=600&q=80' }
    ],
    styles: [
      { name: 'Street & Breakdance', description: 'Toprock, footwork, power moves, freezes, and rhythmic cyphers.' }
    ],
    techniques: [
      { title: 'Spotting During Pirouettes', difficulty: 'Beginner', description: 'Fixing your eyes on a single focal point as your body rotates to prevent dizziness and maintain balance.', tip: 'Whip your head around faster than your body turns so your eyes return to the spot immediately.', tools: ['Sprung dance floor', 'Ballet barre', 'Mirror studio'] }
    ],
    popularMaterials: ['Freed of London Pointe Shoes', 'Ballet Barre & Marley Sprung Floor', 'Dance Resistance Bands'],
    historyFact: 'Ballet began during the Italian Renaissance in the 15th century and was formalized in France by King Louis XIV, who founded the Royal Academy of Dance.'
  }
];
