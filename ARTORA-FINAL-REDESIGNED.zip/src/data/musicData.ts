import { MusicGenreInfo } from '../types';

export const MUSIC_GENRES_DATA: Record<string, MusicGenreInfo> = {
  jazz: {
    id: 'jazz',
    name: 'Jazz',
    tagline: 'Improvisation, syncopation, and swing feel.',
    coverImage: 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?auto=format&fit=crop&w=1000&q=80',
    history: 'Originating in New Orleans African American communities in the late 19th and early 20th centuries, Jazz fused blues harmonies, ragtime syncopation, and European harmonic structures into an expressive art form celebrating spontaneous improvisation.',
    characteristics: [
      'Extensive use of 7th, 9th, and altered chord extensions (ii-V-I progressions)',
      'Swing eighth-note rhythmic feel and syncopated accents',
      'Call-and-response vocal and instrumental phrasing',
      'Modal and bebop spontaneous improvisational solos'
    ],
    commonInstruments: [
      { name: 'Saxophone (Tenor/Alto)', role: 'Lead melodic phrasing, warm breathy tones and fiery bebop runs.', image: 'https://images.unsplash.com/photo-1525994886773-080587e161c2?auto=format&fit=crop&w=400&q=80' },
      { name: 'Upright Acoustic Bass', role: 'Walking bass lines driving the steady harmonic and rhythmic foundation.', image: 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?auto=format&fit=crop&w=400&q=80' },
      { name: 'Semi-Hollow Jazz Guitar', role: 'Warm comping chords, Wes Montgomery thumb octaves, and clean tones.', image: 'https://images.unsplash.com/photo-1514525253161-7a46d19cd819?auto=format&fit=crop&w=400&q=80' },
      { name: 'Grand Piano', role: 'Rootless chord voicings, rhythmic accents, and lush harmonies.', image: 'https://images.unsplash.com/photo-1520523839898-507127053c3d?auto=format&fit=crop&w=400&q=80' },
      { name: 'Ride Cymbal & Brushes', role: 'Delicate feathered swing patterns providing continuous momentum.', image: 'https://images.unsplash.com/photo-1519892300165-cb5542fb47c7?auto=format&fit=crop&w=400&q=80' }
    ],
    featuredArtists: [
      { name: 'Miles Davis', era: '1926–1991', description: 'Visionary trumpeter who spearheaded Cool Jazz, Hard Bop, and Modal Jazz.', image: 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?auto=format&fit=crop&w=400&q=80' },
      { name: 'John Coltrane', era: '1926–1967', description: 'Saxophone virtuoso renowned for sheets of sound and spiritual jazz explorations.', image: 'https://images.unsplash.com/photo-1525994886773-080587e161c2?auto=format&fit=crop&w=400&q=80' },
      { name: 'Ella Fitzgerald', era: '1917–1996', description: 'The First Lady of Song, celebrated for her flawless intonation and scat singing.', image: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=400&q=80' }
    ],
    tracks: [
      {
        id: 'track-jazz-1',
        title: 'Blue Note Midnight Promenade',
        artist: 'The Artora Jazz Quintet',
        genre: 'Jazz',
        duration: 32,
        audioPreset: 'jazz_swing',
        coverImage: 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?auto=format&fit=crop&w=400&q=80',
        description: 'Smooth Dm9 to G13 swing cadence accompanied by acoustic upright bass and brush rhythm.',
        instrumentsUsed: ['Acoustic Piano', 'Upright Bass', 'Brushed Snare', 'Muted Horn'],
        bpm: 110,
        license: 'Original Artora Composition'
      },
      {
        id: 'track-jazz-2',
        title: 'Autumn Velvet Standards',
        artist: 'Harbor Trio',
        genre: 'Jazz',
        duration: 28,
        audioPreset: 'lofi_chill',
        coverImage: 'https://images.unsplash.com/photo-1514525253161-7a46d19cd819?auto=format&fit=crop&w=400&q=80',
        description: 'Lush major 7th chord voicings evoking a cozy late-night café atmosphere.',
        instrumentsUsed: ['Rhodes Piano', 'Archtop Guitar', 'Sub Bass'],
        bpm: 85,
        license: 'Royalty-Free'
      }
    ],
    learningResources: [
      { title: 'The Anatomy of a ii-V-I Chord Progression', type: 'Harmonic Interactive Guide', duration: '15 mins' },
      { title: 'Mastering the Dorian & Mixolydian Scales', type: 'Scale Exercise Sheet', duration: '20 mins' },
      { title: 'Walking Bass Lines for Beginners', type: 'Rhythm Breakdown', duration: '25 mins' }
    ],
    relatedGenres: ['Blues', 'Classical', 'Soul', 'Bossa Nova']
  },
  classical: {
    id: 'classical',
    name: 'Classical',
    tagline: 'Orchestral grandeur, counterpoint, and timeless harmony.',
    coverImage: 'https://images.unsplash.com/photo-1520523839898-507127053c3d?auto=format&fit=crop&w=1000&q=80',
    history: 'Spanning from the Medieval and Renaissance periods through the Baroque, Classical, Romantic, and Modern eras, Western classical music formalized complex symphonic structures, sonatas, and polyphonic counterpoint.',
    characteristics: [
      'Strict formal architecture (Sonata-Allegro form, Fugues, Rondos)',
      'Rich dynamic range (pianissimo whisper to fortissimo tutti)',
      'Polyphony and intricate counterpoint melodies',
      'Acoustic resonance of string quartets and grand orchestras'
    ],
    commonInstruments: [
      { name: 'Grand Piano', role: 'Dynamic acoustic percussive hammer-string instrument spanning 88 keys.', image: 'https://images.unsplash.com/photo-1520523839898-507127053c3d?auto=format&fit=crop&w=400&q=80' },
      { name: 'Violin & String Ensemble', role: 'Soaring expressive vibrato and lyrical melodic lines.', image: 'https://images.unsplash.com/photo-1612225330812-01a9c6b355ec?auto=format&fit=crop&w=400&q=80' },
      { name: 'Cello', role: 'Warm resonant baritone foundation bridging bass and upper strings.', image: 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?auto=format&fit=crop&w=400&q=80' }
    ],
    featuredArtists: [
      { name: 'Johann Sebastian Bach', era: '1685–1750', description: 'Baroque master of counterpoint, fugues, and structural symmetry.', image: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=400&q=80' },
      { name: 'Ludwig van Beethoven', era: '1770–1827', description: 'Revolutionary figure bridging the Classical and Romantic eras with dramatic power.', image: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=400&q=80' },
      { name: 'Frédéric Chopin', era: '1810–1849', description: 'The Poet of the Piano, famed for nocturnes, ballades, and expressive rubato.', image: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=400&q=80' }
    ],
    tracks: [
      {
        id: 'track-classical-1',
        title: 'Nocturne in E-Flat Arpeggio (Clair Tribute)',
        artist: 'Artora Chamber Ensemble',
        genre: 'Classical',
        duration: 35,
        audioPreset: 'classical_piano',
        coverImage: 'https://images.unsplash.com/photo-1520523839898-507127053c3d?auto=format&fit=crop&w=400&q=80',
        description: 'Delicate ascending and descending piano arpeggios demonstrating classical harmonic clarity.',
        instrumentsUsed: ['Concert Grand Piano'],
        bpm: 72,
        license: 'Public Domain'
      }
    ],
    learningResources: [
      { title: 'Understanding Sonata-Allegro Form', type: 'Structure Guide', duration: '18 mins' },
      { title: 'How to Read Orchestral Clefs (Treble, Bass, Alto)', type: 'Notation Primer', duration: '22 mins' }
    ],
    relatedGenres: ['Film Music', 'Opera', 'Ambient', 'Choral']
  },
  blues: {
    id: 'blues',
    name: 'Blues',
    tagline: 'Soulful bends, 12-bar cycles, and raw feeling.',
    coverImage: 'https://images.unsplash.com/photo-1514525253161-7a46d19cd819?auto=format&fit=crop&w=1000&q=80',
    history: 'Born in the Mississippi Delta in the late 19th century, the blues expressed struggle, resilience, and hope. It is the direct parent of rock and roll, jazz, R&B, and modern popular music.',
    characteristics: [
      '12-bar blues structural framework (I-IV-V dominant 7th chords)',
      'Expressive vocal and guitar string microtonal pitch bends',
      'AAB rhyming lyrical scheme',
      'The minor pentatonic scale infused with the flattened 5th (blue note)'
    ],
    commonInstruments: [
      { name: 'Electric Guitar with Slide', role: 'Vocal-like sliding bends and stinging single-string leads.', image: 'https://images.unsplash.com/photo-1514525253161-7a46d19cd819?auto=format&fit=crop&w=400&q=80' },
      { name: 'Harmonica (Blues Harp)', role: 'Cross-harp draw bends and rhythmic train-whistle chugging.', image: 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?auto=format&fit=crop&w=400&q=80' }
    ],
    featuredArtists: [
      { name: 'B.B. King', era: '1925–2015', description: 'The King of the Blues, renowned for his expressive vibrato on his guitar Lucille.', image: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=400&q=80' },
      { name: 'Muddy Waters', era: '1913–1983', description: 'Pioneered the electrified Chicago blues sound that inspired the British Rock invasion.', image: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=400&q=80' }
    ],
    tracks: [
      {
        id: 'track-blues-1',
        title: 'Delta Crossroads Shuffle',
        artist: 'Muddy Creek Project',
        genre: 'Blues',
        duration: 30,
        audioPreset: 'blues_riff',
        coverImage: 'https://images.unsplash.com/photo-1514525253161-7a46d19cd819?auto=format&fit=crop&w=400&q=80',
        description: 'Authentic 12-bar shuffle pattern with minor pentatonic blue note inflections.',
        instrumentsUsed: ['Overdriven Tube Guitar', 'Blues Harp', 'Bass'],
        bpm: 108,
        license: 'Original Artora Composition'
      }
    ],
    learningResources: [
      { title: 'The 12-Bar Blues Progression Demystified', type: 'Interactive Chart', duration: '12 mins' },
      { title: 'How to Bend Notes & Find the Blue Note', type: 'Technique Video', duration: '16 mins' }
    ],
    relatedGenres: ['Rock', 'Jazz', 'Soul', 'Folk']
  },
  electronic: {
    id: 'electronic',
    name: 'Electronic',
    tagline: 'Synthesizers, modular loops, and hypnotic soundscapes.',
    coverImage: 'https://images.unsplash.com/photo-1598488035139-bdbb2231ce04?auto=format&fit=crop&w=1000&q=80',
    history: 'From early Theremin and Moog synthesizer pioneers to Detroit Techno, Chicago House, and modern Ambient sound design, electronic music transformed sound synthesis into an infinite canvas.',
    characteristics: [
      'Oscillator waveforms (sawtooth, square, sine, triangle)',
      'Low-pass filter sweeps, envelopes (ADSR), and LFO modulations',
      'Sequenced drum machines (808/909 kicks and claps)',
      'Atmospheric delay and reverb spatial synthesis'
    ],
    commonInstruments: [
      { name: 'Analog Synthesizer', role: 'Oscillator sound generation, resonance filters, and arpeggiation.', image: 'https://images.unsplash.com/photo-1598488035139-bdbb2231ce04?auto=format&fit=crop&w=400&q=80' },
      { name: 'Drum Machine / Sampler', role: 'Grid-based rhythm sequencing and dynamic groove velocity.', image: 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?auto=format&fit=crop&w=400&q=80' }
    ],
    featuredArtists: [
      { name: 'Kraftwerk', era: '1970–Present', description: 'German pioneers who established the blueprint of electronic pop and techno.', image: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=400&q=80' },
      { name: 'Daft Punk', era: '1993–2021', description: 'French electronic duo who defined modern French Touch, house, and synth production.', image: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=400&q=80' }
    ],
    tracks: [
      {
        id: 'track-elec-1',
        title: 'Neon Horizon Retrowave',
        artist: 'CyberSynthesis',
        genre: 'Electronic',
        duration: 30,
        audioPreset: 'synthwave',
        coverImage: 'https://images.unsplash.com/photo-1598488035139-bdbb2231ce04?auto=format&fit=crop&w=400&q=80',
        description: 'Driving 80s analog saw bassline paired with glowing synth pads.',
        instrumentsUsed: ['Analog Saw Synth', '808 Kick & Snare', 'Chorus FX'],
        bpm: 120,
        license: 'Royalty-Free'
      }
    ],
    learningResources: [
      { title: 'Subtractive Synthesis: Oscillators & Filters', type: 'Interactive Lab', duration: '20 mins' }
    ],
    relatedGenres: ['Synthwave', 'Ambient', 'Hip-Hop', 'House']
  },
  folk: {
    id: 'folk',
    name: 'Folk',
    tagline: 'Acoustic storytelling, wooden instruments, and cultural heritage.',
    coverImage: 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?auto=format&fit=crop&w=1000&q=80',
    history: 'Transmitted orally through generations, folk music preserves the history, myths, dances, and intimate personal narratives of communities across every continent.',
    characteristics: [
      'Acoustic string instruments (acoustic guitar, banjo, mandolin, fiddle)',
      'Narrative ballad songwriting and poetic lyrical imagery',
      'Simple open chord voicings (G, C, D, Em) and fingerpicking patterns',
      'Close modal vocal harmonies'
    ],
    commonInstruments: [
      { name: 'Acoustic Steel-String Guitar', role: 'Fingerpicked patterns and resonant dreadnought strumming.', image: 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?auto=format&fit=crop&w=400&q=80' },
      { name: 'Fiddle & Mandolin', role: 'Fast melodic reels, rhythmic chops, and folk ornaments.', image: 'https://images.unsplash.com/photo-1612225330812-01a9c6b355ec?auto=format&fit=crop&w=400&q=80' }
    ],
    featuredArtists: [
      { name: 'Bob Dylan', era: '1960s–Present', description: 'Nobel Prize laureate who redefined poetic lyrics in modern folk and rock.', image: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=400&q=80' },
      { name: 'Joan Baez', era: '1960s–Present', description: 'Legendary folk singer known for clear soprano vocals and social advocacy.', image: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=400&q=80' }
    ],
    tracks: [
      {
        id: 'track-folk-1',
        title: 'Pine Needle Mountain Reel',
        artist: 'Greenwood Duo',
        genre: 'Folk',
        duration: 32,
        audioPreset: 'folk_acoustic',
        coverImage: 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?auto=format&fit=crop&w=400&q=80',
        description: 'Warm acoustic fingerpicking melody celebrating mountain mornings.',
        instrumentsUsed: ['Dreadnought Acoustic', 'Mandolin', 'Tambourine'],
        bpm: 96,
        license: 'Royalty-Free'
      }
    ],
    learningResources: [
      { title: 'Travis Picking: Thumb-Independent Technique', type: 'Guitar Exercise', duration: '15 mins' }
    ],
    relatedGenres: ['Country', 'Bluegrass', 'Indie', 'Traditional']
  }
};

export const MUSIC_ALL_GENRE_NAMES = [
  'Classical',
  'Folk',
  'Rock',
  'Jazz',
  'Pop',
  'Blues',
  'Hip-Hop',
  'Electronic',
  'Indie',
  'Country',
  'Traditional',
  'Regional',
  'Film Music',
  'World Music'
];
