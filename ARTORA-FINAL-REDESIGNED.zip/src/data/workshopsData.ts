import { Workshop } from '../types';

export const WORKSHOPS_DATA: Workshop[] = [
  {
    id: 'ws-botanical-watercolor-mastery',
    title: 'Botanical Watercolor & Wet-on-Wet Masterclass',
    instructor: {
      name: 'Claire Beauchamp',
      title: 'Botanical Illustrator & Royal Society Fellow',
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&q=80'
    },
    categoryId: 'painting',
    artForm: 'Watercolor',
    date: 'Saturday, Oct 14, 2026',
    time: '10:00 AM - 1:00 PM EST',
    duration: '3 hours',
    difficulty: 'Beginner',
    locationType: 'Online',
    locationName: 'Live Interactive Studio (Zoom HD)',
    city: 'Global Stream',
    price: '$45.00',
    image: 'https://images.unsplash.com/photo-1579783900882-c0d3dad7b119?auto=format&fit=crop&w=800&q=80',
    description: 'Join Claire Beauchamp for a hands-on live session exploring the delicate art of translucent botanical glazes, color mixing for natural leaves, and stem anatomy.',
    agenda: [
      'Welcome & Paper Preparation (15 mins)',
      'Mixing Organic Greens & Warm Floral Glazes (30 mins)',
      'Step-by-Step Orchid Petal Study (60 mins)',
      'Vein Details & Masking Techniques (45 mins)',
      'Live Q&A & Student Feedback Reviews (30 mins)'
    ],
    materialsProvided: ['Digital botanical outline template PDF', 'High-res reference photo pack', 'Color mixing cheat-sheet'],
    spotsRemaining: 6
  },
  {
    id: 'ws-wheel-throwing-pottery',
    title: 'Wheel Throwing & Japanese Trimming Workshop',
    instructor: {
      name: 'Kenji Takahashi',
      title: 'Master Potter & Ceramicist',
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=200&q=80'
    },
    categoryId: 'pottery',
    artForm: 'Pottery',
    date: 'Sunday, Oct 22, 2026',
    time: '2:00 PM - 5:30 PM PDT',
    duration: '3.5 hours',
    difficulty: 'Intermediate',
    locationType: 'Local Studio',
    locationName: 'Earth & Kiln Studio, 442 Mission St',
    city: 'San Francisco, CA',
    price: '$85.00',
    image: 'https://images.unsplash.com/photo-1565193566173-7a0ee3dbe261?auto=format&fit=crop&w=800&q=80',
    description: 'A physical studio intensive dedicated to mastering 2lb cylinder centering, pulling uniform thin walls, and traditional foot trimming on the wheel.',
    agenda: [
      'Clay wedging & ergonomic wheel posture (20 mins)',
      'Centering & Opening with minimum arm fatigue (40 mins)',
      'Throwing 3 uniform match cups (60 mins)',
      'Leather-hard trimming & carving chattering marks (60 mins)',
      'Glaze selection & bisque firing preparation (30 mins)'
    ],
    materialsProvided: ['10 lbs of premium stoneware clay', 'Studio wheel usage', 'Two fired & glazed finished pieces shipped to your home'],
    spotsRemaining: 3
  },
  {
    id: 'ws-street-photography-light',
    title: 'The Decisive Moment: Street Photography Walk',
    instructor: {
      name: 'Marcus Sterling',
      title: 'Documentary Photojournalist',
      avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=200&q=80'
    },
    categoryId: 'photography',
    artForm: 'Photography',
    date: 'Saturday, Nov 04, 2026',
    time: '3:30 PM - 6:30 PM GMT',
    duration: '3 hours',
    difficulty: 'Beginner',
    locationType: 'Local Studio',
    locationName: 'SoHo & Covent Garden Heritage District',
    city: 'London, UK',
    price: '£55.00',
    image: 'https://images.unsplash.com/photo-1516035069371-29a1b244cc32?auto=format&fit=crop&w=800&q=80',
    description: 'Walk through historic streets discovering high-contrast golden light, candid reflections, and unscripted human storytelling.',
    agenda: [
      'Camera pre-focus & zone focusing setup (20 mins)',
      'Reading light pockets in architecture (40 mins)',
      'Guided street shooting circuit (90 mins)',
      'Coffee shop photo critique & selection review (30 mins)'
    ],
    materialsProvided: ['Street photography composition card', 'Lightroom Street preset pack'],
    spotsRemaining: 4
  },
  {
    id: 'ws-amigurumi-crochet-plush',
    title: 'Beginner Amigurumi & Seamless Fiber Sculpture',
    instructor: {
      name: 'Mika Tanaka',
      title: 'Fiber Artist & Author',
      avatar: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?auto=format&fit=crop&w=200&q=80'
    },
    categoryId: 'crochet',
    artForm: 'Crochet',
    date: 'Wednesday, Nov 11, 2026',
    time: '6:00 PM - 8:30 PM EST',
    duration: '2.5 hours',
    difficulty: 'Beginner',
    locationType: 'Online',
    locationName: 'Virtual Workshop Room',
    city: 'Global Stream',
    price: 'Free / Community Sponsored',
    image: 'https://images.unsplash.com/photo-1584992236310-6edddc08acff?auto=format&fit=crop&w=800&q=80',
    description: 'Master the magic ring, invisible decrease, and neat seam sewing while creating an adorable handmade character from start to finish.',
    agenda: [
      'Yarn tension & holding ergonomics (15 mins)',
      'Magic circle live walkthrough (30 mins)',
      'Body shaping & stitch counting (45 mins)',
      'Attaching safety eyes & face embroidery (30 mins)',
      'Show & tell celebration (30 mins)'
    ],
    materialsProvided: ['Printable pattern booklet', 'Stitch counting sheet', 'Community Discord access'],
    spotsRemaining: 18
  }
];
