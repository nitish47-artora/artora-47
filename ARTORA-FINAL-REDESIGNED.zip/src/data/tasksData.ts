import { PracticeTask } from '../types';

export const PRACTICE_TASKS_DATA: PracticeTask[] = [
  {
    id: 'task-1-basic-shapes',
    categoryId: 'painting',
    taskNumber: 1,
    title: 'Draw a Simple Object Using Basic Shapes',
    level: 'Beginner',
    estimatedMinutes: 20,
    materials: ['Sketchbook or paper', '2B/4B Graphite pencil or brush pen', 'Kneaded eraser'],
    referenceImage: 'https://images.unsplash.com/photo-1544717305-2782549b5136?auto=format&fit=crop&w=600&q=80',
    instructions: [
      'Choose an everyday object nearby (e.g. an apple, a ceramic mug, or a water flask).',
      'Deconstruct the object into primary 2D geometric shapes (circle, rectangle, triangle, or ellipse).',
      'Draw the outer envelope lightly before committing to final perimeter lines.',
      'Refine the contours where curves join and erase underlying construction guidelines.'
    ],
    criteria: [
      'Clear silhouette and accurate proportions',
      'Balanced placement on the page',
      'Visible foundational structure without excessive erasing marks'
    ],
    mentorTip: 'Do not worry about shading yet; prioritize looking at the subject 70% of the time and your paper 30% of the time.'
  },
  {
    id: 'task-2-light-shadow',
    categoryId: 'painting',
    taskNumber: 2,
    title: 'Create a Light and Shadow Value Study',
    level: 'Intermediate',
    estimatedMinutes: 35,
    materials: ['Medium of your choice (Pencil, Charcoal, Watercolor or Acrylic)', 'Smooth paper or canvas panel', 'Single directional lamp'],
    referenceImage: 'https://images.unsplash.com/photo-1579783902614-a3fb3927b675?auto=format&fit=crop&w=600&q=80',
    instructions: [
      'Place an egg, cup, or simple fruit on a plain table lit by a single desk lamp from the side.',
      'Establish a 5-step value scale from pure paper white (Value 1) to deepest shadow (Value 5).',
      'Identify and shade: (A) Highlight, (B) Midtone, (C) Core Shadow, (D) Reflected Light, and (E) Cast Shadow.',
      'Soften the form shadow transition while keeping the cast shadow edge crisp near the base.'
    ],
    criteria: [
      'Distinct separation between light family and shadow family',
      'Preservation of reflected bounce light in the shadowed underside',
      'Consistent single-source illumination'
    ],
    mentorTip: 'Squinting your eyes turns your visual field into simplified black-and-white shapes, making value differences much easier to judge.'
  },
  {
    id: 'task-3-simple-landscape',
    categoryId: 'painting',
    taskNumber: 3,
    title: 'Paint a Simple Atmospheric Landscape',
    level: 'Advanced',
    estimatedMinutes: 45,
    materials: ['Watercolor, Gouache or Acrylics', 'Cold-press paper or 8x10 canvas', 'Flat and round brushes', 'Water jar & palette'],
    referenceImage: 'https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=600&q=80',
    instructions: [
      'Block out a three-tier depth composition: Sky/Background (Lightest & coolest), Midground hills (Medium tone), and Foreground shore/trees (Darkest & warmest).',
      'Paint the sky wash smoothly and allow it to dry.',
      'Layer the midground silhouettes with soft atmospheric contrast.',
      'Add foreground focal elements with sharp edges and rich pigment density.'
    ],
    criteria: [
      'Clear sense of atmospheric perspective (distance gets lighter/hazier)',
      'Harmonious color temperature balance',
      'Compelling focal point using the rule of thirds'
    ],
    mentorTip: 'Warm colors advance toward the viewer while cool blues and greys recede into the distance.'
  },
  {
    id: 'task-4-custom-composition',
    categoryId: 'painting',
    taskNumber: 4,
    title: 'Create Your Own Original Composition',
    level: 'Portfolio Ready',
    estimatedMinutes: 60,
    materials: ['Your favorite medium', 'Quality heavyweight canvas or archival paper', 'Reference photo collage or live setup'],
    referenceImage: 'https://images.unsplash.com/photo-1541701494587-cb58502866ab?auto=format&fit=crop&w=600&q=80',
    instructions: [
      'Draft 3 small thumbnail sketches (2x3 inches) testing different focal point placements and lighting ideas.',
      'Select your strongest composition and transfer the structure to your final surface.',
      'Execute the artwork with deliberate color hierarchy and expressive brush/line work.',
      'Review the final balance and sign your piece with pride!'
    ],
    criteria: [
      'Original creative voice and storytelling',
      'Demonstration of proportion, value mastery, and confident mark-making',
      'Exhibition-ready presentation and clarity'
    ],
    mentorTip: 'Take a step 6 feet back from your canvas every 15 minutes to evaluate the overall visual impact as a whole.'
  }
];
