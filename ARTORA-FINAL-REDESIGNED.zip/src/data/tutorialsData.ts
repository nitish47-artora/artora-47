import { Tutorial } from '../types';

export const TUTORIALS_DATA: Tutorial[] = [
  {
    id: 'tut-watercolor-landscape',
    categoryId: 'painting',
    title: 'Watercolor Misty Mountain Landscape',
    subtitle: 'Master wet-on-wet sky washes, layered mountain ridges, and delicate pine tree silhouettes.',
    coverImage: 'https://images.unsplash.com/photo-1579783900882-c0d3dad7b119?auto=format&fit=crop&w=800&q=80',
    difficulty: 'Beginner',
    durationMinutes: 25,
    totalSteps: 8,
    rating: 4.9,
    tags: ['Watercolor', 'Landscape', 'Wet-on-Wet', 'Atmosphere'],
    creator: {
      name: 'Elena Rostova',
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&q=80',
      role: 'Master Watercolorist'
    },
    steps: [
      {
        stepNumber: 1,
        title: 'Paper Preparation & Clean Masking',
        image: 'https://images.unsplash.com/photo-1579783902614-a3fb3927b675?auto=format&fit=crop&w=800&q=80',
        explanation: 'Tape your 300gsm cold-press cotton paper securely to your drawing board using acid-free artist tape. Ensure 1/2 inch borders for a crisp gallery finish.',
        materials: ['140lb Cold-press cotton paper', 'Acid-free artist tape', 'Waterproof backing board'],
        proTip: 'Press tape firmly along inner edges using your thumbnail to prevent pigment bleeding.'
      },
      {
        stepNumber: 2,
        title: 'Golden Dawn Wet-on-Wet Sky Wash',
        image: 'https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=800&q=80',
        explanation: 'Pre-wet the top half of the sheet with clean water using a 2-inch flat hake brush. Drop in diluted Raw Sienna near the horizon and Ultramarine Blue at the top.',
        materials: ['Raw Sienna watercolor', 'Ultramarine Blue', '2-inch Flat Hake Brush', 'Clean water jar'],
        proTip: 'Tilt your board at a 20-degree angle so the two pigments gently blend into each other without pooling.'
      },
      {
        stepNumber: 3,
        title: 'Soft Distant Mountain Ridge (Value Level 1)',
        image: 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?auto=format&fit=crop&w=800&q=80',
        explanation: 'While the sky is semi-damp, mix a very pale Cobalt Blue wash with a touch of Burnt Umber. Paint the faint silhouette of distant peaks.',
        materials: ['Cobalt Blue', 'Burnt Umber', '#10 Round Squirrel Mop'],
        proTip: 'Soft edges create atmospheric haze. Feather the lower edge of the ridge with a damp clean brush.'
      },
      {
        stepNumber: 4,
        title: 'Mid-ground Mountain Range (Value Level 2)',
        image: 'https://images.unsplash.com/photo-1579783900882-c0d3dad7b119?auto=format&fit=crop&w=800&q=80',
        explanation: 'Allow layer 3 to dry completely. Mix a medium-tone Indigo and Prussian Blue. Paint jagged, overlapping ridge contours across the mid-ground.',
        materials: ['Indigo Watercolor', 'Prussian Blue', '#8 Round Kolinsky Brush'],
        proTip: 'Leave tiny unpainted paper breaks along sharp ridge crags to simulate glistening morning snow patches.'
      },
      {
        stepNumber: 5,
        title: 'Foreground Lake & Reflection Wash',
        image: 'https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=800&q=80',
        explanation: 'Paint horizontal streaks of Indigo mixed with Viridian across the lake surface, leaving thin gaps of untouched paper for water glimmers.',
        materials: ['Viridian Green', 'Indigo', '1/2-inch Dagger Striper Brush'],
        proTip: 'Keep brush strokes strictly horizontal so the water plane lies flat to the eye.'
      },
      {
        stepNumber: 6,
        title: 'Foreground Pine Forest Silhouettes',
        image: 'https://images.unsplash.com/photo-1544717305-2782549b5136?auto=format&fit=crop&w=800&q=80',
        explanation: 'Using rich, creamy dark paint (Payne’s Grey and Sap Green with minimal water), paint varied pine trees on the front shore.',
        materials: ['Payne’s Grey', 'Sap Green', '#2 Rigger / Script Brush'],
        proTip: 'Vary the height and spacing of trees in odd groups (3, 5, 7) for an organic natural composition.'
      },
      {
        stepNumber: 7,
        title: 'Misty Shoreline Splatter & Fog Details',
        image: 'https://images.unsplash.com/photo-1582201942988-13e60e4556ee?auto=format&fit=crop&w=800&q=80',
        explanation: 'Using a spray mister filled with clean water, lightly mist the base of the pine trees to create realistic rising morning fog.',
        materials: ['Fine spray mister', 'Dry paper towel for dabbing'],
        proTip: 'Dab gently with a crumpled tissue to lift pigment where you want bright luminous fog pockets.'
      },
      {
        stepNumber: 8,
        title: 'Final Highlights & Tape Peeling',
        image: 'https://images.unsplash.com/photo-1541701494587-cb58502866ab?auto=format&fit=crop&w=800&q=80',
        explanation: 'Add tiny opaque white gouache stars or water ripples. Once bone dry, peel tape away from paper at a 45-degree angle.',
        materials: ['Permanent White Gouache', '#0 Detail Brush', 'Hairdryer (optional)'],
        proTip: 'Warm the tape gently with a hairdryer before peeling to avoid tearing paper fibers.'
      }
    ]
  },
  {
    id: 'tut-crochet-amigurumi-whale',
    categoryId: 'crochet',
    title: 'Adorable Pocket Amigurumi Whale',
    subtitle: 'Learn the magic ring, continuous spiral rounds, invisible decreases, and safety eye placement.',
    coverImage: 'https://images.unsplash.com/photo-1584992236310-6edddc08acff?auto=format&fit=crop&w=800&q=80',
    difficulty: 'Beginner',
    durationMinutes: 35,
    totalSteps: 6,
    rating: 4.95,
    tags: ['Crochet', 'Amigurumi', 'Yarn', 'Beginner Friendly'],
    creator: {
      name: 'Mika Tanaka',
      avatar: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?auto=format&fit=crop&w=200&q=80',
      role: 'Fiber Artist & Pattern Designer'
    },
    steps: [
      {
        stepNumber: 1,
        title: 'Magic Ring & Round 1 Foundation',
        image: 'https://images.unsplash.com/photo-1584992236310-6edddc08acff?auto=format&fit=crop&w=800&q=80',
        explanation: 'Make a magic circle and work 6 single crochets (sc) into the ring. Pull yarn tail to tighten center hole completely. Place stitch marker.',
        materials: ['Worsted weight blue cotton yarn', '3.5mm Ergonomic hook', 'Stitch marker'],
        proTip: 'Never count your slip knot as a stitch; keep tension even and relaxed.'
      },
      {
        stepNumber: 2,
        title: 'Even Increases for Whale Dome (Rounds 2-5)',
        image: 'https://images.unsplash.com/photo-1606760227091-3dd870d97f1d?auto=format&fit=crop&w=800&q=80',
        explanation: 'Rnd 2: 2 sc in each st (12). Rnd 3: [1 sc, inc] x6 (18). Rnd 4: [2 sc, inc] x6 (24). Rnd 5: [3 sc, inc] x6 (30).',
        materials: ['3.5mm hook', 'Contrasting locking stitch marker'],
        proTip: 'Move your marker to the last stitch of every round to avoid losing count.'
      },
      {
        stepNumber: 3,
        title: 'Building Body Walls & Tail Fins',
        image: 'https://images.unsplash.com/photo-1584992236310-6edddc08acff?auto=format&fit=crop&w=800&q=80',
        explanation: 'Work rounds 6-9 even (30 sc each). On round 10, crochet 2 tail fins using [ch 3, dc 2, sl st] directly into the side.',
        materials: ['Blue cotton yarn', 'Yarn snips'],
        proTip: 'Work in continuous spirals without joining rounds to prevent a visible seam line.'
      },
      {
        stepNumber: 4,
        title: 'Safety Eye Placement & Embroidered Smile',
        image: 'https://images.unsplash.com/photo-1544816155-12df9643f363?auto=format&fit=crop&w=800&q=80',
        explanation: 'Insert 8mm black safety eyes between rounds 7 and 8, spaced 6 stitches apart. Snap backing washers on firmly. Embroider tiny curved smile.',
        materials: ['Pair of 8mm Safety Eyes with washers', 'Black embroidery floss', 'Tapestry needle'],
        proTip: 'Ensure safety washer clicks twice to permanently lock inside the fabric.'
      },
      {
        stepNumber: 5,
        title: 'White Belly Color Change & Invisible Decreases',
        image: 'https://images.unsplash.com/photo-1606760227091-3dd870d97f1d?auto=format&fit=crop&w=800&q=80',
        explanation: 'Switch to white yarn on the last yarn-over. Work [3 sc, invdec] around. Stuff firmly with hypoallergenic polyfill before closing.',
        materials: ['White worsted cotton yarn', 'Premium polyfill fiber', 'Bamboo stuffing stick'],
        proTip: 'Use front loops only for decreases so no visible knots or holes appear on the belly.'
      },
      {
        stepNumber: 6,
        title: 'Final Weave & Water Spout Accent',
        image: 'https://images.unsplash.com/photo-1584992236310-6edddc08acff?auto=format&fit=crop&w=800&q=80',
        explanation: 'Decrease until 6 stitches remain. Fasten off with 6-inch tail. Weave needle through front loops and pull tight to seal. Add blue yarn water spout!',
        materials: ['Yarn needle', 'Light blue accent thread'],
        proTip: 'Tie off inside the plush body so tails never unravel during handling.'
      }
    ]
  },
  {
    id: 'tut-photography-portrait-lighting',
    categoryId: 'photography',
    title: 'Cinematic Natural Light Portraiture',
    subtitle: 'Harness window light, directional shadows, Rembrandt triangles, and shallow depth of field.',
    coverImage: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=800&q=80',
    difficulty: 'Intermediate',
    durationMinutes: 30,
    totalSteps: 5,
    rating: 4.88,
    tags: ['Photography', 'Portraits', 'Lighting', 'Composition'],
    creator: {
      name: 'Julian Vance',
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=200&q=80',
      role: 'Commercial Fashion Photographer'
    },
    steps: [
      {
        stepNumber: 1,
        title: 'Subject Positioning & 45-Degree Light Angle',
        image: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=800&q=80',
        explanation: 'Position your subject 4 to 6 feet away from a large north-facing window at a 45-degree angle. This produces soft directional modeling across the facial contours.',
        materials: ['Camera with 50mm or 85mm f/1.8 lens', 'Large window / diffuser curtain'],
        proTip: 'North-facing windows provide steady, soft diffused light throughout the entire day without harsh direct sun rays.'
      },
      {
        stepNumber: 2,
        title: 'Identifying the Rembrandt Triangle',
        image: 'https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=800&q=80',
        explanation: 'Ask your subject to turn their chin slightly away from the window until an illuminated triangular patch of light appears on the shadow cheek beneath their eye.',
        materials: ['Model / Subject', 'Stool with swivel adjustment'],
        proTip: 'The triangle should not be wider than the eye or lower than the tip of the nose.'
      },
      {
        stepNumber: 3,
        title: 'Camera Exposure Setup for Crisp Eyes',
        image: 'https://images.unsplash.com/photo-1516035069371-29a1b244cc32?auto=format&fit=crop&w=800&q=80',
        explanation: 'Set aperture to f/1.8–f/2.2 for creamy bokeh. Keep shutter speed above 1/200s to avoid camera shake. Use single-point Eye-AF locked on the nearest eye.',
        materials: ['Full frame / APS-C camera', 'Eye Autofocus mode enabled'],
        proTip: 'In close-up portraits, always prioritize pin-sharp focus on the eye closest to the camera lens.'
      },
      {
        stepNumber: 4,
        title: 'Controlling Shadows with a 5-in-1 Reflector',
        image: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=800&q=80',
        explanation: 'Hold the silver or white side of a circular reflector opposite the window to bounce subtle fill light into deep jaw and neck shadows.',
        materials: ['32" 5-in-1 Collapsible Reflector', 'Reflector stand or assistant'],
        proTip: 'Use the white side for soft natural fill; use the black side (negative fill) when you want higher contrast drama.'
      },
      {
        stepNumber: 5,
        title: 'Subtle Color Grading & Contrast Curve',
        image: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=800&q=80',
        explanation: 'In post-processing, create an S-curve for punchy contrast, warm up midtone skin tones slightly, and add gentle clarity to the iris highlights.',
        materials: ['Lightroom / Capture One RAW editor'],
        proTip: 'Avoid over-smoothing skin textures; preserve natural pore micro-detail to keep the portrait authentic and professional.'
      }
    ]
  },
  {
    id: 'tut-drawing-facial-proportions',
    categoryId: 'drawing',
    title: 'Mastering Classical Loomis Facial Proportions',
    subtitle: 'Construct realistic heads from any angle using spheres, crosshairs, and the Andrew Loomis method.',
    coverImage: 'https://images.unsplash.com/photo-1544717305-2782549b5136?auto=format&fit=crop&w=800&q=80',
    difficulty: 'Beginner',
    durationMinutes: 20,
    totalSteps: 5,
    rating: 4.92,
    tags: ['Drawing', 'Anatomy', 'Portrait', 'Loomis Method'],
    creator: {
      name: 'Arthur Sterling',
      avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=200&q=80',
      role: 'Classical Atelier Instructor'
    },
    steps: [
      {
        stepNumber: 1,
        title: 'The Cranial Sphere & Side Slices',
        image: 'https://images.unsplash.com/photo-1544717305-2782549b5136?auto=format&fit=crop&w=800&q=80',
        explanation: 'Draw a clean circle representing the cranial mass. Slice off the sides with flat ellipses to match the natural flattened temples of the skull.',
        materials: ['2H Drawing Pencil', 'Strathmore Sketch Pad', 'Compass or freehand'],
        proTip: 'Keep initial construction lines feather-light so they erase or blend into later shading.'
      },
      {
        stepNumber: 2,
        title: 'The Brow Line & Center Facial Cross',
        image: 'https://images.unsplash.com/photo-1513364776144-60967b0f800f?auto=format&fit=crop&w=800&q=80',
        explanation: 'Wrap a curved brow line equator around the sphere. Drop a perpendicular facial centerline down across the center of the face.',
        materials: ['HB Pencil', 'Kneaded eraser'],
        proTip: 'The tilt of this crosshair dictates the exact upward or downward gaze angle of the head.'
      },
      {
        stepNumber: 3,
        title: 'Rule of Thirds: Hairline, Brow, Nose & Chin',
        image: 'https://images.unsplash.com/photo-1580196969807-cc6de06c05be?auto=format&fit=crop&w=800&q=80',
        explanation: 'Measure three equal distances: from Hairline to Brow line, Brow line to Nose base, and Nose base to bottom of Chin.',
        materials: ['HB Pencil', 'Ruler / Divider'],
        proTip: 'The distance between the eyes is always equal to the width of one single eye.'
      },
      {
        stepNumber: 4,
        title: 'Placement of Facial Features & Ears',
        image: 'https://images.unsplash.com/photo-1544717305-2782549b5136?auto=format&fit=crop&w=800&q=80',
        explanation: 'The top of the ears aligns with the brow line; the bottom of the ears aligns with the base of the nose. Sketch socket planes and lips.',
        materials: ['2B Pencil', 'Blending stump'],
        proTip: 'Corners of the mouth align vertically with the pupils when the eyes look straight ahead.'
      },
      {
        stepNumber: 5,
        title: 'Tonal Mass Shading & Core Shadow Planes',
        image: 'https://images.unsplash.com/photo-1579783902614-a3fb3927b675?auto=format&fit=crop&w=800&q=80',
        explanation: 'Establish a unified light source. Group all shadow planes under brow, nose, lower lip, and jaw with smooth diagonal 4B pencil hatching.',
        materials: ['4B & 6B Graphite Pencils', 'Mono Zero Precision Eraser'],
        proTip: 'Squint at your reference to see values as big simple shapes rather than getting lost in eyelash details.'
      }
    ]
  },
  {
    id: 'tut-sculpture-clay-bust',
    categoryId: 'sculpture',
    title: 'Classical Clay Bust Armature & Modeling',
    subtitle: 'Construct a sturdy aluminum wire armature and block in primary facial anatomical planes with monster clay.',
    coverImage: 'https://images.unsplash.com/photo-1569172122301-bc500f309134?auto=format&fit=crop&w=800&q=80',
    difficulty: 'Intermediate',
    durationMinutes: 45,
    totalSteps: 5,
    rating: 4.96,
    tags: ['Sculpture', 'Clay', 'Armature', 'Anatomy'],
    creator: {
      name: 'Matteo Moretti',
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=200&q=80',
      role: 'Master Sculptor & Foundry Artisan'
    },
    steps: [
      {
        stepNumber: 1,
        title: 'Building the Wire & Pipe Armature',
        image: 'https://images.unsplash.com/photo-1569172122301-bc500f309134?auto=format&fit=crop&w=800&q=80',
        explanation: 'Mount an iron pipe to a heavy wooden base board. Form a rigid aluminum wire loop for the skull and wrap tie wire to anchor the core bulk.',
        materials: ['Aluminum armature wire (1/8")', 'Wooden mounting base', 'Tie wire', 'Pliers'],
        proTip: 'Tightly wrap aluminum wire with thinner floral wire so the soft clay does not slide along smooth metal rods.'
      },
      {
        stepNumber: 2,
        title: 'Bulk Foil Packing & Primary Clay Mass',
        image: 'https://images.unsplash.com/photo-1544717305-2782549b5136?auto=format&fit=crop&w=800&q=80',
        explanation: 'Pack heavy-duty aluminum foil tightly around the wire core to save weight and clay. Warm Monster Clay and apply 1/2-inch uniform sheets.',
        materials: ['Heavy aluminum foil', 'Medium Monster Clay / Chavant', 'Heat gun or crockpot'],
        proTip: 'Warm clay between 110°F–120°F to make it as malleable as butter without liquefying.'
      },
      {
        stepNumber: 3,
        title: 'Blocking Facial Planes: Brow, Cheeks & Jaw',
        image: 'https://images.unsplash.com/photo-1513364776144-60967b0f800f?auto=format&fit=crop&w=800&q=80',
        explanation: 'Using wooden rake tools, block the zygomatic arches (cheekbones), eye orbits, and mandible jawline. Continuously rotate your sculpture on a turntable.',
        materials: ['Wooden modeling tools', 'Rake tool', 'Lazy susan turntable'],
        proTip: 'Always sculpt in 360 degrees; check silhouette profile from all cardinal angles every 2 minutes.'
      },
      {
        stepNumber: 4,
        title: 'Feature Refinement: Nose, Lips & Eye Spheres',
        image: 'https://images.unsplash.com/photo-1579783902614-a3fb3927b675?auto=format&fit=crop&w=800&q=80',
        explanation: 'Insert pre-baked polymer clay eye spheres into sockets. Wrap thin clay eyelid ribbons around the eyeballs and sculpt the nasal cartilage.',
        materials: ['Wire loop tools', 'Smooth ball stylus', 'Pre-made acrylic or clay eye beads'],
        proTip: 'The upper eyelid covers a small sliver of the top iris; the lower eyelid barely touches the bottom edge.'
      },
      {
        stepNumber: 5,
        title: 'Surface Texturing & Isopropyl Smoothing',
        image: 'https://images.unsplash.com/photo-1569172122301-bc500f309134?auto=format&fit=crop&w=800&q=80',
        explanation: 'Press stippling sponges for skin pore realism. Lightly brush 99% isopropyl alcohol or mineral oil to melt away unwanted tool scratch marks.',
        materials: ['99% Isopropyl alcohol', 'Soft flat hog bristle brush', 'Texturing sponge'],
        proTip: 'Use minimal solvent; excessive alcohol can soften the wax too deeply and erase crisp character wrinkles.'
      }
    ]
  },
  {
    id: 'tut-digital-cyberpunk-concept',
    categoryId: 'digital',
    title: 'Neon Cyberpunk Environment Concept Art',
    subtitle: 'Learn photobashing, atmospheric perspective, custom brush lighting, and cinematic neon glow.',
    coverImage: 'https://images.unsplash.com/photo-1578632767115-351597cf2477?auto=format&fit=crop&w=800&q=80',
    difficulty: 'Intermediate',
    durationMinutes: 40,
    totalSteps: 5,
    rating: 4.94,
    tags: ['Digital Art', 'Concept Art', 'Photoshop', 'Procreate', 'Lighting'],
    creator: {
      name: 'Kaito Shiro',
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&q=80',
      role: 'Senior Game Concept Artist'
    },
    steps: [
      {
        stepNumber: 1,
        title: 'Composition Sketch & 3-Point Perspective',
        image: 'https://images.unsplash.com/photo-1578632767115-351597cf2477?auto=format&fit=crop&w=800&q=80',
        explanation: 'Set up a dramatic low-angle 3-point perspective grid. Sketch towering skyscraper silhouettes receding into the rainy night sky.',
        materials: ['Graphics Tablet / iPad Pro', 'Perspective Guide Tool', 'Standard Hard Round Brush'],
        proTip: 'Place your horizon line in the bottom third of the canvas to give the city an imposing, colossal scale.'
      },
      {
        stepNumber: 2,
        title: 'Value Grouping & Deep Atmospheric Fog',
        image: 'https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=800&q=80',
        explanation: 'Establish values from dark foreground (Value 90%) to pale blue hazy background (Value 20%). Separate street levels onto discrete layers.',
        materials: ['Soft Airbrush', 'Lasso selection tool', 'Layer Masks'],
        proTip: 'Contrast decreases with distance: faraway buildings should have lower contrast and closer color values to the sky.'
      },
      {
        stepNumber: 3,
        title: 'Architectural Photobashing & Texturing',
        image: 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?auto=format&fit=crop&w=800&q=80',
        explanation: 'Warp architectural textures, air conditioning units, and cables along perspective planes using distort and puppet warp modes.',
        materials: ['Hi-res industrial photo pack', 'Transform/Distort tool', 'Match Color adjustment'],
        proTip: 'Set texture blend modes to Multiply or Overlay and paint out hard photo borders with a textured grunge brush.'
      },
      {
        stepNumber: 4,
        title: 'Neon Signage & Screen Glow Passes',
        image: 'https://images.unsplash.com/photo-1578632767115-351597cf2477?auto=format&fit=crop&w=800&q=80',
        explanation: 'Paint vibrant Japanese and holographic signage in saturated cyan and magenta. Duplicate the layer and apply Gaussian Blur with Color Dodge.',
        materials: ['Color Dodge blend mode', 'Gaussian Blur filter', 'Custom Kanji brush'],
        proTip: 'Color Dodge requires a dark under-layer to bloom effectively without turning pure flat white.'
      },
      {
        stepNumber: 5,
        title: 'Rain Reflections & Lens Chromatic Aberration',
        image: 'https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=800&q=80',
        explanation: 'Paint vertical light streaks on wet asphalt pavement with Motion Blur. Add subtle RGB channel shift chromatic aberration at canvas corners.',
        materials: ['Motion Blur filter', 'Noise overlay at 3%', 'Chromatic aberration pass'],
        proTip: 'Subtle 35mm film grain unifies photobashed elements and digital brushstrokes into a cohesive movie screenshot.'
      }
    ]
  },
  {
    id: 'tut-calligraphy-copperplate-script',
    categoryId: 'calligraphy',
    title: 'Flourished Copperplate Pointed Pen Script',
    subtitle: 'Master nib pressure dynamics, 55-degree slant guides, hairline upstrokes, and swelling downstrokes.',
    coverImage: 'https://images.unsplash.com/photo-1580196969807-cc6de06c05be?auto=format&fit=crop&w=800&q=80',
    difficulty: 'Beginner',
    durationMinutes: 25,
    totalSteps: 5,
    rating: 4.91,
    tags: ['Calligraphy', 'Pointed Pen', 'Lettering', 'Ink'],
    creator: {
      name: 'Aurelia Vance',
      avatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=200&q=80',
      role: 'Master Penman & Typographer'
    },
    steps: [
      {
        stepNumber: 1,
        title: 'Oblique Pen Holder & Flexible Nib Prep',
        image: 'https://images.unsplash.com/photo-1580196969807-cc6de06c05be?auto=format&fit=crop&w=800&q=80',
        explanation: 'Insert a Nikko G or Brause Steno nib into an oblique pen flange. Clean off factory oils with rubbing alcohol or toothpaste so ink flows evenly.',
        materials: ['Oblique pen holder', 'Nikko G flexible nib', 'Sumi / Walnut ink', 'Rhodia dot pad'],
        proTip: 'The brass flange should hold the nib at a 55-degree angle aligned with the natural slant lines of copperplate script.'
      },
      {
        stepNumber: 2,
        title: 'Fundamental Drill: Hairline Upstrokes',
        image: 'https://images.unsplash.com/photo-1513364776144-60967b0f800f?auto=format&fit=crop&w=800&q=80',
        explanation: 'With zero hand pressure, glide the tip of the nib diagonally upward along the 55-degree guide. Produce whispers of razor-sharp lines.',
        materials: ['55-degree ruled guideline sheet', 'Walnut crystal ink'],
        proTip: 'Relax your shoulder; write from the whole arm rather than pinching and locking your fingers.'
      },
      {
        stepNumber: 3,
        title: 'Fundamental Drill: Swelling Pressure Downstrokes',
        image: 'https://images.unsplash.com/photo-1580196969807-cc6de06c05be?auto=format&fit=crop&w=800&q=80',
        explanation: 'Apply smooth, gradual index finger pressure as you pull straight down to flex the nib tines. Release pressure right before the baseline.',
        materials: ['Nikko G nib', 'Smooth bleedproof paper'],
        proTip: 'Square off the tops and bottoms of your shaded stems with a tiny preliminary horizontal flick.'
      },
      {
        stepNumber: 4,
        title: 'The Universal Ovals & Compound Curves',
        image: 'https://images.unsplash.com/photo-1580196969807-cc6de06c05be?auto=format&fit=crop&w=800&q=80',
        explanation: 'Combine thin hairline entry, left-sided pressure swell, and feather-light exit into a continuous egg-shaped oval (the foundation of a, c, d, g, o, q).',
        materials: ['Oblique pen', 'Rhodia paper'],
        proTip: 'Keep the widest part of your oval swell exactly at the midpoint between the waistline and baseline.'
      },
      {
        stepNumber: 5,
        title: 'Capital Flourishing & Ascender Loops',
        image: 'https://images.unsplash.com/photo-1580196969807-cc6de06c05be?auto=format&fit=crop&w=800&q=80',
        explanation: 'Gracefully loop descenders on y and g below the baseline. Intersect flourish lines at 90-degree angles to avoid muddy visual tangles.',
        materials: ['Metallic gold gouache (Schmincke)', 'Dropper for mixing'],
        proTip: 'Never cross two shaded/thick strokes over each other; only cross a thick stroke with a delicate hairline.'
      }
    ]
  },
  {
    id: 'tut-ceramics-wheel-centering',
    categoryId: 'ceramics',
    title: 'Pottery Wheel Throwing: Centering & Pulling Cylinders',
    subtitle: 'Learn clay wedging, wheel speed control, coning up/down, and raising thin, balanced cylinder walls.',
    coverImage: 'https://images.unsplash.com/photo-1565193566173-7a0ee3dbe261?auto=format&fit=crop&w=800&q=80',
    difficulty: 'Beginner',
    durationMinutes: 35,
    totalSteps: 5,
    rating: 4.97,
    tags: ['Ceramics', 'Pottery', 'Clay', 'Wheel Throwing', 'Craft'],
    creator: {
      name: 'Claire Beauchamp',
      avatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=200&q=80',
      role: 'Studio Ceramicist & Wheel Instructor'
    },
    steps: [
      {
        stepNumber: 1,
        title: 'Spiral Wedging & Throwing on Wheel Head',
        image: 'https://images.unsplash.com/photo-1565193566173-7a0ee3dbe261?auto=format&fit=crop&w=800&q=80',
        explanation: 'Spiral wedge 2 lbs of stoneware clay to eliminate all air bubbles. Slam the clay ball directly into the exact center of a dry wheel bat.',
        materials: ['2 lbs B-Mix or Stoneware clay', 'Pottery wheel with foot pedal', 'Plaster wedging table'],
        proTip: 'Seal the bottom seam of the clay ball to the wheel head with damp fingers so water does not seep underneath.'
      },
      {
        stepNumber: 2,
        title: 'Centering: Coning Up & Coning Down',
        image: 'https://images.unsplash.com/photo-1565193566173-7a0ee3dbe261?auto=format&fit=crop&w=800&q=80',
        explanation: 'At high wheel speed, brace your elbows against your hips. Squeeze the clay into a tall cone, then push down with the heel of your left palm.',
        materials: ['Pottery sponge', 'Water bucket'],
        proTip: 'Lock your core and use your body weight rather than arm muscles alone to steady the clay.'
      },
      {
        stepNumber: 3,
        title: 'Opening the Floor & Checking Depth',
        image: 'https://images.unsplash.com/photo-1565193566173-7a0ee3dbe261?auto=format&fit=crop&w=800&q=80',
        explanation: 'Support the outer clay dome with left fingers. Press right middle fingers down the center until 1/4 inch from the wheel bat. Push out to form flat floor.',
        materials: ['Needle tool for measuring floor thickness', 'Sponge'],
        proTip: 'Push needle tool through floor and slide thumb down to needle to verify a crisp 1/4 inch floor thickness.'
      },
      {
        stepNumber: 4,
        title: 'First & Second Wall Pulls',
        image: 'https://images.unsplash.com/photo-1565193566173-7a0ee3dbe261?auto=format&fit=crop&w=800&q=80',
        explanation: 'Position inside fingers and outside fingers at the 4 o’clock position. Pinch gently to create a clay donut ridge, then pull steadily upward.',
        materials: ['Hydra sponge', 'Fingertips with slip lubrication'],
        proTip: 'Release pressure smoothly at the rim; abrupt let-offs cause the top lip to wobble or tear.'
      },
      {
        stepNumber: 5,
        title: 'Rib Shaping, Rim Compression & Wire Cutoff',
        image: 'https://images.unsplash.com/photo-1565193566173-7a0ee3dbe261?auto=format&fit=crop&w=800&q=80',
        explanation: 'Smooth the outer cylinder walls with a metal or wooden rib. Compress the top rim with a chamois leather strip. Pull cutoff wire under the base.',
        materials: ['Stainless steel smoothing rib', 'Chamois leather strip', 'Braided cutoff wire'],
        proTip: 'Pull the wire taut along the wheel head while the wheel spins very slowly to separate without warping the pot.'
      }
    ]
  }
];

// Smart helper function to ensure every category has high quality matching tutorials
export function getTutorialsForCategory(category: { id: string; name: string; description?: string; color?: string }): Tutorial[] {
  const directMatches = TUTORIALS_DATA.filter(t => t.categoryId === category.id);
  if (directMatches.length > 0) {
    return directMatches;
  }

  // Generate customized tutorial preview for this specific category
  const generatedTutorial: Tutorial = {
    id: `tut-${category.id}-foundations`,
    categoryId: category.id,
    title: `${category.name} Foundations & Master Techniques`,
    subtitle: `Step-by-step masterclass covering core tools, materials, practical studio techniques, and finishing touches for ${category.name}.`,
    coverImage: 'https://images.unsplash.com/photo-1579783902614-a3fb3927b675?auto=format&fit=crop&w=800&q=80',
    difficulty: 'Beginner',
    durationMinutes: 30,
    totalSteps: 6,
    rating: 4.95,
    tags: [category.name, 'Fundamentals', 'Step-by-Step', 'Studio Guide'],
    creator: {
      name: 'Elena Rostova & Guest Artisans',
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&q=80',
      role: `Master ${category.name} Practitioner`
    },
    steps: [
      {
        stepNumber: 1,
        title: 'Essential Workspace & Tool Setup',
        image: 'https://images.unsplash.com/photo-1513364776144-60967b0f800f?auto=format&fit=crop&w=800&q=80',
        explanation: `Organize your dedicated creative workspace with the primary materials, surface supports, and protective backing needed for ${category.name}.`,
        materials: ['Primary studio starter kit', 'Surface protection mat', 'Measurement gauge'],
        proTip: 'Keep high-usage tools arranged within arm’s reach on your dominant hand side for ergonomic flow.'
      },
      {
        stepNumber: 2,
        title: 'Material Calibration & Safety Prep',
        image: 'https://images.unsplash.com/photo-1544717305-2782549b5136?auto=format&fit=crop&w=800&q=80',
        explanation: `Inspect the consistency, moisture level, or pigmentation of your media before starting your initial composition in ${category.name}.`,
        materials: ['Testing sample strip', 'Clean rag / solvent', 'Mixing palette'],
        proTip: 'Perform a test swatch on scrap material first to check adhesion and drying characteristics.'
      },
      {
        stepNumber: 3,
        title: 'Initial Structuring & Rough Layout',
        image: 'https://images.unsplash.com/photo-1579783900882-c0d3dad7b119?auto=format&fit=crop&w=800&q=80',
        explanation: 'Block out the primary gesture, framework, or foundation lines. Focus on proportion and balance before committing heavy details.',
        materials: ['Foundation pencil / marker', 'Primary working tools'],
        proTip: 'Step back 6 feet from your project periodically to evaluate overall structural harmony.'
      },
      {
        stepNumber: 4,
        title: 'Building Core Values & Midtone Layers',
        image: 'https://images.unsplash.com/photo-1580196969807-cc6de06c05be?auto=format&fit=crop&w=800&q=80',
        explanation: 'Apply midtone values and primary forms in sequential layers, allowing proper bonding or curing between coats.',
        materials: ['Medium grade tools', 'Layering medium'],
        proTip: 'Build from light to dark or general to specific for optimal control and reworkability.'
      },
      {
        stepNumber: 5,
        title: 'Deep Shadows & Fine Detail Pass',
        image: 'https://images.unsplash.com/photo-1569172122301-bc500f309134?auto=format&fit=crop&w=800&q=80',
        explanation: 'Carve or render crisp focal highlights, sharp edge contours, and contrasting shadows to give your artwork dimensional depth.',
        materials: ['Detail precision tools', 'Highlight accents'],
        proTip: 'Limit maximum contrast highlights to the primary focal point of your composition.'
      },
      {
        stepNumber: 6,
        title: 'Curing, Sealing & Final Presentation',
        image: 'https://images.unsplash.com/photo-1541701494587-cb58502866ab?auto=format&fit=crop&w=800&q=80',
        explanation: `Seal, glaze, or protect your completed ${category.name} masterpiece with archival varnish or fixative for lifetime gallery preservation.`,
        materials: ['Archival protective sealant', 'Display mount / backing'],
        proTip: 'Allow full manufacturer-specified curing time before framing or direct handling.'
      }
    ]
  };

  return [generatedTutorial, ...TUTORIALS_DATA.slice(0, 3)];
}

