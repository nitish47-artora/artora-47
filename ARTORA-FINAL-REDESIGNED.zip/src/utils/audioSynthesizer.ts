// WebAudio Real-time Synthesizer for Legal Royalty-Free Audio Demonstrations

class AudioSynthEngine {
  private ctx: AudioContext | null = null;
  private isPlaying = false;
  private currentPreset: string | null = null;
  private timerId: any = null;
  private onTimeUpdateCallback: ((time: number, isPlaying: boolean) => void) | null = null;
  private currentTime = 0;
  private trackDuration = 30;

  private initContext() {
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      this.ctx = new AudioCtx();
    }
    if (this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  }

  public setTimeUpdateListener(cb: (time: number, isPlaying: boolean) => void) {
    this.onTimeUpdateCallback = cb;
  }

  public playPreset(preset: string, durationSec: number = 30) {
    this.initContext();
    this.stop();
    this.isPlaying = true;
    this.currentPreset = preset;
    this.currentTime = 0;
    this.trackDuration = durationSec;

    this.scheduleNotes(preset);

    this.timerId = setInterval(() => {
      if (!this.isPlaying) return;
      this.currentTime += 0.5;
      if (this.currentTime >= this.trackDuration) {
        this.currentTime = 0;
      }
      if (this.onTimeUpdateCallback) {
        this.onTimeUpdateCallback(this.currentTime, this.isPlaying);
      }
    }, 500);
  }

  private scheduleNotes(preset: string) {
    if (!this.ctx) return;

    const playTone = (freq: number, startDelay: number, duration: number, type: OscillatorType = 'sine', gainVal = 0.15) => {
      if (!this.ctx) return;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = type;
      osc.frequency.setValueAtTime(freq, this.ctx.currentTime + startDelay);

      gain.gain.setValueAtTime(0.001, this.ctx.currentTime + startDelay);
      gain.gain.exponentialRampToValueAtTime(gainVal, this.ctx.currentTime + startDelay + 0.05);
      gain.gain.exponentialRampToValueAtTime(0.0001, this.ctx.currentTime + startDelay + duration);

      osc.connect(gain);
      gain.connect(this.ctx.destination);

      osc.start(this.ctx.currentTime + startDelay);
      osc.stop(this.ctx.currentTime + startDelay + duration + 0.1);
    };

    // Loops based on preset
    const loopInterval = 4.0;
    const now = 0.05;

    const runLoop = () => {
      if (!this.isPlaying || this.currentPreset !== preset) return;

      if (preset === 'jazz_swing') {
        // Sophisticated Jazz ii-V-I chords (Dm9 -> G13 -> Cmaj9)
        playTone(146.83, 0.0, 1.2, 'triangle', 0.2); // D3
        playTone(220.00, 0.1, 1.2, 'sine', 0.15); // A3
        playTone(329.63, 0.2, 1.0, 'sine', 0.12); // E4
        playTone(349.23, 0.3, 1.0, 'triangle', 0.1); // F4
        
        playTone(196.00, 1.3, 1.2, 'triangle', 0.2); // G3
        playTone(246.94, 1.4, 1.0, 'sine', 0.15); // B3
        playTone(329.63, 1.5, 1.0, 'sine', 0.12); // E4
        playTone(440.00, 1.6, 0.9, 'triangle', 0.1); // A4

        playTone(130.81, 2.6, 1.4, 'triangle', 0.22); // C3
        playTone(246.94, 2.7, 1.4, 'sine', 0.16); // B3
        playTone(329.63, 2.8, 1.3, 'sine', 0.14); // E4
        playTone(392.00, 2.9, 1.3, 'triangle', 0.12); // G4
        playTone(493.88, 3.1, 0.8, 'sine', 0.1); // B4
      } else if (preset === 'classical_piano') {
        // Clair de Lune style gentle arpeggios
        const notes = [261.63, 329.63, 392.0, 523.25, 659.25, 523.25, 392.0, 329.63];
        notes.forEach((freq, idx) => {
          playTone(freq, idx * 0.45, 0.9, 'sine', 0.18);
        });
      } else if (preset === 'lofi_chill') {
        // Soft vintage keys with 7th chords
        playTone(174.61, 0.0, 1.8, 'sine', 0.2); // F3
        playTone(261.63, 0.05, 1.8, 'triangle', 0.12);
        playTone(329.63, 0.1, 1.8, 'sine', 0.1);
        playTone(392.00, 0.15, 1.8, 'sine', 0.08);

        playTone(164.81, 2.0, 1.8, 'sine', 0.2); // E3
        playTone(246.94, 2.05, 1.8, 'triangle', 0.12);
        playTone(329.63, 2.1, 1.8, 'sine', 0.1);
        playTone(392.00, 2.15, 1.8, 'sine', 0.08);
      } else if (preset === 'ambient_chords') {
        // Ethereal warm lush pads
        playTone(130.81, 0.0, 3.5, 'sine', 0.25);
        playTone(196.00, 0.2, 3.5, 'sine', 0.18);
        playTone(293.66, 0.4, 3.5, 'triangle', 0.12);
        playTone(392.00, 0.6, 3.5, 'sine', 0.1);
      } else if (preset === 'blues_riff') {
        // 12-bar blues shuffle feel
        const bluesNotes = [110, 164.81, 196, 220, 261.63, 246.94, 220, 196];
        bluesNotes.forEach((freq, idx) => {
          playTone(freq, idx * 0.45, 0.4, 'triangle', 0.2);
        });
      } else if (preset === 'synthwave') {
        // Retro 80s bassline
        const synthNotes = [110, 110, 130.81, 146.83, 164.81, 146.83, 130.81, 98];
        synthNotes.forEach((freq, idx) => {
          playTone(freq, idx * 0.4, 0.35, 'sawtooth', 0.1);
        });
      } else {
        // Folk acoustic arpeggios
        const folk = [146.83, 220, 293.66, 369.99, 440, 369.99, 293.66, 220];
        folk.forEach((freq, idx) => {
          playTone(freq, idx * 0.45, 0.8, 'triangle', 0.15);
        });
      }

      if (this.isPlaying) {
        setTimeout(runLoop, loopInterval * 1000);
      }
    };

    runLoop();
  }

  public pause() {
    this.isPlaying = false;
    if (this.timerId) clearInterval(this.timerId);
    if (this.onTimeUpdateCallback) {
      this.onTimeUpdateCallback(this.currentTime, false);
    }
  }

  public resume() {
    if (!this.currentPreset) return;
    this.isPlaying = true;
    this.scheduleNotes(this.currentPreset);
    this.timerId = setInterval(() => {
      if (!this.isPlaying) return;
      this.currentTime += 0.5;
      if (this.currentTime >= this.trackDuration) {
        this.currentTime = 0;
      }
      if (this.onTimeUpdateCallback) {
        this.onTimeUpdateCallback(this.currentTime, this.isPlaying);
      }
    }, 500);
  }

  public stop() {
    this.isPlaying = false;
    if (this.timerId) {
      clearInterval(this.timerId);
      this.timerId = null;
    }
    this.currentTime = 0;
    if (this.onTimeUpdateCallback) {
      this.onTimeUpdateCallback(0, false);
    }
  }

  public getCurrentTime() {
    return this.currentTime;
  }

  public isCurrentlyPlaying() {
    return this.isPlaying;
  }

  public getActivePreset() {
    return this.currentPreset;
  }
}

export const audioSynth = new AudioSynthEngine();
