package com.artora.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.artora.app.data.ArtoraRepository
import com.artora.app.model.ArtistProfile
import com.artora.app.ui.theme.*

@Composable
fun ArtistProfileScreen(
    artistId: String,
    onBack: () -> Unit = {}
) {
    val artist = ArtoraRepository.artists.find { it.id == artistId } ?: ArtoraRepository.artists[0]
    var isFollowing by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(ArtoraIvory)
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Column(modifier = Modifier.padding(top = 12.dp)) {
                Button(
                    onClick = onBack,
                    colors = ButtonDefaults.buttonColors(containerColor = ArtoraWhite),
                    border = androidx.compose.foundation.BorderStroke(1.dp, ArtoraBeige),
                    shape = RoundedCornerShape(50),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Text("← Back to Gallery", color = ArtoraCharcoal, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Hero Card
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = ArtoraWhite),
                    border = androidx.compose.foundation.BorderStroke(1.dp, ArtoraBeige),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column {
                        Box(modifier = Modifier.fillMaxWidth().height(140.dp)) {
                            AsyncImage(
                                model = artist.coverImage,
                                contentDescription = artist.name,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize()
                            )
                        }

                        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.Bottom
                            ) {
                                AsyncImage(
                                    model = artist.avatar,
                                    contentDescription = artist.name,
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier
                                        .size(64.dp)
                                        .offset(y = (-24).dp)
                                        .clip(CircleShape)
                                        .border(2.dp, ArtoraGold, CircleShape)
                                )

                                Button(
                                    onClick = { isFollowing = !isFollowing },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = if (isFollowing) ArtoraCharcoal else ArtoraGold
                                    ),
                                    shape = RoundedCornerShape(50)
                                ) {
                                    Text(
                                        text = if (isFollowing) "Following" else "Follow Atelier",
                                        color = if (isFollowing) ArtoraGold else ArtoraCharcoal,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 11.sp
                                    )
                                }
                            }

                            Text(
                                text = artist.name,
                                fontFamily = FontFamily.Serif,
                                fontWeight = FontWeight.Bold,
                                fontSize = 20.sp,
                                color = ArtoraCharcoal
                            )
                            Text(
                                text = "${artist.handle} • ${artist.location}",
                                fontSize = 12.sp,
                                color = ArtoraMuted
                            )
                            Text(
                                text = artist.bio,
                                fontSize = 12.sp,
                                color = ArtoraTextBody
                            )

                            // Badges
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                artist.badges.forEach { badge ->
                                    Surface(
                                        shape = RoundedCornerShape(50),
                                        color = ArtoraBlush,
                                        border = androidx.compose.foundation.BorderStroke(1.dp, ArtoraCreamBorder)
                                    ) {
                                        Text(
                                            text = badge,
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = ArtoraCharcoal,
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}
