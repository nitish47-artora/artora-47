package com.artora.app.model

enum class DifficultyLevel(val label: String) {
    BEGINNER("Beginner"),
    INTERMEDIATE("Intermediate"),
    ADVANCED("Advanced"),
    PORTFOLIO_READY("Portfolio Ready")
}

data class ArtCategory(
    val id: String = "",
    val name: String,
    val tagline: String,
    val description: String,
    val iconName: String,
    val coverImage: String,
    val historyFact: String
)

data class TutorialStep(
    val stepNumber: Int,
    val title: String,
    val image: String,
    val explanation: String,
    val materials: List<String>,
    val proTip: String? = null
)

data class Tutorial(
    val id: String,
    val categoryId: String,
    val title: String,
    val subtitle: String,
    val coverImage: String,
    val difficulty: DifficultyLevel,
    val durationMinutes: Int,
    val creatorName: String,
    val creatorAvatar: String,
    val creatorRole: String,
    val steps: List<TutorialStep>,
    val tags: List<String>
)

data class PracticeTask(
    val id: String,
    val categoryId: String,
    val taskNumber: Int,
    val title: String,
    val level: DifficultyLevel,
    val estimatedMinutes: Int,
    val materials: List<String>,
    val instructions: List<String>,
    val referenceImage: String,
    val mentorTip: String
)

data class Artwork(
    val id: String,
    val title: String,
    val artistId: String,
    val artistName: String,
    val artistAvatar: String,
    val artForm: String,
    val style: String,
    val materials: String,
    val dimensions: String,
    val image: String,
    val price: Double,
    val isForSale: Boolean,
    val description: String
)

data class ArtistProfile(
    val id: String,
    val name: String,
    val handle: String,
    val specialization: String,
    val location: String,
    val bio: String,
    val avatar: String,
    val coverImage: String,
    val rating: Double,
    val followersCount: Int,
    val artworksCount: Int,
    val openForCommissions: Boolean,
    val badges: List<String>
)

data class ArtEvent(
    val id: String,
    val title: String,
    val type: String,
    val venue: String,
    val city: String,
    val address: String,
    val distanceKm: Double,
    val dateStr: String,
    val timeStr: String,
    val isFree: Boolean,
    val priceStr: String,
    val image: String,
    val description: String,
    val rsvpCount: Int
)

data class MusicTrack(
    val id: String,
    val title: String,
    val artist: String,
    val genre: String,
    val duration: Int, // seconds
    val audioPreset: String,
    val coverImage: String,
    val description: String,
    val bpm: Int,
    val license: String
)

data class MusicGenreInfo(
    val id: String,
    val name: String,
    val tagline: String,
    val coverImage: String,
    val history: String,
    val characteristics: List<String>,
    val tracks: List<MusicTrack>
)
