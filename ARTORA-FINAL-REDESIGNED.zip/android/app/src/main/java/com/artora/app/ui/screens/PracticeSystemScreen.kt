package com.artora.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.artora.app.data.ArtoraRepository
import com.artora.app.model.PracticeTask
import com.artora.app.ui.theme.*

@Composable
fun PracticeSystemScreen() {
    val tasks = ArtoraRepository.practiceTasks
    var selectedTaskIndex by remember { mutableStateOf(0) }
    var completedTaskIndices by remember { mutableStateOf(setOf<Int>()) }
    var uploadedImageUrl by remember { mutableStateOf<String?>(null) }
    var isCritiquing by remember { mutableStateOf(false) }
    var showCritiqueFeedback by remember { mutableStateOf(false) }

    val currentTask = tasks.getOrElse(selectedTaskIndex) { tasks[0] }

    val levels = listOf(
        "FOUNDATIONS" to "Shape decomposition",
        "TONAL DEPTH" to "Chiaroscuro planes",
        "ATMOSPHERE" to "Color temperature",
        "ATELIER MASTER" to "Original masterwork"
    )

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(ArtoraIvory)
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Header
        item {
            Column(modifier = Modifier.padding(top = 12.dp, bottom = 4.dp)) {
                Surface(
                    shape = RoundedCornerShape(50),
                    color = ArtoraBlush,
                    border = androidx.compose.foundation.BorderStroke(1.dp, ArtoraCreamBorder)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.Brush,
                            contentDescription = null,
                            tint = ArtoraGold,
                            modifier = Modifier.size(14.dp)
                        )
                        Text(
                            text = "INTERACTIVE ATELIER STUDIO",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = ArtoraCharcoal,
                            letterSpacing = 1.2.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = "Create With Me",
                    fontFamily = FontFamily.Serif,
                    fontSize = 26.sp,
                    fontWeight = FontWeight.Normal,
                    color = ArtoraCharcoal
                )
                Text(
                    text = "& Studio Practice Ladder",
                    fontFamily = FontFamily.Serif,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Light,
                    color = ArtoraMuted
                )
            }
        }

        // 4-Stage Progression Ladder Pills
        item {
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                itemsIndexed(levels) { index, pair ->
                    val isSelected = selectedTaskIndex == index
                    val isCompleted = completedTaskIndices.contains(index)

                    Card(
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = if (isSelected) ArtoraWhite else if (isCompleted) ArtoraBlush else ArtoraWhite
                        ),
                        border = androidx.compose.foundation.BorderStroke(
                            1.dp,
                            if (isSelected) ArtoraGold else if (isCompleted) ArtoraGold.copy(alpha = 0.5f) else ArtoraBeige
                        ),
                        modifier = Modifier
                            .width(140.dp)
                            .clickable {
                                selectedTaskIndex = index
                                uploadedImageUrl = null
                                showCritiqueFeedback = false
                            }
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "Stage ${index + 1}",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isSelected) ArtoraGold else ArtoraMuted
                                )
                                if (isCompleted) {
                                    Icon(
                                        imageVector = Icons.Default.Check,
                                        contentDescription = "Completed",
                                        tint = ArtoraGold,
                                        modifier = Modifier.size(12.dp)
                                    )
                                }
                            }
                            Text(
                                text = pair.first,
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Serif,
                                fontWeight = FontWeight.Bold,
                                color = ArtoraCharcoal,
                                modifier = Modifier.padding(top = 2.dp)
                            )
                            Text(
                                text = pair.second,
                                fontSize = 9.sp,
                                color = ArtoraMuted,
                                maxLines = 1
                            )
                        }
                    }
                }
            }
        }

        // Workbench Card
        item {
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = ArtoraWhite),
                border = androidx.compose.foundation.BorderStroke(1.dp, ArtoraBeige),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    
                    // Badges
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            shape = RoundedCornerShape(50),
                            color = ArtoraGold
                        ) {
                            Text(
                                text = "Stage ${currentTask.taskNumber} of 4",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = ArtoraCharcoal,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                            )
                        }
                        Surface(
                            shape = RoundedCornerShape(50),
                            color = ArtoraBlush,
                            border = androidx.compose.foundation.BorderStroke(1.dp, ArtoraCreamBorder)
                        ) {
                            Text(
                                text = currentTask.level.label,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = ArtoraCharcoal,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                            )
                        }
                        Text(
                            text = "~${currentTask.estimatedMinutes} mins",
                            fontSize = 11.sp,
                            color = ArtoraMuted
                        )
                    }

                    Text(
                        text = currentTask.title,
                        fontFamily = FontFamily.Serif,
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp,
                        color = ArtoraCharcoal
                    )

                    // Master Reference
                    Box(modifier = Modifier.fillMaxWidth().height(180.dp).clip(RoundedCornerShape(12.dp))) {
                        AsyncImage(
                            model = currentTask.referenceImage,
                            contentDescription = currentTask.title,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                        Surface(
                            shape = RoundedCornerShape(50),
                            color = ArtoraIvory.copy(alpha = 0.9f),
                            modifier = Modifier.align(Alignment.BottomEnd).padding(8.dp)
                        ) {
                            Text(
                                text = "Study Guide",
                                fontSize = 9.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = ArtoraCharcoal,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                            )
                        }
                    }

                    // Steps
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(
                            text = "ATELIER EXERCISE STEPS",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = ArtoraMuted,
                            letterSpacing = 1.sp
                        )
                        currentTask.instructions.forEachIndexed { idx, step ->
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.Top) {
                                Box(
                                    modifier = Modifier
                                        .size(18.dp)
                                        .clip(CircleShape)
                                        .background(ArtoraBlush)
                                        .border(1.dp, ArtoraCreamBorder, CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = "${idx + 1}",
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = ArtoraGold
                                    )
                                }
                                Text(
                                    text = step,
                                    fontSize = 12.sp,
                                    color = ArtoraTextBody
                                )
                            }
                        }
                    }

                    // Mentor Tip
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = ArtoraBlush,
                        border = androidx.compose.foundation.BorderStroke(1.dp, ArtoraCreamBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(10.dp),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.Lightbulb,
                                contentDescription = null,
                                tint = ArtoraGold,
                                modifier = Modifier.size(16.dp)
                            )
                            Text(
                                text = "Master Insight: ${currentTask.mentorTip}",
                                fontSize = 11.sp,
                                color = ArtoraTextBody
                            )
                        }
                    }

                    // Upload / Sample Button & Review
                    if (uploadedImageUrl == null) {
                        Button(
                            onClick = {
                                uploadedImageUrl = "https://images.unsplash.com/photo-1544717305-2782549b5136?auto=format&fit=crop&w=800&q=80"
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = ArtoraBlush),
                            border = androidx.compose.foundation.BorderStroke(1.dp, ArtoraCreamBorder),
                            shape = RoundedCornerShape(50),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.Upload,
                                contentDescription = null,
                                tint = ArtoraGold,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Load Sketchbook Study Photo", color = ArtoraCharcoal, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                        }
                    } else {
                        // Critique Trigger
                        Button(
                            onClick = {
                                isCritiquing = true
                                showCritiqueFeedback = true
                                completedTaskIndices = completedTaskIndices + selectedTaskIndex
                                isCritiquing = false
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = ArtoraGold),
                            shape = RoundedCornerShape(50),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.Shield,
                                contentDescription = null,
                                tint = ArtoraCharcoal,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Request Master Critique & Advance", color = ArtoraCharcoal, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    // Critique Evaluation Result
                    if (showCritiqueFeedback) {
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = ArtoraBlush,
                            border = androidx.compose.foundation.BorderStroke(1.dp, ArtoraCreamBorder),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text(
                                    text = "Master Evaluation: Ready for Next Challenge",
                                    fontFamily = FontFamily.Serif,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    color = ArtoraCharcoal
                                )
                                Text(
                                    text = "✓ Foundational geometry matches master proportions accurately.\n✓ Clean value separation along terminator shadow planes.\n✓ Ready for the next atelier stage.",
                                    fontSize = 11.sp,
                                    color = ArtoraTextBody
                                )
                            }
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}
