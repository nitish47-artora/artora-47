package com.artora.app.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.artora.app.data.ArtoraRepository
import com.artora.app.ui.theme.*

@Composable
fun ExposScreen() {
    val context = LocalContext.current
    val events = ArtoraRepository.events
    fun open(url: String) { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
    LazyColumn(Modifier.fillMaxSize().background(ArtoraIvory).padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(bottom = 24.dp)) {
        item {
            Column(Modifier.padding(top = 12.dp)) {
                Text("EXPOS", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = ArtoraGold, letterSpacing = 1.4.sp)
                Text("Exhibitions near you", fontFamily = FontFamily.Serif, fontSize = 27.sp, fontWeight = FontWeight.Bold, color = ArtoraCharcoal)
                Text("Find art expos, galleries and exhibitions, then book tickets externally.", fontSize = 12.sp, color = ArtoraMuted)
            }
        }
        items(events.size) { index ->
            val event = events[index]
            Card(shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = ArtoraWhite), border = androidx.compose.foundation.BorderStroke(1.dp, ArtoraBeige)) {
                Column(Modifier.padding(16.dp)) {
                    Text(event.title, fontFamily = FontFamily.Serif, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = ArtoraCharcoal)
                    Text("${event.dateStr} • ${event.venue}", fontSize = 11.sp, color = ArtoraMuted)
                    Text("${event.distanceKm} km away • ${event.priceStr}", fontSize = 11.sp, color = ArtoraGold, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 4.dp))
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { open("https://www.district.in/") }, colors = ButtonDefaults.buttonColors(containerColor = ArtoraGold), shape = RoundedCornerShape(50), modifier = Modifier.weight(1f)) { Text("District", color = ArtoraCharcoal, fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                        OutlinedButton(onClick = { open("https://in.bookmyshow.com/") }, shape = RoundedCornerShape(50), modifier = Modifier.weight(1f)) { Text("BookMyShow", color = ArtoraCharcoal, fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                    }
                }
            }
        }
    }
}
