package com.artora.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val ArtoraLightColorScheme = lightColorScheme(
    primary = ArtoraGold,
    onPrimary = ArtoraCharcoal,
    primaryContainer = ArtoraBlush,
    onPrimaryContainer = ArtoraCharcoal,
    secondary = ArtoraCharcoal,
    onSecondary = ArtoraWhite,
    background = ArtoraIvory,
    onBackground = ArtoraCharcoal,
    surface = ArtoraWhite,
    onSurface = ArtoraCharcoal,
    surfaceVariant = ArtoraBlush,
    onSurfaceVariant = ArtoraMuted,
    outline = ArtoraBeige
)

@Composable
fun ArtoraTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = ArtoraLightColorScheme,
        typography = Typography,
        content = content
    )
}
