package com.artora.app.ui.theme

import androidx.compose.ui.graphics.Color

val ArtoraIvory = Color(0xFFFAF8F5)
val ArtoraWhite = Color(0xFFFFFFFF)
val ArtoraCharcoal = Color(0xFF2D2926)
val ArtoraGold = Color(0xFFC5A059)
val ArtoraGoldDark = Color(0xFFB38E46)
val ArtoraBlush = Color(0xFFFAF2F0)
val ArtoraBeige = Color(0xFFEFE8DE)
val ArtoraCreamBorder = Color(0xFFEFE6D5)
val ArtoraMuted = Color(0xFF7D7571)
val ArtoraTextBody = Color(0xFF57514D)
val ArtoraCardSurface = Color(0xFFFFFFFF)
