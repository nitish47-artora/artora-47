package com.artora.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.artora.app.data.ArtoraRepository
import com.artora.app.model.ArtEvent
import com.artora.app.ui.theme.*

@Composable
fun ExploreNearbyScreen() {
    var rsvpedEventIds by remember { mutableStateOf(setOf<String>()) }
    var selectedEventModal by remember { mutableStateOf<ArtEvent?>(null) }
    var showMapSim by remember { mutableStateOf(false) }

    val events = ArtoraRepository.events

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(ArtoraIvory)
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Header
        item {
            Column(modifier = Modifier.padding(top = 12.dp, bottom = 4.dp)) {
                Surface(
                    shape = RoundedCornerShape(50),
                    color = ArtoraBlush,
                    border = androidx.compose.foundation.BorderStroke(1.dp, ArtoraCreamBorder)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.Place,
                            contentDescription = null,
                            tint = ArtoraGold,
                            modifier = Modifier.size(14.dp)
                        )
                        Text(
                            text = "GEOLOCATION & CULTURAL SALONS",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = ArtoraCharcoal,
                            letterSpacing = 1.2.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = "Local Salons & Gatherings",
                    fontFamily = FontFamily.Serif,
                    fontSize = 26.sp,
                    fontWeight = FontWeight.Normal,
                    color = ArtoraCharcoal
                )
                Text(
                    text = "Nearby openings, plein-air sessions, and live acoustic gatherings.",
                    fontSize = 12.sp,
                    color = ArtoraTextBody,
                    modifier = Modifier.padding(top = 4.dp)
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Toggle Map Mode / List Mode Button
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = { showMapSim = false },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (!showMapSim) ArtoraGold else ArtoraWhite
                        ),
                        border = androidx.compose.foundation.BorderStroke(1.dp, if (!showMapSim) ArtoraGold else ArtoraBeige),
                        shape = RoundedCornerShape(50),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("List View", color = ArtoraCharcoal, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                    Button(
                        onClick = { showMapSim = true },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (showMapSim) ArtoraGold else ArtoraWhite
                        ),
                        border = androidx.compose.foundation.BorderStroke(1.dp, if (showMapSim) ArtoraGold else ArtoraBeige),
                        shape = RoundedCornerShape(50),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Map Radar", color = ArtoraCharcoal, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        if (showMapSim) {
            // Interactive Radar Map Simulation
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = ArtoraBlush),
                    border = androidx.compose.foundation.BorderStroke(1.dp, ArtoraCreamBorder),
                    modifier = Modifier.fillMaxWidth().height(260.dp)
                ) {
                    Box(modifier = Modifier.fillMaxSize()) {
                        // Stylized Map Grid
                        Column(
                            modifier = Modifier.fillMaxSize().padding(16.dp),
                            verticalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "SAN FRANCISCO CULTURAL RADAR",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = ArtoraCharcoal,
                                letterSpacing = 1.2.sp
                            )
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceAround
                            ) {
                                events.forEach { ev ->
                                    Surface(
                                        shape = RoundedCornerShape(50),
                                        color = ArtoraCharcoal,
                                        modifier = Modifier.clickable { selectedEventModal = ev }
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Outlined.Place,
                                                contentDescription = null,
                                                tint = ArtoraGold,
                                                modifier = Modifier.size(12.dp)
                                            )
                                            Text(
                                                text = "${ev.distanceKm} km",
                                                color = ArtoraWhite,
                                                fontSize = 10.sp,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                    }
                                }
                            }
                            Text(
                                text = "Tap any beacon pin to view salon details and RSVP.",
                                fontSize = 10.sp,
                                color = ArtoraMuted
                            )
                        }
                    }
                }
            }
        }

        // Event Cards
        items(events) { ev ->
            val isRsvped = rsvpedEventIds.contains(ev.id)

            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = ArtoraWhite),
                border = androidx.compose.foundation.BorderStroke(1.dp, ArtoraBeige),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { selectedEventModal = ev }
            ) {
                Column {
                    Box(modifier = Modifier.fillMaxWidth().height(140.dp)) {
                        AsyncImage(
                            model = ev.image,
                            contentDescription = ev.title,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                        Surface(
                            shape = RoundedCornerShape(50),
                            color = ArtoraCharcoal.copy(alpha = 0.9f),
                            modifier = Modifier.align(Alignment.TopEnd).padding(10.dp)
                        ) {
                            Text(
                                text = ev.priceStr,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = ArtoraGold,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                            )
                        }
                    }

                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = ev.type.uppercase(),
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = ArtoraGoldDark,
                                letterSpacing = 1.sp
                            )
                            Text(
                                text = "${ev.distanceKm} km away",
                                fontSize = 10.sp,
                                color = ArtoraMuted
                            )
                        }

                        Text(
                            text = ev.title,
                            fontFamily = FontFamily.Serif,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = ArtoraCharcoal
                        )

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.AccessTime,
                                contentDescription = null,
                                tint = ArtoraMuted,
                                modifier = Modifier.size(12.dp)
                            )
                            Text(
                                text = "${ev.dateStr} • ${ev.venue}",
                                fontSize = 11.sp,
                                color = ArtoraTextBody
                            )
                        }

                        Divider(color = ArtoraBeige, thickness = 1.dp, modifier = Modifier.padding(vertical = 4.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "${ev.rsvpCount + (if (isRsvped) 1 else 0)} attending",
                                fontSize = 11.sp,
                                color = ArtoraMuted
                            )

                            Button(
                                onClick = {
                                    rsvpedEventIds = if (isRsvped) rsvpedEventIds - ev.id else rsvpedEventIds + ev.id
                                },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (isRsvped) ArtoraCharcoal else ArtoraGold
                                ),
                                shape = RoundedCornerShape(50),
                                contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp)
                            ) {
                                Text(
                                    text = if (isRsvped) "Attending ✓" else "RSVP Now",
                                    color = if (isRsvped) ArtoraGold else ArtoraCharcoal,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }

    // Modal
    selectedEventModal?.let { ev ->
        AlertDialog(
            onDismissRequest = { selectedEventModal = null },
            confirmButton = {
                Button(
                    onClick = {
                        rsvpedEventIds = rsvpedEventIds + ev.id
                        selectedEventModal = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ArtoraGold),
                    shape = RoundedCornerShape(50)
                ) {
                    Text("Confirm Attendance", color = ArtoraCharcoal, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { selectedEventModal = null }) {
                    Text("Close", color = ArtoraMuted)
                }
            },
            title = {
                Text(
                    text = ev.title,
                    fontFamily = FontFamily.Serif,
                    fontWeight = FontWeight.Bold,
                    color = ArtoraCharcoal
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(text = ev.description, fontSize = 12.sp, color = ArtoraTextBody)
                    Text(text = "Venue: ${ev.venue}", fontSize = 11.sp, color = ArtoraMuted)
                    Text(text = "Address: ${ev.address}", fontSize = 11.sp, color = ArtoraMuted)
                    Text(text = "Time: ${ev.timeStr}", fontSize = 11.sp, color = ArtoraMuted)
                }
            },
            containerColor = ArtoraIvory,
            shape = RoundedCornerShape(20.dp)
        )
    }
}
