package com.artora.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.artora.app.model.Tutorial
import com.artora.app.ui.theme.*

@Composable
fun TutorialPlayerScreen(tutorial: Tutorial, onBack: () -> Unit) {
    var completedSteps by remember { mutableStateOf(setOf<Int>()) }

    Column(
        modifier = Modifier.fillMaxSize().background(ArtoraIvory)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(12.dp),
            horizontalArrangement = Arrangement.Start
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Outlined.ArrowBack, contentDescription = "Back", tint = ArtoraCharcoal)
            }
            Column(modifier = Modifier.padding(start = 4.dp).weight(1f)) {
                Text("WORKSHOP", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = ArtoraGold)
                Text(tutorial.title, fontFamily = FontFamily.Serif, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = ArtoraCharcoal)
            }
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                AsyncImage(
                    model = tutorial.coverImage,
                    contentDescription = tutorial.title,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxWidth().height(190.dp)
                )
            }
            item {
                Text(
                    "${completedSteps.size}/${tutorial.steps.size} steps completed",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = ArtoraMuted
                )
            }
            items(tutorial.steps) { step ->
                val done = completedSteps.contains(step.stepNumber)
                Card(
                    colors = CardDefaults.cardColors(containerColor = ArtoraWhite),
                    border = androidx.compose.foundation.BorderStroke(1.dp, if (done) ArtoraGold else ArtoraBeige)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text("STEP ${step.stepNumber}", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = ArtoraGold)
                        Text(step.title, fontFamily = FontFamily.Serif, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = ArtoraCharcoal)
                        AsyncImage(
                            model = step.image,
                            contentDescription = step.title,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxWidth().height(150.dp).padding(top = 10.dp)
                        )
                        Text(step.explanation, fontSize = 12.sp, color = ArtoraTextBody, modifier = Modifier.padding(top = 10.dp))
                        Button(
                            onClick = {
                                completedSteps = if (done) completedSteps - step.stepNumber else completedSteps + step.stepNumber
                            },
                            modifier = Modifier.padding(top = 10.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = if (done) ArtoraBlush else ArtoraGold)
                        ) {
                            Text(if (done) "Completed ✓" else "Mark Step Complete", color = ArtoraCharcoal)
                        }
                    }
                }
            }
        }
    }
}
