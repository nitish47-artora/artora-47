package com.artora.app.data

import com.artora.app.model.*

object ArtoraRepository {

    val categories = listOf(
        ArtCategory(
            id = "painting",
            name = "Painting & Fine Art",
            tagline = "Oil, Watercolor, Acrylic & Gouache",
            description = "Explore timeless brushwork, master glazes, atmospheric washes, and vibrant pigment studies.",
            iconName = "Palette",
            coverImage = "https://images.unsplash.com/photo-1579783902614-a3fb3927b675?auto=format&fit=crop&w=800&q=80",
            historyFact = "Classical tempera was mixed with egg yolk before the Flemish Renaissance perfected slow-drying linseed oil."
        ),
        ArtCategory(
            id = "ceramics",
            name = "Pottery & Ceramics",
            tagline = "Wheel Throwing, Handbuilding & Glazing",
            description = "Transform raw stoneware and porcelain into sculptural vessels through tactile mastery.",
            iconName = "Layers",
            coverImage = "https://images.unsplash.com/photo-1565193566173-7a0ee3dbe261?auto=format&fit=crop&w=800&q=80",
            historyFact = "Jōmon earthenware from prehistoric Japan is among the oldest known ceramic traditions in human history."
        ),
        ArtCategory(
            id = "photography",
            name = "Fine Art Photography",
            tagline = "Composition, Chiaroscuro & Archival Darkroom",
            description = "Capture evocative moments, geometric balance, and fine monochrome tonal ranges.",
            iconName = "Camera",
            coverImage = "https://images.unsplash.com/photo-1516035069371-29a1b244cc32?auto=format&fit=crop&w=800&q=80",
            historyFact = "The camera obscura was utilized by Renaissance masters to study depth, optical projection, and perspective."
        ),
        ArtCategory(
            id = "digital_art",
            name = "Digital & Concept Art",
            tagline = "Stylized Illustration & Worldbuilding",
            description = "Harness digital stylus pressure, dynamic layer clipping, and digital color grading.",
            iconName = "Laptop",
            coverImage = "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=800&q=80",
            historyFact = "The first digital sketchpad was Sutherland's Sketchpad in 1963, introducing direct graphical manipulation."
        ),
        ArtCategory(
            id = "music",
            name = "Sonic Arts & Conservatory",
            tagline = "Harmonic lineages, acoustic masters & synthesized scores",
            description = "Immerse in jazz improvisation, classical counterpoint, ambient textures, and sound design.",
            iconName = "Music",
            coverImage = "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?auto=format&fit=crop&w=800&q=80",
            historyFact = "Pythagoras discovered musical harmony ratios by experimenting with vibrating blacksmith anvils and monochords."
        )
    )

    val artworks = listOf(
        Artwork(
            id = "art-alpine-mist-01",
            title = "Alpine Mist & Golden Chiaroscuro",
            artistId = "artist-elena-vance",
            artistName = "Elena Rostova",
            artistAvatar = "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&q=80",
            artForm = "Painting",
            style = "Atmospheric Realism",
            materials = "Winsor & Newton archival oils on Belgian linen",
            dimensions = "24 × 36 in (61 × 91 cm)",
            image = "https://images.unsplash.com/photo-1579783902614-a3fb3927b675?auto=format&fit=crop&w=1000&q=80",
            price = 1450.0,
            isForSale = true,
            description = "A study in dawn light filtering through high alpine peaks, executed using multi-layered transparent oil glazes."
        ),
        Artwork(
            id = "art-terracotta-02",
            title = "Wabi-Sabi Stoneware Vessel",
            artistId = "artist-marcus-chen",
            artistName = "Marcus Chen",
            artistAvatar = "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=200&q=80",
            artForm = "Pottery & Ceramics",
            style = "Japanese Minimalist",
            materials = "High-fire stoneware with wood-ash reduction glaze",
            dimensions = "14 × 8 in",
            image = "https://images.unsplash.com/photo-1565193566173-7a0ee3dbe261?auto=format&fit=crop&w=1000&q=80",
            price = 680.0,
            isForSale = true,
            description = "Wood-fired over 72 hours in an Anagama kiln, yielding natural ash deposits and warm earth tones."
        ),
        Artwork(
            id = "art-monochrome-03",
            title = "Solitude in Venice Fog",
            artistId = "artist-clara-dupont",
            artistName = "Clara Dupont",
            artistAvatar = "https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=200&q=80",
            artForm = "Photography",
            style = "Monochrome Fine Art",
            materials = "Silver gelatin fiber print, museum rag mounted",
            dimensions = "20 × 30 in",
            image = "https://images.unsplash.com/photo-1516035069371-29a1b244cc32?auto=format&fit=crop&w=1000&q=80",
            price = 920.0,
            isForSale = true,
            description = "Captured at 5:30 AM in the Venetian lagoon during winter fog using a medium format rangefinder."
        ),
        Artwork(
            id = "art-digital-04",
            title = "Neon Sanctuary in the Rain",
            artistId = "artist-sora-takahashi",
            artistName = "Sora Takahashi",
            artistAvatar = "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=200&q=80",
            artForm = "Digital Art",
            style = "Cyberpunk Neo-Noir",
            materials = "Archival Giclée print on Hahnemühle Photo Rag",
            dimensions = "24 × 24 in",
            image = "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=1000&q=80",
            price = 0.0,
            isForSale = false,
            description = "An exploration of futuristic urban solitude rendered in custom textured digital brushwork."
        )
    )

    val artists = listOf(
        ArtistProfile(
            id = "artist-elena-vance",
            name = "Elena Rostova",
            handle = "@elena.atelier",
            specialization = "Archival Oil Glazing & Landscape Realism",
            location = "Florence & Vienna",
            bio = "Trained at the Florence Classical Atelier. My practice explores the convergence of 19th-century atmospheric realism and contemporary light physics.",
            avatar = "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80",
            coverImage = "https://images.unsplash.com/photo-1579783902614-a3fb3927b675?auto=format&fit=crop&w=1000&q=80",
            rating = 4.96,
            followersCount = 14200,
            artworksCount = 38,
            openForCommissions = true,
            badges = listOf("Master Fellow", "Atelier Instructor", "Top Curator 2026")
        ),
        ArtistProfile(
            id = "artist-marcus-chen",
            name = "Marcus Chen",
            handle = "@marcus.ceramics",
            specialization = "Wood-Fired Anagama Stoneware",
            location = "Kyoto & Seattle",
            bio = "Dedicated to the unrepeatable poetry of wood-fired kilns, natural ash glaze melts, and ergonomic tea ceremony ware.",
            avatar = "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80",
            coverImage = "https://images.unsplash.com/photo-1565193566173-7a0ee3dbe261?auto=format&fit=crop&w=1000&q=80",
            rating = 4.92,
            followersCount = 9800,
            artworksCount = 52,
            openForCommissions = true,
            badges = listOf("Heritage Ceramicist", "Guild Master")
        )
    )

    val tutorials = listOf(
        Tutorial(
            id = "tut-watercolor-landscape-01",
            categoryId = "painting",
            title = "Mastering Atmospheric Landscape in Watercolor",
            subtitle = "Wet-on-wet washes, dry brush texture & edge control",
            coverImage = "https://images.unsplash.com/photo-1544717305-2782549b5136?auto=format&fit=crop&w=800&q=80",
            difficulty = DifficultyLevel.INTERMEDIATE,
            durationMinutes = 45,
            creatorName = "Elena Rostova",
            creatorAvatar = "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&q=80",
            creatorRole = "Classical Atelier Instructor",
            steps = listOf(
                TutorialStep(
                    stepNumber = 1,
                    title = "Paper Preparation & Horizon Geometry",
                    image = "https://images.unsplash.com/photo-1544717305-2782549b5136?auto=format&fit=crop&w=800&q=80",
                    explanation = "Stretch 300gsm cold-pressed cotton rag on a birch board. Establish the focal horizon line lightly using an HB graphite pencil.",
                    materials = listOf("300gsm Arches Cold Press", "Birch Board", "Gummed Tape", "HB Pencil"),
                    proTip = "Keep pencil lines extremely light so they melt seamlessly beneath transparent washes."
                ),
                TutorialStep(
                    stepNumber = 2,
                    title = "Luminous Sky Wash (Wet-on-Wet)",
                    image = "https://images.unsplash.com/photo-1579783902614-a3fb3927b675?auto=format&fit=crop&w=800&q=80",
                    explanation = "Saturate the upper sky area with clean water using a 2-inch hake brush. Charge Raw Sienna at the horizon and Cobalt Blue at the zenith.",
                    materials = listOf("Hake Brush 2\"", "Raw Sienna", "Cobalt Blue"),
                    proTip = "Tilt the board at 20 degrees to let gravity create an effortless smooth gradient."
                ),
                TutorialStep(
                    stepNumber = 3,
                    title = "Foreground Contrast & Dry-Brush Highlights",
                    image = "https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=800&q=80",
                    explanation = "Once the midtones are dry, use Burnt Umber with minimal water on a squirrel mop to skim across textured paper tooth.",
                    materials = listOf("Burnt Umber", "Squirrel Mop", "Lifting Sponge"),
                    proTip = "Keep the brush nearly parallel to the paper surface to catch only the highest grain ridges."
                )
            ),
            tags = listOf("Watercolor", "Atmospheric", "Landscape", "Color Theory")
        )
    ) + categories.filter { it.id != "painting" }.map { category ->
        Tutorial(
            id = "tut-${category.id}-01",
            categoryId = category.id,
            title = "Foundations of ${category.name}",
            subtitle = "A guided beginner pathway through ${category.tagline.lowercase()}",
            coverImage = category.coverImage,
            difficulty = DifficultyLevel.BEGINNER,
            durationMinutes = 30,
            creatorName = "Artora Academy",
            creatorAvatar = category.coverImage,
            creatorRole = "Artora Instructor",
            steps = listOf(
                TutorialStep(
                    1, "Observe & Plan", category.coverImage,
                    "Study the reference, identify the main forms, and decide the order of your first actions.",
                    listOf("Reference image", "Sketchbook"),
                    "Spend a few minutes planning before committing to detail."
                ),
                TutorialStep(
                    2, "Build the Foundation", category.coverImage,
                    "Create the primary shapes, structure, or rhythm of the work before adding fine detail.",
                    listOf("Basic tools for ${category.name}"),
                    "Keep the first pass simple and easy to adjust."
                ),
                TutorialStep(
                    3, "Refine & Review", category.coverImage,
                    "Add the defining details, step back, and compare the result with your reference.",
                    listOf("Your chosen materials"),
                    "A short pause often reveals proportions and details that need correction."
                )
            ),
            tags = listOf(category.name, "Beginner", "Foundations")
        )
    }

    val practiceTasks = listOf(
        PracticeTask(
            id = "task-oil-01",
            categoryId = "painting",
            taskNumber = 1,
            title = "Stage 1: Foundational Envelope & Value Block-In",
            level = DifficultyLevel.BEGINNER,
            estimatedMinutes = 35,
            materials = listOf("Vine Charcoal", "Newsprint Pad", "Kneaded Eraser"),
            instructions = listOf(
                "Deconstruct the master reference into primary geometric mass shapes.",
                "Establish outer proportional bounding boxes using straight construction sight-lines.",
                "Block in shadow planes with a single transparent halftone tone."
            ),
            referenceImage = "https://images.unsplash.com/photo-1544717305-2782549b5136?auto=format&fit=crop&w=800&q=80",
            mentorTip = "Squint your eyes to eliminate distracting micro-details and perceive only raw value masses."
        ),
        PracticeTask(
            id = "task-oil-02",
            categoryId = "painting",
            taskNumber = 2,
            title = "Stage 2: Chiaroscuro & Core Shadow Planes",
            level = DifficultyLevel.INTERMEDIATE,
            estimatedMinutes = 50,
            materials = listOf("Raw Umber", "Odorless Mineral Spirits", "Flat Hog Bristle #6"),
            instructions = listOf(
                "Mix a clean 5-step value scale from white to dark umber.",
                "Render the sharp terminator line between lit form and shadow core.",
                "Introduce subtle warm ambient reflection in the cast shadow floor."
            ),
            referenceImage = "https://images.unsplash.com/photo-1579783902614-a3fb3927b675?auto=format&fit=crop&w=800&q=80",
            mentorTip = "Never make your cast shadows darker than the core shadow terminator."
        ),
        PracticeTask(
            id = "task-oil-03",
            categoryId = "painting",
            taskNumber = 3,
            title = "Stage 3: Chromatic Temperature & Aerial Depth",
            level = DifficultyLevel.ADVANCED,
            estimatedMinutes = 65,
            materials = listOf("Ultramarine Blue", "Cadmium Yellow Medium", "Titanium White"),
            instructions = listOf(
                "Warm the foreground elements with saturated ochres and earth reds.",
                "Cool the receding planes with low-contrast cobalt and sky tint.",
                "Soften all background silhouettes using a dry fan blending brush."
            ),
            referenceImage = "https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=800&q=80",
            mentorTip = "Warm colors advance toward the viewer; cool desaturated tones recede into atmospheric distance."
        ),
        PracticeTask(
            id = "task-oil-04",
            categoryId = "painting",
            taskNumber = 4,
            title = "Stage 4: Atelier Masterpiece Portfolio Composition",
            level = DifficultyLevel.PORTFOLIO_READY,
            estimatedMinutes = 90,
            materials = listOf("Belgian Linen Canvas", "Master Oil Palette", "Retouch Varnish"),
            instructions = listOf(
                "Apply deliberate focal glazes over cured underpainting.",
                "Add impasto highlights on primary light catchers with a palette knife.",
                "Sign your completed masterwork and prepare for high-resolution portfolio export."
            ),
            referenceImage = "https://images.unsplash.com/photo-1541701494587-cb58502866ab?auto=format&fit=crop&w=800&q=80",
            mentorTip = "Reserve your thickest paint and sharpest edge exclusively for the single primary focal point."
        )
    )

    val events = listOf(
        ArtEvent(
            id = "evt-sf-modern-01",
            title = "Light & Luminescence: Contemporary Atelier Salon",
            type = "Exhibition",
            venue = "Palace of Fine Arts Gallery",
            city = "San Francisco",
            address = "3301 Lyon St, San Francisco, CA",
            distanceKm = 1.8,
            dateStr = "Tomorrow, 6:00 PM",
            timeStr = "6:00 PM – 9:30 PM",
            isFree = true,
            priceStr = "Free Admission",
            image = "https://images.unsplash.com/photo-1579783902614-a3fb3927b675?auto=format&fit=crop&w=800&q=80",
            description = "An evening salon celebrating atmospheric realism with live acoustic cello and resident artist dialogues.",
            rsvpCount = 142
        ),
        ArtEvent(
            id = "evt-sf-ceramic-02",
            title = "Hands in Clay: Anagama Pottery Masterclass",
            type = "Workshop",
            venue = "Mission Clay Atelier",
            city = "San Francisco",
            address = "24th St & Valencia, San Francisco, CA",
            distanceKm = 3.2,
            dateStr = "This Saturday",
            timeStr = "11:00 AM – 3:00 PM",
            isFree = false,
            priceStr = "$75 (Clay included)",
            image = "https://images.unsplash.com/photo-1565193566173-7a0ee3dbe261?auto=format&fit=crop&w=800&q=80",
            description = "Learn wheel centering, cylinder pulling, and Japanese trimming techniques with master potter Marcus Chen.",
            rsvpCount = 28
        ),
        ArtEvent(
            id = "evt-sf-acoustic-03",
            title = "Acoustic Canvas: Night at the Conservatory",
            type = "Concert",
            venue = "Conservatory of Flowers Lawn",
            city = "San Francisco",
            address = "Golden Gate Park, San Francisco, CA",
            distanceKm = 2.4,
            dateStr = "Sunday Evening",
            timeStr = "7:00 PM – 10:00 PM",
            isFree = true,
            priceStr = "Free RSVP",
            image = "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?auto=format&fit=crop&w=800&q=80",
            description = "Live jazz quartet accompanied by plein-air live painters under illuminated Victorian glass domes.",
            rsvpCount = 310
        )
    )

    val musicGenres = mapOf(
        "jazz" to MusicGenreInfo(
            id = "jazz",
            name = "Jazz & Modal Improvisation",
            tagline = "Syncopated rhythms, blue notes, and expressive chord voicings",
            coverImage = "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?auto=format&fit=crop&w=800&q=80",
            history = "Born in early 20th-century New Orleans, jazz combined African polyrhythms, blues tonality, and European harmonic structures into an expressive art form.",
            characteristics = listOf(
                "Swing feel & syncopated phrasing",
                "Extended chord substitutions (9ths, 11ths, 13ths)",
                "Modal improvisation and call-and-response dynamics"
            ),
            tracks = listOf(
                MusicTrack(
                    id = "track-jazz-01",
                    title = "Midnight Atelier Swing",
                    artist = "Artora Quartet",
                    genre = "Jazz",
                    duration = 32,
                    audioPreset = "jazz_swing",
                    coverImage = "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?auto=format&fit=crop&w=400&q=80",
                    description = "Warm upright bass walk with smooth Rhodes electric piano voicings and brushed snare accompaniment.",
                    bpm = 112,
                    license = "Original Artora Score"
                )
            )
        ),
        "classical" to MusicGenreInfo(
            id = "classical",
            name = "Classical & Counterpoint",
            tagline = "Symphonic clarity, harmonic development & grand dynamics",
            coverImage = "https://images.unsplash.com/photo-1520523839898-5071282543e1?auto=format&fit=crop&w=800&q=80",
            history = "Evolving from the Baroque period through the Classical and Romantic eras, structured around sonata forms and counterpoint.",
            characteristics = listOf(
                "Strict counterpoint and voice leading",
                "Dynamic emotional arc from pianissimo to fortissimo",
                "Acoustic piano arpeggios and orchestral depth"
            ),
            tracks = listOf(
                MusicTrack(
                    id = "track-classical-01",
                    title = "Nocturne in C Minor",
                    artist = "Artora Chamber Soloist",
                    genre = "Classical",
                    duration = 36,
                    audioPreset = "classical_piano",
                    coverImage = "https://images.unsplash.com/photo-1520523839898-5071282543e1?auto=format&fit=crop&w=400&q=80",
                    description = "Delicate grand piano arpeggios descending over rich resonant bass chords.",
                    bpm = 84,
                    license = "Original Artora Score"
                )
            )
        ),
        "blues" to MusicGenreInfo(
            id = "blues",
            name = "Blues",
            tagline = "Soulful bends, 12-bar feeling, and expressive phrasing",
            coverImage = "https://images.unsplash.com/photo-1514525253161-7a46d19cd819?auto=format&fit=crop&w=800&q=80",
            history = "Blues centers on call-and-response, expressive blue notes, and the familiar 12-bar harmonic cycle.",
            characteristics = listOf("12-bar I-IV-V framework", "Blue-note inflections", "Call-and-response phrasing"),
            tracks = listOf(
                MusicTrack("track-blues-01", "Porchlight Blue", "Artora Blues Trio", "Blues", 34, "blues_groove",
                    "https://images.unsplash.com/photo-1514525253161-7a46d19cd819?auto=format&fit=crop&w=400&q=80",
                    "A warm guitar-and-bass blues groove with a relaxed backbeat.", 92, "Original Artora Score")
            )
        ),
        "ambient" to MusicGenreInfo(
            id = "ambient",
            name = "Ambient",
            tagline = "Slow textures, spacious harmony, and calm soundscapes",
            coverImage = "https://images.unsplash.com/photo-1519608487953-e999c86e7455?auto=format&fit=crop&w=800&q=80",
            history = "Ambient music emphasizes atmosphere, sustained tones, and gradual movement rather than a strong beat.",
            characteristics = listOf("Long sustained tones", "Sparse rhythmic motion", "Open harmonic space"),
            tracks = listOf(
                MusicTrack("track-ambient-01", "Ivory Air", "Artora Sound Atelier", "Ambient", 40, "ambient_chords",
                    "https://images.unsplash.com/photo-1519608487953-e999c86e7455?auto=format&fit=crop&w=400&q=80",
                    "Soft sustained chords designed for quiet studio sessions.", 58, "Original Artora Score")
            )
        ),
        "lofi" to MusicGenreInfo(
            id = "lofi",
            name = "Lo-fi",
            tagline = "Dusty textures, mellow chords, and an easy head-nod groove",
            coverImage = "https://images.unsplash.com/photo-1514525253161-7a46d19cd819?auto=format&fit=crop&w=800&q=80",
            history = "Lo-fi production intentionally embraces gentle imperfections, warm repetition, and relaxed beats.",
            characteristics = listOf("Mellow seventh chords", "Relaxed drum pulse", "Tape-like warmth"),
            tracks = listOf(
                MusicTrack("track-lofi-01", "Canvas After Rain", "Artora Study Beats", "Lo-fi", 36, "lofi_chill",
                    "https://images.unsplash.com/photo-1514525253161-7a46d19cd819?auto=format&fit=crop&w=400&q=80",
                    "A mellow study groove with soft chords and a relaxed pulse.", 78, "Original Artora Score")
            )
        )
    )
}
