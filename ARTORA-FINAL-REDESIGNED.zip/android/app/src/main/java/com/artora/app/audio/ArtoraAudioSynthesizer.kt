package com.artora.app.audio

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import kotlinx.coroutines.*
import kotlin.math.PI
import kotlin.math.sin

object ArtoraAudioSynthesizer {
    private const val SAMPLE_RATE = 44100
    private var audioTrack: AudioTrack? = null
    private var isPlaying = false
    private var synthJob: Job? = null

    fun playPreset(preset: String, onProgress: ((Int) -> Unit)? = null) {
        stop()
        isPlaying = true

        val minBufferSize = AudioTrack.getMinBufferSize(
            SAMPLE_RATE,
            AudioFormat.CHANNEL_OUT_MONO,
            AudioFormat.ENCODING_PCM_16BIT
        )

        audioTrack = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(SAMPLE_RATE)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build()
            )
            .setBufferSizeInBytes((minBufferSize * 2).coerceAtLeast(4096))
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build()

        audioTrack?.play()

        // Each preset has a deliberately different harmonic/rhythmic identity.
        val notes = when (preset) {
            "jazz_swing" -> doubleArrayOf(
                293.66, 349.23, 392.00, 440.00, 392.00, 493.88,
                440.00, 392.00, 261.63, 329.63, 392.00, 493.88
            ) // Dm7 -> G7 -> Cmaj7 colour tones
            "classical_piano" -> doubleArrayOf(
                220.00, 261.63, 329.63, 440.00, 523.25, 440.00, 329.63, 261.63
            )
            "blues_groove" -> doubleArrayOf(
                220.00, 261.63, 293.66, 311.13, 329.63, 392.00, 329.63, 293.66
            )
            "ambient_chords" -> doubleArrayOf(
                174.61, 220.00, 261.63, 329.63, 349.23, 261.63
            )
            "lofi_chill" -> doubleArrayOf(
                196.00, 246.94, 293.66, 329.63, 293.66, 246.94
            )
            else -> doubleArrayOf(261.63, 329.63, 392.00, 523.25)
        }

        val noteDuration = when (preset) {
            "jazz_swing", "blues_groove" -> SAMPLE_RATE * 0.34
            "classical_piano" -> SAMPLE_RATE * 0.55
            "ambient_chords" -> SAMPLE_RATE * 1.4
            else -> SAMPLE_RATE * 0.48
        }

        synthJob = CoroutineScope(Dispatchers.Default).launch {
            val buffer = ShortArray(1024)
            var sampleIndex = 0L
            var lastReportedSecond = -1

            while (isPlaying && isActive) {
                for (i in buffer.indices) {
                    val noteIndex = ((sampleIndex / noteDuration).toInt()) % notes.size
                    val local = (sampleIndex % noteDuration) / noteDuration
                    val freq = notes[noteIndex]
                    val time = sampleIndex.toDouble() / SAMPLE_RATE

                    // Gentle attack/release so the synthetic notes do not click.
                    val envelope = when {
                        local < 0.08 -> local / 0.08
                        local > 0.82 -> (1.0 - local) / 0.18
                        else -> 1.0
                    }.coerceIn(0.0, 1.0)

                    val fundamental = sin(2.0 * PI * freq * time)
                    val harmonic = sin(2.0 * PI * freq * 2.0 * time) * 0.22
                    val third = sin(2.0 * PI * freq * 3.0 * time) * 0.08

                    // Swing adds a light off-beat pulse; ambient stays smooth.
                    val pulse = if (preset == "jazz_swing" || preset == "blues_groove") {
                        if (((sampleIndex / (SAMPLE_RATE * 0.17)).toInt() % 2) == 1) 0.82 else 1.0
                    } else 1.0

                    buffer[i] = ((fundamental + harmonic + third) * 0.22 * envelope * pulse * Short.MAX_VALUE)
                        .toInt().coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort()
                    sampleIndex++
                }

                audioTrack?.write(buffer, 0, buffer.size)

                val seconds = (sampleIndex / SAMPLE_RATE).toInt()
                if (seconds != lastReportedSecond) {
                    lastReportedSecond = seconds
                    withContext(Dispatchers.Main) {
                        onProgress?.invoke(seconds)
                    }
                }
            }
        }
    }

    fun pause() {
        isPlaying = false
        synthJob?.cancel()
        audioTrack?.pause()
    }

    fun stop() {
        isPlaying = false
        synthJob?.cancel()
        try { audioTrack?.stop() } catch (_: IllegalStateException) { }
        audioTrack?.release()
        audioTrack = null
    }

    fun isCurrentlyPlaying(): Boolean = isPlaying
}
