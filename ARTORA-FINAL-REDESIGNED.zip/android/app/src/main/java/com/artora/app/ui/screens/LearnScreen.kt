package com.artora.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.artora.app.data.ArtoraRepository
import com.artora.app.model.Tutorial
import com.artora.app.ui.theme.*

@Composable
fun LearnScreen(onOpenTutorial: (Tutorial) -> Unit, onOpenMusic: () -> Unit) {
    var selectedArt by remember { mutableStateOf<String?>(null) }
    var selectedGenre by remember { mutableStateOf("Pop") }
    val artTypes = listOf("Drawing", "Painting", "Sculpture", "Photography", "Digital Art", "Calligraphy", "Crafts", "Dance", "Theatre", "Music", "Architecture", "Animation")
    val genres = listOf("Pop","Rock","Hip Hop","Jazz","Classical","Blues","Electronic","EDM","R&B","Country","Folk","Reggae","Soul","Disco","House","Trance","Techno","Indie","Punk","Ambient","Gospel","Latin","K-Pop","Bollywood","Lo-Fi","Acoustic","World","Alternative","Synthwave","Funk","Metal","Opera","Ska","Grunge","Drum & Bass","Dubstep","Garage","House Jazz","Fusion","Bossa Nova","Flamenco","Reggaeton","Afrobeat","Gospel Soul","Bluegrass","New Age","Chillout","Hard Rock","Progressive","Soundtrack")
    val tutorials = (1..50).map { i -> "${i}. ${if (selectedArt == null) "Creative Foundations" else selectedArt!!} — ${listOf("Basics & Shapes","Composition","Light & Shadow","Color Theory","Texture & Detail","Perspective","Advanced Practice")[i % 7]}" }

    LazyColumn(Modifier.fillMaxSize().background(ArtoraIvory).padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(bottom = 24.dp)) {
        item {
            Column(Modifier.padding(top = 12.dp)) {
                Text("LEARN", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = ArtoraGold, letterSpacing = 1.4.sp)
                Text("What kind of art do you want to learn?", fontFamily = FontFamily.Serif, fontSize = 26.sp, fontWeight = FontWeight.Bold, color = ArtoraCharcoal)
                Text("Choose an art to unlock 50+ structured tutorials.", fontSize = 12.sp, color = ArtoraMuted)
            }
        }
        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(artTypes) { art ->
                    val active = selectedArt == art
                    Surface(shape = RoundedCornerShape(50), color = if (active) ArtoraGold else ArtoraWhite, border = androidx.compose.foundation.BorderStroke(1.dp, ArtoraBeige), modifier = Modifier.clickable { selectedArt = art }) {
                        Text(art, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = ArtoraCharcoal, modifier = Modifier.padding(horizontal = 13.dp, vertical = 9.dp))
                    }
                }
            }
        }
        if (selectedArt == "Music") {
            item {
                Card(shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = ArtoraWhite), border = androidx.compose.foundation.BorderStroke(1.dp, ArtoraBeige)) {
                    Column(Modifier.padding(14.dp)) {
                        Text("50 Music Genres", fontFamily = FontFamily.Serif, fontWeight = FontWeight.Bold, fontSize = 18.sp, color = ArtoraCharcoal)
                        Text("Select a genre to explore artists and 5 music samples.", fontSize = 11.sp, color = ArtoraMuted)
                        Spacer(Modifier.height(10.dp))
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                            items(genres) { genre ->
                                FilterChip(selected = selectedGenre == genre, onClick = { selectedGenre = genre }, label = { Text(genre, fontSize = 10.sp) })
                            }
                        }
                        Spacer(Modifier.height(12.dp))
                        Text("$selectedGenre • 200+ Artists", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = ArtoraCharcoal)
                        Text("Featured artists, emerging creators and genre specialists.", fontSize = 11.sp, color = ArtoraMuted)
                        Spacer(Modifier.height(8.dp))
                        (1..5).forEach { n ->
                            ListItem(headlineContent = { Text("$selectedGenre Artist ${n}", fontSize = 12.sp, fontWeight = FontWeight.SemiBold) }, supportingContent = { Text("Sample ${n} • 03:${20+n}", fontSize = 10.sp) }, leadingContent = { Icon(Icons.Outlined.MusicNote, null, tint = ArtoraGold) }, trailingContent = { Icon(Icons.Outlined.PlayArrow, null, tint = ArtoraGold) })
                        }
                        Button(onClick = onOpenMusic, colors = ButtonDefaults.buttonColors(containerColor = ArtoraGold), shape = RoundedCornerShape(50), modifier = Modifier.fillMaxWidth()) { Text("Explore Music Experience", color = ArtoraCharcoal, fontWeight = FontWeight.Bold) }
                    }
                }
            }
        }
        item { Text("50+ Tutorials", fontFamily = FontFamily.Serif, fontSize = 19.sp, fontWeight = FontWeight.Bold, color = ArtoraCharcoal, modifier = Modifier.padding(top = 6.dp)) }
        items(tutorials) { title ->
            Card(shape = RoundedCornerShape(14.dp), colors = CardDefaults.cardColors(containerColor = ArtoraWhite), border = androidx.compose.foundation.BorderStroke(1.dp, ArtoraBeige), modifier = Modifier.fillMaxWidth().clickable { ArtoraRepository.tutorials.firstOrNull()?.let(onOpenTutorial) }) {
                Row(Modifier.padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(42.dp).clip(CircleShape).background(ArtoraBlush), contentAlignment = Alignment.Center) { Icon(Icons.Outlined.Brush, null, tint = ArtoraGold) }
                    Spacer(Modifier.width(11.dp))
                    Column(Modifier.weight(1f)) { Text(title, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = ArtoraCharcoal); Text(if ((title.hashCode() and 1) == 0) "Beginner • 15 min" else "Intermediate • 25 min", fontSize = 10.sp, color = ArtoraMuted) }
                    Icon(Icons.Outlined.PlayCircle, null, tint = ArtoraGold)
                }
            }
        }
    }
}
