package com.artora.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.artora.app.ui.theme.*

private data class HomeChoice(val title: String, val subtitle: String, val icon: ImageVector, val destination: String)

@Composable
fun ArtoraHomeScreen(onSelect: (String) -> Unit) {
    val choices = listOf(
        HomeChoice("Learn", "Step-by-step tutorials & skills", Icons.Outlined.MenuBook, "learn"),
        HomeChoice("Workshops", "Join workshops & earn marks", Icons.Outlined.School, "workshops"),
        HomeChoice("Discover", "Explore art & creative ideas", Icons.Outlined.Lightbulb, "discover"),
        HomeChoice("Buy", "Buy or pitch your artwork", Icons.Outlined.ShoppingCart, "buy"),
        HomeChoice("Expos", "Find expos & exhibitions near you", Icons.Outlined.ConfirmationNumber, "expos"),
        HomeChoice("Studio", "Get inspired by professionals", Icons.Outlined.Brush, "studio")
    )

    Column(
        modifier = Modifier.fillMaxSize().background(ArtoraIvory).padding(horizontal = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(12.dp))
        Text("Welcome to", fontSize = 12.sp, color = ArtoraMuted, letterSpacing = 1.sp)
        Text("ARTORA", fontFamily = FontFamily.Serif, fontSize = 34.sp, fontWeight = FontWeight.Bold, color = ArtoraCharcoal, letterSpacing = 2.sp)
        Text("Where Art Inspires You", fontSize = 11.sp, color = ArtoraGold, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(18.dp))

        Surface(
            shape = RoundedCornerShape(18.dp), color = ArtoraWhite,
            tonalElevation = 0.dp, shadowElevation = 3.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("ARTORA SCORE", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = ArtoraGold, letterSpacing = 1.sp)
                    Text("875", fontSize = 30.sp, fontWeight = FontWeight.Bold, color = ArtoraCharcoal)
                    Text("Excellent • Top 5%", fontSize = 11.sp, color = ArtoraMuted)
                }
                Icon(Icons.Outlined.EmojiEvents, contentDescription = null, tint = ArtoraGold, modifier = Modifier.size(42.dp))
            }
        }
        Spacer(Modifier.height(16.dp))
        Text("What would you like to do today?", fontFamily = FontFamily.Serif, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = ArtoraCharcoal)
        Spacer(Modifier.height(12.dp))

        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(bottom = 18.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(choices) { choice ->
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = ArtoraWhite),
                    border = androidx.compose.foundation.BorderStroke(1.dp, ArtoraBeige),
                    modifier = Modifier.fillMaxWidth().height(145.dp).clickable { onSelect(choice.destination) }
                ) {
                    Column(Modifier.fillMaxSize().padding(14.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                        Box(Modifier.size(46.dp).clip(RoundedCornerShape(14.dp)).background(ArtoraBlush), contentAlignment = Alignment.Center) {
                            Icon(choice.icon, contentDescription = choice.title, tint = ArtoraGold, modifier = Modifier.size(25.dp))
                        }
                        Spacer(Modifier.height(8.dp))
                        Text(choice.title, fontFamily = FontFamily.Serif, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = ArtoraCharcoal)
                        Text(choice.subtitle, fontSize = 10.sp, color = ArtoraMuted, textAlign = TextAlign.Center, lineHeight = 14.sp)
                    }
                }
            }
        }
    }
}
