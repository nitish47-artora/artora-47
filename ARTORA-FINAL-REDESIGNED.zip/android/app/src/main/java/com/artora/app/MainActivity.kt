package com.artora.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import com.artora.app.model.Tutorial
import com.artora.app.ui.components.AppDestination
import com.artora.app.ui.components.ArtoraBottomBar
import com.artora.app.ui.components.ArtoraTopBar
import com.artora.app.ui.screens.*
import com.artora.app.ui.theme.ArtoraIvory
import com.artora.app.ui.theme.ArtoraTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ArtoraTheme { ArtoraAppContent() } }
    }
}

@Composable
fun ArtoraAppContent() {
    var currentDestination by remember { mutableStateOf(AppDestination.HOME) }
    var selectedArtistId by remember { mutableStateOf<String?>(null) }
    var isWelcomeShown by remember { mutableStateOf(false) }
    var activeTutorial by remember { mutableStateOf<Tutorial?>(null) }
    var showSettings by remember { mutableStateOf(false) }

    fun navigate(destination: AppDestination) {
        selectedArtistId = null
        currentDestination = destination
    }

    Surface(modifier = Modifier.fillMaxSize(), color = ArtoraIvory) {
        if (!isWelcomeShown) {
            WelcomeScreen(onNavigate = { destination ->
                isWelcomeShown = true
                navigate(destination)
            })
        } else if (activeTutorial != null) {
            TutorialPlayerScreen(tutorial = activeTutorial!!, onBack = { activeTutorial = null })
        } else {
            Scaffold(
                topBar = {
                    ArtoraTopBar(
                        title = "ARTORA",
                        subtitle = when (currentDestination) {
                            AppDestination.HOME -> "WHERE ART INSPIRES YOU"
                            AppDestination.LEARN -> "LEARN & CREATE"
                            AppDestination.WORKSHOPS -> "WORKSHOPS"
                            AppDestination.DISCOVER -> "DISCOVER"
                            AppDestination.MARKET -> "BUY & PITCH"
                            AppDestination.NEARBY -> "EXPOS"
                            AppDestination.PRACTICE -> "STUDIO"
                            AppDestination.MUSIC -> "MUSIC"
                            AppDestination.PROFILE -> "MY PROFILE"
                            AppDestination.SETTINGS -> "SETTINGS"
                        },
                        onSettingsClick = { showSettings = true }
                    )
                },
                bottomBar = {
                    ArtoraBottomBar(currentDestination = currentDestination, onNavigate = { destination ->
                        if (destination == AppDestination.SETTINGS) showSettings = true else navigate(destination)
                    })
                },
                containerColor = ArtoraIvory
            ) { paddingValues ->
                Box(Modifier.fillMaxSize().padding(paddingValues)) {
                    if (selectedArtistId != null) {
                        ArtistProfileScreen(artistId = selectedArtistId!!, onBack = { selectedArtistId = null })
                    } else {
                        when (currentDestination) {
                            AppDestination.HOME -> ArtoraHomeScreen(onSelect = { choice ->
                                when (choice) {
                                    "learn" -> navigate(AppDestination.LEARN)
                                    "workshops" -> navigate(AppDestination.WORKSHOPS)
                                    "discover" -> navigate(AppDestination.DISCOVER)
                                    "buy" -> navigate(AppDestination.MARKET)
                                    "expos" -> navigate(AppDestination.NEARBY)
                                    "studio" -> navigate(AppDestination.PRACTICE)
                                }
                            })
                            AppDestination.LEARN -> LearnScreen(onOpenTutorial = { activeTutorial = it }, onOpenMusic = { navigate(AppDestination.MUSIC) })
                            AppDestination.WORKSHOPS -> WorkshopsScreen(onOpenTutorial = { activeTutorial = it })
                            AppDestination.DISCOVER -> DiscoverFeedScreen(onSelectArtist = { selectedArtistId = it })
                            AppDestination.MARKET -> MarketplaceScreen(onSelectArtist = { selectedArtistId = it })
                            AppDestination.NEARBY -> ExposScreen()
                            AppDestination.PRACTICE -> PracticeSystemScreen()
                            AppDestination.MUSIC -> MusicExperienceScreen()
                            AppDestination.PROFILE -> ProfileScreen(onSettings = { showSettings = true })
                            AppDestination.SETTINGS -> ProfileScreen(onSettings = { showSettings = true })
                        }
                    }
                }
            }
        }
        if (showSettings) ArtoraSettingsDialog(onDismiss = { showSettings = false })
    }
}
