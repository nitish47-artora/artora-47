package com.artora.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.artora.app.ui.theme.*

@Composable
fun ProfileScreen(onSettings: () -> Unit) {
    Column(Modifier.fillMaxSize().background(ArtoraIvory).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("MY PROFILE", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = ArtoraGold, letterSpacing = 1.4.sp)
        Text("Artora User", fontFamily = FontFamily.Serif, fontSize = 28.sp, fontWeight = FontWeight.Bold, color = ArtoraCharcoal)
        Card(shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = ArtoraWhite), border = androidx.compose.foundation.BorderStroke(1.dp, ArtoraBeige)) {
            Column(Modifier.padding(18.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) { Text("ARTORA SCORE", fontSize = 10.sp, color = ArtoraGold, fontWeight = FontWeight.Bold); Text("875", fontSize = 34.sp, fontWeight = FontWeight.Bold, color = ArtoraCharcoal); Text("Excellent", fontSize = 11.sp, color = ArtoraMuted) }
                    Icon(Icons.Outlined.EmojiEvents, null, tint = ArtoraGold, modifier = Modifier.size(45.dp))
                }
                Spacer(Modifier.height(14.dp))
                LinearProgressIndicator(progress = { 0.875f }, color = ArtoraGold, trackColor = ArtoraBlush, modifier = Modifier.fillMaxWidth())
            }
        }
        Card(shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = ArtoraWhite), border = androidx.compose.foundation.BorderStroke(1.dp, ArtoraBeige)) {
            Column {
                ListItem(headlineContent = { Text("Workshops completed", fontSize = 12.sp) }, trailingContent = { Text("12", fontWeight = FontWeight.Bold) })
                ListItem(headlineContent = { Text("Certificates earned", fontSize = 12.sp) }, trailingContent = { Text("8", fontWeight = FontWeight.Bold) })
                ListItem(headlineContent = { Text("Current rank", fontSize = 12.sp) }, trailingContent = { Text("Top 5%", fontWeight = FontWeight.Bold, color = ArtoraGold) })
            }
        }
        Button(onClick = onSettings, colors = ButtonDefaults.buttonColors(containerColor = ArtoraCharcoal), shape = RoundedCornerShape(50), modifier = Modifier.fillMaxWidth()) { Icon(Icons.Outlined.Settings, null); Spacer(Modifier.width(8.dp)); Text("Professional Settings", color = ArtoraWhite) }
    }
}
