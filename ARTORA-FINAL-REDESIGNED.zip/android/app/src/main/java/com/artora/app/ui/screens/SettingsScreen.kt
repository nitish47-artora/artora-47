package com.artora.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.artora.app.ui.theme.*

@Composable
fun ArtoraSettingsDialog(onDismiss: () -> Unit) {
    var notifications by remember { mutableStateOf(true) }
    var autoplay by remember { mutableStateOf(false) }
    var freeOnly by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text("Settings", fontWeight = FontWeight.Bold, color = ArtoraCharcoal)
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    "Personalize your Artora experience.",
                    fontSize = 12.sp,
                    color = ArtoraTextBody
                )
                SettingRow("Workshop reminders", notifications) { notifications = it }
                SettingRow("Autoplay music samples", autoplay) { autoplay = it }
                SettingRow("Prefer free discoveries", freeOnly) { freeOnly = it }
            }
        },
        confirmButton = {
            Button(
                onClick = onDismiss,
                colors = ButtonDefaults.buttonColors(containerColor = ArtoraGold),
                shape = MaterialTheme.shapes.extraLarge
            ) {
                Text("Done", color = ArtoraCharcoal, fontWeight = FontWeight.Bold)
            }
        },
        containerColor = ArtoraIvory
    )
}

@Composable
private fun SettingRow(label: String, checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, fontSize = 12.sp, color = ArtoraCharcoal, modifier = Modifier.weight(1f))
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = ArtoraWhite,
                checkedTrackColor = ArtoraGold
            )
        )
    }
}
