package com.artora.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.artora.app.data.ArtoraRepository
import com.artora.app.model.Artwork
import com.artora.app.ui.theme.*

@Composable
fun MarketplaceScreen(
    onSelectArtist: (String) -> Unit = {}
) {
    var marketTab by remember { mutableStateOf("buy") } // "buy" or "pitch"
    var pitchTitle by remember { mutableStateOf("") }
    var pitchMedium by remember { mutableStateOf("") }
    var pitchPrice by remember { mutableStateOf("") }
    var pitchSubmitted by remember { mutableStateOf(false) }

    val forSaleArtworks = ArtoraRepository.artworks.filter { it.isForSale }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(ArtoraIvory)
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Header
        item {
            Column(modifier = Modifier.padding(top = 12.dp, bottom = 4.dp)) {
                Surface(
                    shape = RoundedCornerShape(50),
                    color = ArtoraBlush,
                    border = androidx.compose.foundation.BorderStroke(1.dp, ArtoraCreamBorder)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.ShoppingBag,
                            contentDescription = null,
                            tint = ArtoraGold,
                            modifier = Modifier.size(14.dp)
                        )
                        Text(
                            text = "ATELIER MARKETPLACE & CURATION",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = ArtoraCharcoal,
                            letterSpacing = 1.2.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = "Acquire Originals",
                    fontFamily = FontFamily.Serif,
                    fontSize = 26.sp,
                    fontWeight = FontWeight.Normal,
                    color = ArtoraCharcoal
                )
                Text(
                    text = "Direct provenance from registered atelier fellows and independent masters.",
                    fontSize = 12.sp,
                    color = ArtoraTextBody,
                    modifier = Modifier.padding(top = 4.dp)
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Toggle Buy / Pitch
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = { marketTab = "buy" },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (marketTab == "buy") ArtoraGold else ArtoraWhite
                        ),
                        border = androidx.compose.foundation.BorderStroke(1.dp, if (marketTab == "buy") ArtoraGold else ArtoraBeige),
                        shape = RoundedCornerShape(50),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Acquire Art", color = ArtoraCharcoal, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                    Button(
                        onClick = { marketTab = "pitch" },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (marketTab == "pitch") ArtoraGold else ArtoraWhite
                        ),
                        border = androidx.compose.foundation.BorderStroke(1.dp, if (marketTab == "pitch") ArtoraGold else ArtoraBeige),
                        shape = RoundedCornerShape(50),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Pitch Artwork", color = ArtoraCharcoal, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        if (marketTab == "buy") {
            items(forSaleArtworks) { art ->
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = ArtoraWhite),
                    border = androidx.compose.foundation.BorderStroke(1.dp, ArtoraBeige),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(modifier = Modifier.size(90.dp).clip(RoundedCornerShape(10.dp))) {
                            AsyncImage(
                                model = art.image,
                                contentDescription = art.title,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize()
                            )
                        }

                        Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(
                                text = art.title,
                                fontFamily = FontFamily.Serif,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                color = ArtoraCharcoal
                            )
                            Text(
                                text = "By ${art.artistName} • ${art.artForm}",
                                fontSize = 11.sp,
                                color = ArtoraMuted
                            )
                            Text(
                                text = "$${art.price.toInt()}",
                                fontSize = 14.sp,
                                fontFamily = FontFamily.Serif,
                                fontWeight = FontWeight.Bold,
                                color = ArtoraGoldDark
                            )
                        }

                        Button(
                            onClick = { onSelectArtist(art.artistId) },
                            colors = ButtonDefaults.buttonColors(containerColor = ArtoraBlush),
                            border = androidx.compose.foundation.BorderStroke(1.dp, ArtoraCreamBorder),
                            shape = RoundedCornerShape(50),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Text("Inquire", color = ArtoraCharcoal, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        } else {
            // Pitch Form
            item {
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = ArtoraWhite),
                    border = androidx.compose.foundation.BorderStroke(1.dp, ArtoraBeige),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text(
                            text = "Submit Artwork for Atelier Curation",
                            fontFamily = FontFamily.Serif,
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            color = ArtoraCharcoal
                        )

                        OutlinedTextField(
                            value = pitchTitle,
                            onValueChange = { pitchTitle = it },
                            label = { Text("Artwork Title") },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp)
                        )

                        OutlinedTextField(
                            value = pitchMedium,
                            onValueChange = { pitchMedium = it },
                            label = { Text("Medium & Materials (e.g. Oil on Belgian Linen)") },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp)
                        )

                        OutlinedTextField(
                            value = pitchPrice,
                            onValueChange = { pitchPrice = it },
                            label = { Text("Desired Valuation ($ USD)") },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp)
                        )

                        Button(
                            onClick = {
                                pitchSubmitted = true
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = ArtoraGold),
                            shape = RoundedCornerShape(50),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Submit for Guild Review", color = ArtoraCharcoal, fontWeight = FontWeight.Bold)
                        }

                        if (pitchSubmitted) {
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = ArtoraBlush,
                                border = androidx.compose.foundation.BorderStroke(1.dp, ArtoraCreamBorder),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    text = "✓ Artwork submitted successfully. The curatorial committee will review provenance and notify you within 48 hours.",
                                    fontSize = 11.sp,
                                    color = ArtoraTextBody,
                                    modifier = Modifier.padding(12.dp)
                                )
                            }
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}
